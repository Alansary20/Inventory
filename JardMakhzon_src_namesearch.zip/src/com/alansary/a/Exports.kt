package com.alansary.a

import android.content.Context
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** تصدير Excel بنفس أعمدة وألوان النسخة الأصلية (exportStyledExcel + تصدير المقارنة). */
object Exports {
    private val dash = Regex("^\\d+-[\\d-]+$")
    private val digits = Regex("^\\d+$")

    fun dateStr(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    /** kind: inv | ref | prods | cmp */
    fun fileName(ctx: Context, kind: String): String {
        val base = ctx.getString(when (kind) {
            "inv" -> R.string.x_file_inv
            "ref" -> R.string.x_file_ref
            "prods" -> R.string.x_file_prods
            else -> R.string.x_file_cmp
        })
        return base + "_" + dateStr() + ".xlsx"
    }

    private fun alt(ri: Int) = if (ri % 2 == 0) XlsxWriter.ROW_WHITE else XlsxWriter.ROW_ALT

    fun inventory(ctx: Context, db: Db, os: OutputStream): Int {
        val inv = db.allInventory().sortedByDescending { it.timestamp }
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        val cols = listOf(
            XCol(ctx.getString(R.string.x_barcode), 22), XCol(ctx.getString(R.string.x_itemno), 18),
            XCol(ctx.getString(R.string.x_name), 36), XCol(ctx.getString(R.string.x_qty), 10),
            XCol(ctx.getString(R.string.x_lastscan), 22))
        val rows = inv.mapIndexed { i, it ->
            val itemNo = it.itemNo.ifEmpty { if (dash.matches(it.key)) it.key else "" }
            val barcode = it.barcode.ifEmpty { if (digits.matches(it.key)) it.key else "" }
            XRow(listOf(barcode, itemNo, it.name, it.qty, if (it.timestamp > 0) fmt.format(Date(it.timestamp)) else ""), alt(i))
        }
        XlsxWriter.write(os, ctx.getString(R.string.x_sheet_inv), cols, XlsxWriter.HEADER_GREEN, rows)
        return rows.size
    }

    fun stock(ctx: Context, db: Db, os: OutputStream): Int {
        val all = db.allStock().sortedBy { it.key }
        val cols = listOf(XCol(ctx.getString(R.string.x_itemno), 18), XCol(ctx.getString(R.string.x_name), 36),
            XCol(ctx.getString(R.string.x_refqty), 16))
        val rows = all.mapIndexed { i, s -> XRow(listOf(s.key, s.name, s.qty), alt(i)) }
        XlsxWriter.write(os, ctx.getString(R.string.x_sheet_ref), cols, XlsxWriter.HEADER_GREEN, rows)
        return rows.size
    }


    fun products(ctx: Context, db: Db, os: OutputStream): Int {
        val all = db.allProducts().sortedBy { it.name.lowercase(Locale.ROOT) }
        val cols = listOf(XCol(ctx.getString(R.string.x_barcode), 22), XCol(ctx.getString(R.string.x_itemno), 18),
            XCol(ctx.getString(R.string.x_name), 40), XCol(ctx.getString(R.string.x_priceorig), 16),
            XCol(ctx.getString(R.string.x_pricesale), 16))
        val rows = all.mapIndexed { i, p ->
            val sale = if (p.priceSale != 0.0) p.priceSale else p.priceOrig
            XRow(listOf(p.barcode, p.itemNo, p.name, p.priceOrig, sale), alt(i))
        }
        XlsxWriter.write(os, ctx.getString(R.string.x_sheet_prods), cols, XlsxWriter.HEADER_GREEN, rows)
        return rows.size
    }

    private val CMP_HEADER = CellStyle("FF1B4F72", "FFFFFFFF", bold = true, fontName = "Cairo",
        borderStyle = "medium", borderColor = "FF00A884", wrap = true)
    private val CMP_INC = CellStyle("FFD1FAE5", "FF065F46", fontName = "Cairo")
    private val CMP_DEC = CellStyle("FFFEE2E2", "FF991B1B", fontName = "Cairo")
    private val CMP_MATCH = CellStyle("FFE0F2FE", "FF0369A1", fontName = "Cairo")
    private val CMP_NONE = CellStyle("FFF3F4F6", "FF6B7280", fontName = "Cairo")

    fun compare(ctx: Context, res: CmpResult, os: OutputStream): Int {
        val cols = listOf(
            XCol(ctx.getString(R.string.x_barcode), 20), XCol(ctx.getString(R.string.x_itemno), 18),
            XCol(ctx.getString(R.string.x_name), 40), XCol(ctx.getString(R.string.x_actual), 12),
            XCol(ctx.getString(R.string.x_counted), 12), XCol(ctx.getString(R.string.x_diff), 12),
            XCol(ctx.getString(R.string.x_status), 12))
        val bold = setOf(5, 6)   // الفرق والحالة بخط عريض
        val rows = res.rows.map { r ->
            val style: CellStyle
            val label: String
            val icon: String
            when {
                r.diff > 0 -> { style = CMP_INC; label = ctx.getString(R.string.x_inc); icon = "⬆" }
                r.diff < 0 -> { style = CMP_DEC; label = ctx.getString(R.string.x_dec); icon = "⬇" }
                r.qi > 0 -> { style = CMP_MATCH; label = ctx.getString(R.string.x_match); icon = "✓" }
                else -> { style = CMP_NONE; label = "—"; icon = "—" }
            }
            val diffTxt = (if (r.diff > 0) "+" else "") + Ui.qty(r.diff)
            XRow(listOf(r.barcode, r.itemNo.ifEmpty { if (r.barcode.isEmpty() && !Codes.looksLikeName(r.key)) r.key else "" }, r.name,
                r.qs, r.qi, diffTxt, "$icon $label"), style, bold)
        }
        // العمود الثاني (رقم الصنف) في الأصل: k = itemNo || bc || k
        XlsxWriter.write(os, ctx.getString(R.string.x_sheet_cmp), cols, CMP_HEADER, rows, frozen = true)
        return rows.size
    }
}
