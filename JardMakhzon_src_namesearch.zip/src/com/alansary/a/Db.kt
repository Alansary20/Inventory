package com.alansary.a

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** قاعدة SQLite: كل جداول التطبيق من الآن (المراحل القادمة تستخدمها دون تغيير). */
data class InvItem(
    val key: String, val name: String, val qty: Int,
    val barcode: String = "", val itemNo: String = "", val timestamp: Long = 0L
)

data class LogEntry(
    val id: Long, val itemCode: String, val name: String,
    val barcode: String, val qty: Int, val timestamp: Long
)

data class StockRow(
    val key: String, val itemNo: String = "", val barcode: String = "",
    val name: String = "", val qty: Double = 0.0
)

/** منتج مع الرصيد (إن وُجد) لتبويب الأسعار. */
data class PriceRow(val p: Product, val stock: Double?)

class Db private constructor(c: Context) : SQLiteOpenHelper(c, "inv_smart.db", null, 4) {
    /** يزيد عند أي تغيير في المنتجات أو الرصيد (يُبطل فهرس الأسعار المخزّن). */
    @Volatile var dataVersion = 0L

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE products (id TEXT PRIMARY KEY, barcode TEXT NOT NULL DEFAULT '', item_no TEXT NOT NULL DEFAULT '', name TEXT NOT NULL DEFAULT '', alt_barcodes TEXT NOT NULL DEFAULT '', price_orig REAL NOT NULL DEFAULT 0, price_sale REAL NOT NULL DEFAULT 0, source_id INTEGER NOT NULL DEFAULT 0)")
        db.execSQL("CREATE INDEX idx_products_barcode ON products(barcode)")
        db.execSQL("CREATE INDEX idx_products_item_no ON products(item_no)")
        db.execSQL("CREATE TABLE inventory (key TEXT PRIMARY KEY, name TEXT NOT NULL DEFAULT '', qty INTEGER NOT NULL DEFAULT 0, barcode TEXT NOT NULL DEFAULT '', item_no TEXT NOT NULL DEFAULT '', timestamp INTEGER NOT NULL DEFAULT 0)")
        db.execSQL("CREATE TABLE stock (key TEXT PRIMARY KEY, item_no TEXT NOT NULL DEFAULT '', barcode TEXT NOT NULL DEFAULT '', name TEXT NOT NULL DEFAULT '', qty REAL NOT NULL DEFAULT 0)")
        db.execSQL("CREATE INDEX idx_stock_item_no ON stock(item_no)")
        db.execSQL("CREATE INDEX idx_stock_barcode ON stock(barcode)")
        db.execSQL("CREATE TABLE uploaded_files (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, kind TEXT NOT NULL, timestamp INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE scan_log (id INTEGER PRIMARY KEY AUTOINCREMENT, item_code TEXT NOT NULL, name TEXT NOT NULL DEFAULT '', barcode TEXT NOT NULL DEFAULT '', qty INTEGER NOT NULL DEFAULT 1, timestamp INTEGER NOT NULL)")
        db.execSQL("CREATE INDEX idx_scan_log_time ON scan_log(timestamp)")
        db.execSQL("CREATE TABLE settings (k TEXT PRIMARY KEY, v TEXT NOT NULL)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) db.execSQL("ALTER TABLE scan_log ADD COLUMN qty INTEGER NOT NULL DEFAULT 1")
        if (oldVersion < 3) db.execSQL("ALTER TABLE stock ADD COLUMN barcode TEXT NOT NULL DEFAULT ''")
        if (oldVersion < 4) {
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_stock_item_no ON stock(item_no)")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_stock_barcode ON stock(barcode)")
        }
    }

    private fun read(c: Cursor) = Product(
        id = c.getString(0), barcode = c.getString(1), itemNo = c.getString(2), name = c.getString(3),
        altBarcodes = c.getString(4), priceOrig = c.getDouble(5), priceSale = c.getDouble(6), sourceId = c.getLong(7)
    )

    private fun <T> Cursor.collect(f: (Cursor) -> T): List<T> = use {
        val out = ArrayList<T>()
        while (moveToNext()) out.add(f(this))
        out
    }

    fun searchProducts(q: String, limit: Int, offset: Int): List<Product> {
        val db = readableDatabase
        val c = if (q.isEmpty()) {
            db.rawQuery("SELECT $COLS FROM products ORDER BY name COLLATE NOCASE LIMIT ? OFFSET ?",
                arrayOf(limit.toString(), offset.toString()))
        } else {
            val like = Ar.like(q)
            db.rawQuery("SELECT $COLS FROM products WHERE name GLOB ? OR barcode LIKE ? ESCAPE '\\' OR item_no LIKE ? ESCAPE '\\' OR alt_barcodes LIKE ? ESCAPE '\\' ORDER BY name COLLATE NOCASE LIMIT ? OFFSET ?",
                arrayOf(Ar.glob(q), like, like, like, limit.toString(), offset.toString()))
        }
        return c.collect { read(it) }
    }

    fun allProducts(): List<Product> =
        readableDatabase.rawQuery("SELECT $COLS FROM products", null).collect { read(it) }

    /** بحث دقيق بالكود: باركود أو رقم صنف أو باركود إضافي. */
    fun findByCode(v: String): Product? {
        val c = readableDatabase.rawQuery(
            "SELECT $COLS FROM products WHERE item_no = ? OR barcode = ? OR instr(',' || alt_barcodes || ',', ?) > 0 LIMIT 1",
            arrayOf(v, v, ",$v,"))
        return c.collect { read(it) }.firstOrNull()
    }

    private fun count(table: String): Int =
        readableDatabase.rawQuery("SELECT COUNT(*) FROM $table", null).use { if (it.moveToFirst()) it.getInt(0) else 0 }

    fun countProducts() = count("products")
    fun countInventory() = count("inventory")
    fun countScanLog() = count("scan_log")

    fun upsertProducts(list: List<Product>) {
        dataVersion++
        if (list.isEmpty()) return
        val db = writableDatabase
        db.beginTransaction()
        try {
            val st = db.compileStatement("INSERT OR REPLACE INTO products ($COLS) VALUES (?,?,?,?,?,?,?,?)")
            for (p in list) {
                st.clearBindings()
                st.bindString(1, p.id); st.bindString(2, p.barcode); st.bindString(3, p.itemNo)
                st.bindString(4, p.name); st.bindString(5, p.altBarcodes)
                st.bindDouble(6, p.priceOrig); st.bindDouble(7, p.priceSale); st.bindLong(8, p.sourceId)
                st.executeInsert()
            }
            st.close()
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun deleteProduct(id: String) {
        dataVersion++
        writableDatabase.delete("products", "id = ?", arrayOf(id))
    }

    fun deleteProducts(ids: List<String>) {
        dataVersion++
        if (ids.isEmpty()) return
        val db = writableDatabase
        db.beginTransaction()
        try {
            for (id in ids) db.delete("products", "id = ?", arrayOf(id))
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun clearProducts() {
        dataVersion++
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("products", null, null)
            db.delete("uploaded_files", "kind = ?", arrayOf("products"))
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun addUploadedFile(name: String, kind: String) {
        val v = ContentValues()
        v.put("name", name); v.put("kind", kind); v.put("timestamp", System.currentTimeMillis())
        writableDatabase.insert("uploaded_files", null, v)
    }


    // ───────── البحث الدقيق للمسح ─────────
    private fun one(sql: String, args: Array<String>): Product? =
        readableDatabase.rawQuery(sql, args).collect { read(it) }.firstOrNull()

    fun findByBarcode(code: String): Product? {
        one("SELECT $COLS FROM products WHERE barcode = ? OR instr(',' || alt_barcodes || ',', ?) > 0 LIMIT 1",
            arrayOf(code, ",$code,"))?.let { return it }
        // تسامح الأصفار الأولى: UPC-A (12) ↔ EAN-13 (13)، أو صفر ضاع في ملف إكسل
        if (code.length < 6 || !code.all { it in '0'..'9' }) return null
        val base = code.trimStart('0')
        if (base.isEmpty()) return null
        val variants = LinkedHashSet<String>()
        for (n in intArrayOf(base.length, 8, 12, 13, 14)) if (n >= base.length) variants.add(base.padStart(n, '0'))
        variants.remove(code)
        if (variants.isEmpty()) return null
        val ph = variants.joinToString(",") { "?" }
        return one("SELECT $COLS FROM products WHERE barcode IN ($ph) LIMIT 1", variants.toTypedArray())
    }

    fun findByItemNo(code: String): Product? =
        one("SELECT $COLS FROM products WHERE item_no = ? LIMIT 1", arrayOf(code))


    /** صنف من الرصيد بأي من: المفتاح أو رقم الصنف أو الباركود. */
    fun findStock(code: String): StockRow? =
        readableDatabase.rawQuery("SELECT $STOCK_COLS FROM stock WHERE key = ? OR item_no = ? OR barcode = ? LIMIT 1",
            arrayOf(code, code, code)).collect { readStock(it) }.firstOrNull()

    // ───────── الجرد وسجل المسحات ─────────
    private fun readInv(c: Cursor) = InvItem(c.getString(0), c.getString(1), c.getInt(2), c.getString(3), c.getString(4), c.getLong(5))
    private val INV_COLS = "key, name, qty, barcode, item_no, timestamp"

    private fun readLog(c: Cursor) = LogEntry(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getInt(4), c.getLong(5))
    private val LOG_COLS = "id, item_code, name, barcode, qty, timestamp"

    private fun addInvQty(db: SQLiteDatabase, key: String, delta: Int, name: String, barcode: String, itemNo: String, now: Long) {
        val cur = db.rawQuery("SELECT qty FROM inventory WHERE key = ?", arrayOf(key)).use { if (it.moveToFirst()) it.getInt(0) else -1 }
        if (cur >= 0) {
            val nq = cur + delta
            if (nq <= 0) {
                // وصل الصفر: يُحذف من الجرد ومن سجل المسح معاً
                db.delete("inventory", "key = ?", arrayOf(key))
                db.delete("scan_log", "item_code = ?", arrayOf(key))
            } else {
                val v = ContentValues()
                v.put("qty", nq); v.put("timestamp", now)
                db.update("inventory", v, "key = ?", arrayOf(key))
            }
        } else if (delta > 0) {
            val v = ContentValues()
            v.put("key", key); v.put("name", name); v.put("qty", delta)
            v.put("barcode", barcode); v.put("item_no", itemNo); v.put("timestamp", now)
            db.insertWithOnConflict("inventory", null, v, SQLiteDatabase.CONFLICT_REPLACE)
        }
    }

    /** تنظيف: أي صنف كميته صفر أو أقل يُحذف من الجرد وسجل المسح. يعيد عدد المحذوف. */
    fun purgeZeroInventory(): Int {
        var n = 0
        tx { db ->
            db.execSQL("DELETE FROM scan_log WHERE item_code IN (SELECT key FROM inventory WHERE qty <= 0)")
            n = db.delete("inventory", "qty <= 0", null)
        }
        return n
    }

    /** صفوف جرد مفتاحها اسم مكتوب بالخطأ: تُربط بصنفها الحقيقي (وتُدمج كميتها)، أو تُحفظ كاسم فقط. */
    fun repairNameKeys(): Int {
        val idx = Names.get(this)
        val rows = allInventory().filter { !Codes.isBarcode(it.key) && !Codes.isItemNo(it.key) && Codes.looksLikeName(it.key) }
        var n = 0
        for (r in rows) {
            val hit = idx.exact(r.key)
            val newKey = hit?.let { it.itemNo.ifEmpty { it.barcode } }.orEmpty()
            tx { db ->
                if (hit != null && newKey.isNotEmpty()) {
                    val ex = db.rawQuery("SELECT qty FROM inventory WHERE key = ?", arrayOf(newKey)).use { if (it.moveToFirst()) it.getInt(0) else -1 }
                    if (ex >= 0) {
                        val v = ContentValues(); v.put("qty", ex + r.qty); v.put("timestamp", maxOf(r.timestamp, System.currentTimeMillis()))
                        db.update("inventory", v, "key = ?", arrayOf(newKey))
                        db.delete("inventory", "key = ?", arrayOf(r.key))
                    } else {
                        val v = ContentValues(); v.put("key", newKey); v.put("name", hit.name); v.put("barcode", hit.barcode); v.put("item_no", hit.itemNo)
                        db.update("inventory", v, "key = ?", arrayOf(r.key))
                    }
                    db.execSQL("UPDATE scan_log SET item_code = ?, name = ?, barcode = ? WHERE item_code = ?",
                        arrayOf(newKey, hit.name, hit.barcode, r.key))
                    n++
                } else if (r.itemNo.isNotEmpty() || r.barcode.isNotEmpty() || r.name != r.key) {
                    // لا صنف مطابق: الاسم يبقى اسماً ويُفرَّغ رقم الصنف والباركود
                    val v = ContentValues(); v.put("name", r.key); v.put("barcode", ""); v.put("item_no", "")
                    db.update("inventory", v, "key = ?", arrayOf(r.key))
                    db.execSQL("UPDATE scan_log SET name = ?, barcode = '' WHERE item_code = ?", arrayOf(r.key, r.key))
                    n++
                }
            }
        }
        return n
    }

    /** تنظيف شامل: ربط الأسماء المكتوبة بأصنافها، التعرف على المجهول، حذف الأصفار. */
    fun reconcile(labels: List<String>): Int = repairNameKeys() + resolveUnknown(labels) + purgeZeroInventory()

    /** أصناف الجرد المجهولة: إن ظهر لها اسم الآن في المنتجات أو الرصيد نملأ الاسم والباركود ورقم الصنف. */
    fun resolveUnknown(labels: List<String>): Int {
        val rows = ArrayList<InvItem>()
        val ph = labels.joinToString(",") { "?" }
        readableDatabase.rawQuery("SELECT $INV_COLS FROM inventory WHERE name = '' OR name IN ($ph)", labels.toTypedArray())
            .use { while (it.moveToNext()) rows.add(readInv(it)) }
        var n = 0
        for (r in rows) {
            var name: String? = null
            var bc = r.barcode
            var ino = r.itemNo
            for (code in listOf(r.itemNo, r.barcode, r.key).filter { it.isNotEmpty() }) {
                val p = findByCode(code)
                if (p != null) { name = p.name; if (bc.isEmpty()) bc = p.barcode; if (ino.isEmpty()) ino = p.itemNo; break }
                val s = findStock(code)
                if (s != null) { name = s.name.ifEmpty { s.key }; if (bc.isEmpty()) bc = s.barcode; if (ino.isEmpty()) ino = s.itemNo; break }
            }
            val nm = name
            if (nm != null && nm.isNotBlank()) {
                tx { db ->
                    val v = ContentValues(); v.put("name", nm); v.put("barcode", bc); v.put("item_no", ino)
                    db.update("inventory", v, "key = ?", arrayOf(r.key))
                    val lv = ContentValues(); lv.put("name", nm)
                    db.update("scan_log", lv, "item_code = ?", arrayOf(r.key))
                }
                n++
            }
        }
        return n
    }

    private fun insertLog(db: SQLiteDatabase, itemCode: String, name: String, barcode: String, qty: Int, now: Long) {
        val v = ContentValues()
        v.put("item_code", itemCode); v.put("name", name); v.put("barcode", barcode)
        v.put("qty", qty); v.put("timestamp", now)
        db.insert("scan_log", null, v)
    }

    private fun tx(block: (SQLiteDatabase) -> Unit) {
        val db = writableDatabase
        db.beginTransaction()
        try { block(db); db.setTransactionSuccessful() } finally { db.endTransaction() }
    }

    /** نفس addToInventory الأصلية: تحديث الجرد المجمّع + سطر في السجل التفصيلي. */
    fun addToInventory(itemCode: String, name: String, barcode: String = "", itemNoOverride: String = "") {
        val now = System.currentTimeMillis()
        val onlyDigits = DIGITS_RE.matches(itemCode)
        val hasDash = DASH_RE.matches(itemCode)
        val storedBarcode = if (barcode.isNotEmpty()) barcode else if (onlyDigits) itemCode else ""
        val storedItemNo = if (itemNoOverride.isNotEmpty()) itemNoOverride else if (hasDash) itemCode else ""
        val key = storedItemNo.ifEmpty { storedBarcode.ifEmpty { itemCode } }
        tx { db ->
            addInvQty(db, key, 1, name, storedBarcode, storedItemNo, now)
            insertLog(db, itemCode, name, storedBarcode, 1, now)
        }
    }

    fun searchInventory(q: String, limit: Int, offset: Int): List<InvItem> {
        val c = if (q.isEmpty()) readableDatabase.rawQuery(
            "SELECT $INV_COLS FROM inventory ORDER BY timestamp DESC LIMIT ? OFFSET ?", arrayOf(limit.toString(), offset.toString()))
        else {
            val like = Ar.like(q)
            readableDatabase.rawQuery("SELECT $INV_COLS FROM inventory WHERE name GLOB ? OR barcode LIKE ? ESCAPE '\\' OR item_no LIKE ? ESCAPE '\\' OR key LIKE ? ESCAPE '\\' ORDER BY timestamp DESC LIMIT ? OFFSET ?",
                arrayOf(Ar.glob(q), like, like, like, limit.toString(), offset.toString()))
        }
        return c.collect { readInv(it) }
    }

    fun allInventory(): List<InvItem> =
        readableDatabase.rawQuery("SELECT $INV_COLS FROM inventory", null).collect { readInv(it) }

    fun searchLog(q: String, limit: Int, offset: Int): List<LogEntry> {
        val c = if (q.isEmpty()) readableDatabase.rawQuery(
            "SELECT $LOG_COLS FROM scan_log ORDER BY timestamp DESC, id DESC LIMIT ? OFFSET ?", arrayOf(limit.toString(), offset.toString()))
        else {
            val like = Ar.like(q)
            readableDatabase.rawQuery("SELECT $LOG_COLS FROM scan_log WHERE name GLOB ? OR item_code LIKE ? ESCAPE '\\' OR barcode LIKE ? ESCAPE '\\' ORDER BY timestamp DESC, id DESC LIMIT ? OFFSET ?",
                arrayOf(Ar.glob(q), like, like, limit.toString(), offset.toString()))
        }
        return c.collect { readLog(it) }
    }

    fun logPlus(itemCode: String, name: String, barcode: String) {
        val now = System.currentTimeMillis()
        tx { db ->
            val last = db.rawQuery("SELECT id, qty FROM scan_log WHERE item_code = ? ORDER BY timestamp DESC, id DESC LIMIT 1", arrayOf(itemCode))
                .use { if (it.moveToFirst()) Pair(it.getLong(0), it.getInt(1)) else null }
            if (last != null) {
                val v = ContentValues(); v.put("qty", last.second + 1)
                db.update("scan_log", v, "id = ?", arrayOf(last.first.toString()))
            } else insertLog(db, itemCode, name, barcode, 1, now)
            addInvQty(db, itemCode, 1, name, barcode, itemCode, now)
        }
    }

    /** يعيد false إن لم يوجد سجل لهذا الصنف. */
    fun logMinus(itemCode: String): Boolean {
        var found = false
        val now = System.currentTimeMillis()
        tx { db ->
            val last = db.rawQuery("SELECT id, qty FROM scan_log WHERE item_code = ? ORDER BY timestamp DESC, id DESC LIMIT 1", arrayOf(itemCode))
                .use { if (it.moveToFirst()) Pair(it.getLong(0), it.getInt(1)) else null }
            if (last != null) {
                found = true
                if (last.second > 1) {
                    val v = ContentValues(); v.put("qty", last.second - 1)
                    db.update("scan_log", v, "id = ?", arrayOf(last.first.toString()))
                } else db.delete("scan_log", "id = ?", arrayOf(last.first.toString()))
                addInvQty(db, itemCode, -1, "", "", "", now)
            }
        }
        return found
    }

    fun logDelete(id: Long) {
        tx { db ->
            val row = db.rawQuery("SELECT item_code, qty FROM scan_log WHERE id = ?", arrayOf(id.toString()))
                .use { if (it.moveToFirst()) Pair(it.getString(0), it.getInt(1)) else null }
            if (row != null) {
                db.delete("scan_log", "id = ?", arrayOf(id.toString()))
                addInvQty(db, row.first, -row.second, "", "", "", System.currentTimeMillis())
            }
        }
    }

    fun logSetQty(id: Long, newQty: Int) {
        if (newQty < 1) { logDelete(id); return }
        tx { db ->
            val row = db.rawQuery("SELECT item_code, qty FROM scan_log WHERE id = ?", arrayOf(id.toString()))
                .use { if (it.moveToFirst()) Pair(it.getString(0), it.getInt(1)) else null }
            if (row != null) {
                val v = ContentValues(); v.put("qty", newQty)
                db.update("scan_log", v, "id = ?", arrayOf(id.toString()))
                addInvQty(db, row.first, newQty - row.second, "", "", "", System.currentTimeMillis())
            }
        }
    }

    fun clearInventoryAndLog() {
        tx { db -> db.delete("inventory", null, null); db.delete("scan_log", null, null) }
    }

    /** استيراد الجرد: كل عنصر مع سطر في السجل بكميته. */
    fun importInventory(items: List<InvItem>, replace: Boolean, mergeInto: Map<String, InvItem>) {
        tx { db ->
            if (replace) { db.delete("inventory", null, null); db.delete("scan_log", null, null) }
            for (it in items) {
                val ex = mergeInto[it.key]
                val v = ContentValues()
                v.put("key", ex?.key ?: it.key); v.put("name", ex?.name?.ifEmpty { it.name } ?: it.name)
                v.put("qty", (ex?.qty ?: 0) + it.qty); v.put("barcode", ex?.barcode?.ifEmpty { it.barcode } ?: it.barcode)
                v.put("item_no", ex?.itemNo?.ifEmpty { it.itemNo } ?: it.itemNo); v.put("timestamp", it.timestamp)
                db.insertWithOnConflict("inventory", null, v, SQLiteDatabase.CONFLICT_REPLACE)
                insertLog(db, ex?.key ?: it.key, it.name, it.barcode, it.qty, it.timestamp)
            }
        }
    }

    // ───────── الرصيد (stock) ─────────
    private fun readStock(c: Cursor) = StockRow(c.getString(0), c.getString(1), c.getString(2), c.getString(3), c.getDouble(4))
    private val STOCK_COLS = "key, item_no, barcode, name, qty"

    fun countStock() = count("stock")

    fun allStock(): List<StockRow> =
        readableDatabase.rawQuery("SELECT $STOCK_COLS FROM stock", null).collect { readStock(it) }

    fun searchStock(q: String, limit: Int, offset: Int): List<StockRow> {
        val c = if (q.isEmpty()) readableDatabase.rawQuery(
            "SELECT $STOCK_COLS FROM stock ORDER BY name COLLATE NOCASE LIMIT ? OFFSET ?", arrayOf(limit.toString(), offset.toString()))
        else {
            val like = Ar.like(q)
            readableDatabase.rawQuery("SELECT $STOCK_COLS FROM stock WHERE name GLOB ? OR key LIKE ? ESCAPE '\\' OR barcode LIKE ? ESCAPE '\\' ORDER BY name COLLATE NOCASE LIMIT ? OFFSET ?",
                arrayOf(Ar.glob(q), like, like, limit.toString(), offset.toString()))
        }
        return c.collect { readStock(it) }
    }

    fun upsertStock(list: List<StockRow>) {
        dataVersion++
        if (list.isEmpty()) return
        tx { db ->
            val st = db.compileStatement("INSERT OR REPLACE INTO stock ($STOCK_COLS) VALUES (?,?,?,?,?)")
            for (r in list) {
                st.clearBindings()
                st.bindString(1, r.key); st.bindString(2, r.itemNo); st.bindString(3, r.barcode)
                st.bindString(4, r.name); st.bindDouble(5, r.qty)
                st.executeInsert()
            }
            st.close()
        }
    }

    fun clearStock() {
        dataVersion++
        tx { db -> db.delete("stock", null, null); db.delete("uploaded_files", "kind = ?", arrayOf("stock")) }
    }

    // ───────── الأسعار ─────────

    companion object {
        private val DIGITS_RE = Regex("^\\d+$")
        private val DASH_RE = Regex("^\\d+-[\\d-]+$")
        private const val COLS = "id, barcode, item_no, name, alt_barcodes, price_orig, price_sale, source_id"
        @Volatile private var instance: Db? = null

        fun get(c: Context): Db = instance ?: synchronized(this) {
            instance ?: Db(c.applicationContext).also { instance = it }
        }
    }
}
