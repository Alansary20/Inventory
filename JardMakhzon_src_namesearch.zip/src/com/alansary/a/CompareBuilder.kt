package com.alansary.a

class CmpRow(
    val key: String, val itemNo: String, val barcode: String, val name: String,
    val qs: Double, val qi: Double, val diff: Double
)

class CmpResult(
    val rows: List<CmpRow>, val inc: Int, val dec: Int, val match: Int, val invLen: Int, val stockLen: Int
)

/** نفس منطق cmpRows الأصلي: توحيد المفاتيح عبر جدول المنتجات ثم المقارنة بين الجرد والرصيد. */
object CompareBuilder {
    private val dashRe = Regex("^\\d+-[\\d-]+$")
    private val digitsRe = Regex("^\\d+$")

    fun build(db: Db, unknown: List<String> = emptyList()): CmpResult {
        val inv = db.allInventory()
        val stock = db.allStock()
        val prods = db.allProducts()

        val prodsMap = HashMap<String, Product>()
        for (p in prods) {
            if (p.itemNo.isNotEmpty()) prodsMap[p.itemNo] = p
            if (p.barcode.isNotEmpty() && p.barcode != p.itemNo) prodsMap[p.barcode] = p
            for (ab in p.altList()) if (ab != p.itemNo) prodsMap[ab] = p
        }
        val names = Names.get(db)
        fun canonical(k: String): String {
            val p = prodsMap[k]
            if (p != null && p.itemNo.isNotEmpty()) return p.itemNo
            // مفتاح هو اسم مكتوب بالخطأ: نربطه بصنفه الحقيقي إن تطابقت كلماته
            if (p == null && !Codes.isBarcode(k) && !Codes.isItemNo(k) && Codes.looksLikeName(k)) {
                names.exact(k)?.let { h -> if (h.itemNo.isNotEmpty()) return h.itemNo }
            }
            return k
        }
        fun unknownName(n: String) = n.isBlank() || n in unknown

        val invMap = LinkedHashMap<String, InvItem>()
        for (i in inv) {
            val ck = canonical(i.key)
            val ex = invMap[ck]
            invMap[ck] = if (ex == null) i else ex.copy(
                qty = ex.qty + i.qty,                                    // نجمع الكميات ولا نستبدلها
                name = if (unknownName(ex.name)) i.name else ex.name,
                barcode = ex.barcode.ifEmpty { i.barcode },
                itemNo = ex.itemNo.ifEmpty { i.itemNo })
        }
        val stockMap = LinkedHashMap<String, StockRow>()
        for (s in stock) stockMap[canonical(s.key)] = s

        val all = LinkedHashSet<String>()
        all.addAll(invMap.keys); all.addAll(stockMap.keys)

        val rows = ArrayList<CmpRow>(all.size)
        var inc = 0; var dec = 0; var match = 0
        for (k in all) {
            val i = invMap[k]
            val s = stockMap[k]
            val qi = i?.qty?.toDouble() ?: 0.0
            val qs = s?.qty ?: 0.0
            val diff = qi - qs
            val fp = prodsMap[k]
            val isDash = dashRe.matches(k)
            val isDigits = digitsRe.matches(k)
            val srcItemNo = i?.itemNo ?: s?.itemNo ?: ""
            val srcBarcode = i?.barcode ?: s?.barcode ?: ""
            val itemNo = srcItemNo.ifEmpty { fp?.itemNo ?: "" }.ifEmpty { if (isDash) k else "" }
            val barcode = srcBarcode.ifEmpty { fp?.barcode ?: "" }.ifEmpty { if (isDigits) k else "" }
            val invName = i?.name ?: ""
            val name = when {
                !unknownName(invName) && invName != k -> invName
                !fp?.name.isNullOrBlank() -> fp.name
                !s?.name.isNullOrBlank() -> s.name
                else -> invName
            }
            rows.add(CmpRow(k, itemNo, barcode, name, qs, qi, diff))
            if (diff > 0) inc++ else if (diff < 0) dec++ else if (qi > 0) match++
        }
        return CmpResult(rows, inc, dec, match, inv.size, stock.size)
    }
}
