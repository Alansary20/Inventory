package com.alansary.a

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** تبويب المسح: كاميرا + إدخال يدوي + تأخير + سجل المسحات التفصيلي. */
class ScanView(
    private val act: Activity,
    private val t: Theme,
    private val onChanged: () -> Unit
) : FrameLayout(act) {

    private val db = Db.get(act)
    private val engine = ScanEngine(db, act.getString(R.string.unknown_name))
    private val ui = Handler(Looper.getMainLooper())
    private val prefs = act.getSharedPreferences("scan", Context.MODE_PRIVATE)
    private val tone: ToneGenerator? = try { ToneGenerator(AudioManager.STREAM_MUSIC, 90) } catch (_: Exception) { null }

    // حالة المسح (نفس المتغيرات الأصلية)
    private var scanDelay = prefs.getInt("delay", 1500)
    private var lastScanTime = 0L
    private var isScanLocked = false
    private var pendingCode: String? = null
    private var pendingCount = 0
    private val pendingReset = Runnable {
        pendingCode = null; pendingCount = 0
        if (cameraOn) setStatus("ready", s(R.string.scan_ready))
    }

    // الكاميرا
    private val scanner = CameraScanner(act, { onCameraScan(it) }, { cameraError(it) })
    private var cameras: List<CameraScanner.Cam> = emptyList()
    private var cameraOn = false
    private var surfaceReady = false
    private var startPending = false
    private var awaitSize: android.util.Size? = null
    private var awaitCam = ""
    private lateinit var surface: SurfaceView
    private lateinit var previewBox: CameraBox
    private lateinit var openBtn: TextView

    // الواجهة
    private lateinit var statusCard: LinearLayout
    private lateinit var statusDot: View
    private lateinit var statusText: TextView
    private lateinit var input: EditText
    private lateinit var delayLabel: TextView
    private lateinit var logCount: TextView
    private lateinit var emptyText: TextView

    // السجل
    private val items = ArrayList<LogEntry>()
    private val list = StillListView(act)
    private val adapter = LogAdapter()
    private var query = ""
    private var token = 0
    private var loading = false
    private var endReached = false


    private fun s(id: Int) = act.getString(id)
    private fun fmtS(id: Int, vararg a: Any) = String.format(Locale.US, act.getString(id), *a)
    private fun toast(m: String) = Toast.makeText(act, m, Toast.LENGTH_SHORT).show()
    /** تنفيذ في خيط خلفي؛ أي خطأ غير متوقع يظهر كرسالة بدل أن يُغلق التطبيق. */
    private fun bg(block: () -> Unit) = Thread {
        try { block() } catch (e: Exception) {
            ui.post { toast(fmtS(R.string.op_error, e.message ?: e.javaClass.simpleName)) }
        }
    }.start()

    // ───────── الواجهة ─────────
    private fun buildHeader(): View {
        val c: Context = act
        val h = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        Ui.pad(h, c, 12f, 6f, 12f, 6f)

        // شريط الحالة
        statusCard = LinearLayout(c).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = Ui.rounded(c, t.surface2, t.border, 16f)
        }
        Ui.pad(statusCard, c, 16f, 14f, 16f, 14f)
        statusDot = View(c)
        statusCard.addView(statusDot, Ui.margin(Ui.lp(Ui.dp(c, 12f), Ui.dp(c, 12f)), c, 0f, 0f, 10f, 0f))
        statusText = Ui.text(c, s(R.string.scan_ready), 15f, t.text, true)
        statusCard.addView(statusText, Ui.lpWeight(1f))
        h.addView(statusCard, Ui.margin(Ui.lp(-1, -2), c, 0f, 4f, 0f, 10f))
        setStatus("idle", s(R.string.scan_ready))

        // الإدخال اليدوي
        val row = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL }
        val add = Ui.button(c, "+", t.accent, true) { manualAdd() }
        add.textSize = 26f
        row.addView(add, Ui.margin(Ui.lp(Ui.dp(c, 52f), Ui.dp(c, 52f)), c, 0f, 0f, 8f, 0f))
        input = EditText(c).apply {
            hint = s(R.string.scan_manual_hint)
            setHintTextColor(t.muted); setTextColor(t.text); textSize = 15f
            isSingleLine = true
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_DONE
            background = Ui.rounded(c, t.surface2, t.border, 16f)
            minHeight = Ui.dp(c, 52f)
            setOnEditorActionListener { _, _, _ -> manualAdd(); true }
        }
        Ui.pad(input, c, 14f, 0f, 14f, 0f)
        row.addView(input, Ui.lpWeight(1f))
        h.addView(row, Ui.margin(Ui.lp(-1, -2), c, 0f, 0f, 0f, 10f))


        // معاينة الكاميرا: إطار 340×280 شبه مربع بزوايا مستديرة كما في الأصل
        previewBox = CameraBox(c, 340, 140f, 20f, t.bg).apply { visibility = View.GONE }
        surface = previewBox.surface
        surface.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(hd: SurfaceHolder) {
                surfaceReady = true
                if (startPending) startCamera()
            }
            override fun surfaceChanged(hd: SurfaceHolder, f: Int, w: Int, hh: Int) {
                val aw = awaitSize
                if (aw != null && cameraOn && w == aw.width && hh == aw.height) { awaitSize = null; scanner.start(awaitCam, hd, aw) }
            }
            override fun surfaceDestroyed(hd: SurfaceHolder) {
                surfaceReady = false; awaitSize = null; scanner.stop()
                if (cameraOn) startPending = true   // الكاميرا ما زالت «مفتوحة»: تُعاد عند رجوع السطح بدل الشاشة السوداء
            }
        })
        previewBox.setOnClickListener { scanner.refocus() }
        scanner.viewport = { previewBox.visibleFrac() }
        val pLp = LinearLayout.LayoutParams(-1, -2)
        pLp.gravity = Gravity.CENTER_HORIZONTAL
        pLp.bottomMargin = Ui.dp(c, 10f)
        h.addView(previewBox, pLp)

        // زر تشغيل/إيقاف السكانر: تحت المعاينة (وتحت مربع الإدخال مباشرة حين تكون الكاميرا مغلقة)
        openBtn = Ui.button(c, s(R.string.cam_open), t.accent, true) { toggleCamera() }
        h.addView(openBtn, Ui.margin(Ui.lp(-1, Ui.dp(c, 48f)), c, 0f, 0f, 0f, 10f))


        // التأخير
        val dRow = LinearLayout(c).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = Ui.rounded(c, t.surface2, t.border, 16f)
        }
        Ui.pad(dRow, c, 14f, 10f, 14f, 10f)
        dRow.addView(Ui.text(c, s(R.string.scan_delay), 14f, t.text))
        val seek = SeekBar(c).apply {
            max = (5000 - 500) / 250
            progress = (scanDelay - 500) / 250
        }
        dRow.addView(seek, Ui.margin(Ui.lpWeight(1f), c, 8f, 0f, 8f, 0f))
        delayLabel = Ui.text(c, String.format(Locale.US, "%.1fs", scanDelay / 1000.0), 15f, t.accent, true)
        dRow.addView(delayLabel)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                scanDelay = 500 + p * 250
                delayLabel.text = String.format(Locale.US, "%.1fs", scanDelay / 1000.0)
                lastScanTime = 0
                prefs.edit().putInt("delay", scanDelay).apply()
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
        h.addView(dRow, Ui.margin(Ui.lp(-1, -2), c, 0f, 0f, 0f, 10f))

        // مسح الجرد
        h.addView(Ui.button(c, "🗑  " + s(R.string.reset_inventory), t.danger, false) { confirmReset() },
            Ui.margin(Ui.lp(-1, Ui.dp(c, 52f)), c, 0f, 0f, 0f, 14f))

        // عنوان السجل
        val title = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL }
        title.addView(Ui.text(c, s(R.string.scan_log_title), 16f, t.text, true), Ui.lpWeight(1f))
        logCount = Ui.text(c, "0", 15f, t.accent, true).apply {
            gravity = Gravity.CENTER
            background = Ui.rounded(c, Theme.alpha(t.accent, 0.12f), Theme.alpha(t.accent, 0.4f), 10f)
        }
        Ui.pad(logCount, c, 14f, 4f, 14f, 4f)
        title.addView(logCount)
        h.addView(title, Ui.margin(Ui.lp(-1, -2), c, 0f, 0f, 0f, 8f))

        val search = EditText(c).apply {
            hint = "🔍  " + s(R.string.log_search_hint)
            setHintTextColor(t.muted); setTextColor(t.text); textSize = 14f
            isSingleLine = true
            background = Ui.rounded(c, t.surface2, t.border, 16f)
            minHeight = Ui.dp(c, 48f)
        }
        Ui.pad(search, c, 14f, 0f, 14f, 0f)
        val apply = Runnable { reload() }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(a: CharSequence?, b: Int, d: Int, e: Int) {}
            override fun onTextChanged(a: CharSequence?, b: Int, d: Int, e: Int) {}
            override fun afterTextChanged(ed: Editable?) {
                query = ed?.toString()?.trim() ?: ""
                ui.removeCallbacks(apply)
                ui.postDelayed(apply, if (query.isEmpty()) 0L else 250L)
            }
        })
        h.addView(search, Ui.lp(-1, -2))

        emptyText = Ui.text(c, s(R.string.no_scans), 14f, t.muted).apply { gravity = Gravity.CENTER }
        Ui.pad(emptyText, c, 0f, 30f, 0f, 30f)
        h.addView(emptyText, Ui.lp(-1, -2))
        return h
    }

    private fun setStatus(state: String, msg: String) {
        val color = when (state) {
            "idle" -> t.muted
            "ready" -> t.accent
            "scanning" -> 0xFF10B981.toInt()
            "locked" -> t.danger
            "confirm" -> 0xFF34D399.toInt()
            else -> t.muted
        }
        statusDot.background = Ui.rounded(act, color, 0, 6f)
        statusText.text = msg
    }

    private fun flash(ok: Boolean) {
        val col = if (ok) Theme.alpha(t.accent, 0.35f) else Theme.alpha(t.danger, 0.35f)
        statusCard.background = Ui.rounded(act, col, t.border, 16f)
        ui.postDelayed({ statusCard.background = Ui.rounded(act, t.surface2, t.border, 16f) }, 350)
    }

    fun release() { try { tone?.release() } catch (_: Exception) {} }

    private fun beep(ok: Boolean) {
        try { tone?.startTone(if (ok) ToneGenerator.TONE_PROP_ACK else ToneGenerator.TONE_PROP_NACK, if (ok) 120 else 300) } catch (_: Exception) {}
    }

    // ───────── منطق المسح ─────────
    private fun manualAdd() {
        val raw = input.text.toString().trim()
        if (raw.isEmpty()) { toast(s(R.string.enter_code)); return }
        lastScanTime = 0
        ui.removeCallbacks(pendingReset); pendingCode = null; pendingCount = 0
        lookupAndAdd(raw.replace(Regex("\\.0+$"), "").trim())
        input.setText("")
    }

    /** المعالج بالتأكيد المزدوج: قراءتان متطابقتان خلال 700ms. */
    private fun onCameraScan(raw: String) {
        val code = engine.sanitize(raw) ?: return
        if (isScanLocked) return
        if (code == pendingCode) {
            pendingCount++
            if (pendingCount >= CONFIRM_HITS) {
                ui.removeCallbacks(pendingReset)
                pendingCode = null; pendingCount = 0
                lookupAndAdd(code)
            }
        } else {
            ui.removeCallbacks(pendingReset)
            pendingCode = code
            pendingCount = 1
            setStatus("confirm", fmtS(R.string.status_confirm, code))
            ui.postDelayed(pendingReset, CONFIRM_WINDOW)
        }
    }

    private fun lookupAndAdd(raw: String) {
        val code = engine.sanitize(raw)
        if (code == null) { toast(s(R.string.invalid_code)); return }
        val now = System.currentTimeMillis()
        if (isScanLocked) { setStatus("locked", s(R.string.scan_ready)); return }
        val elapsed = now - lastScanTime
        if (elapsed < scanDelay) {
            setStatus("locked", fmtS(R.string.status_locked, String.format(Locale.US, "%.1fs", (scanDelay - elapsed) / 1000.0)))
            return
        }
        isScanLocked = true
        lastScanTime = now
        setStatus("scanning", fmtS(R.string.status_processing, code))
        bg {
            val out = try { engine.process(code) } catch (e: Exception) { null }
            ui.post {
                when (out?.kind) {
                    ScanEngine.Kind.FOUND -> {
                        beep(true); flash(true); toast("✓ " + out.name)
                        setStatus("ready", fmtS(R.string.status_counted, out.name))
                    }
                    ScanEngine.Kind.AUTO -> {
                        beep(true); flash(true); toast(fmtS(R.string.toast_auto, out.name))
                        setStatus("ready", fmtS(R.string.status_counted, out.name))
                    }
                    ScanEngine.Kind.UNKNOWN -> {
                        beep(false); flash(false); toast(fmtS(R.string.toast_unknown, out.code))
                        setStatus("idle", fmtS(R.string.status_unknown, out.code))
                    }
                    ScanEngine.Kind.NAME_ONLY -> {
                        beep(false); flash(false); toast(fmtS(R.string.toast_unknown, out.code))
                        setStatus("idle", fmtS(R.string.status_unknown, out.code))
                    }
                    ScanEngine.Kind.CHOOSE -> {
                        setStatus("idle", s(R.string.choose_item))
                        showChoices(out.code, out.choices)
                    }
                    else -> setStatus("idle", s(R.string.scan_ready))
                }
                isScanLocked = false
                reload()
                onChanged()
            }
        }
    }

    /** عدّة أصناف تطابق الاسم المكتوب: يختار المستخدم الصنف المقصود. */
    private fun showChoices(typed: String, hits: List<NameHit>) {
        var cd: CardDialog? = null
        val box = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        for (h in hits) {
            val row = LinearLayout(act).apply {
                orientation = LinearLayout.VERTICAL
                background = Ui.rounded(act, t.surface2, t.border, 14f)
            }
            Ui.pad(row, act, 14f, 10f, 14f, 10f)
            row.addView(Ui.text(act, h.name, 14f, t.text, true))
            val codes = listOf(h.itemNo, h.barcode).filter { it.isNotEmpty() }.joinToString("  •  ")
            if (codes.isNotEmpty()) row.addView(Ui.text(act, codes, 11f, t.muted))
            row.setOnClickListener {
                cd?.dismiss()
                bg {
                    val o = engine.addHit(h)
                    ui.post {
                        beep(true); flash(true); toast("✓ " + o.name)
                        setStatus("ready", fmtS(R.string.status_counted, o.name))
                        reload(); onChanged()
                    }
                }
            }
            box.addView(row, Ui.margin(Ui.lp(-1, -2), act, 0f, 0f, 0f, 8f))
        }
        cd = CardDialog(act, t)
            .title(s(R.string.choose_item), R.drawable.ic_products)
            .subtitle(typed)
            .content(box, scroll = true)
            .button(s(R.string.cancel))
            .show()
    }

    // ───────── الكاميرا ─────────
    private fun refreshCameras() {
        // العدسة تُختار تلقائياً (الأفضل أولاً) بلا قائمة اختيار
        val l = CameraScanner.list(act)
        cameras = CameraScanner.bestFirst(act, l)
    }

    private fun toggleCamera() {
        if (cameraOn) { stopCamera(); return }
        if (cameras.isEmpty()) refreshCameras()
        if (cameras.isEmpty()) { toast(s(R.string.cam_none)); return }
        if (act.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            act.requestPermissions(arrayOf(Manifest.permission.CAMERA), REQ_CAMERA)
            return
        }
        cameraOn = true
        openBtn.text = s(R.string.cam_close)
        previewBox.visibility = View.VISIBLE
        setStatus("ready", s(R.string.scan_ready))
        startPending = true
        if (surfaceReady) startCamera()
    }

    private fun startCamera() {
        startPending = false
        val cam = cameras.firstOrNull() ?: return
        val size = CameraScanner.chooseSize(act, cam.id)
        if (size == null) { cameraError("size"); return }
        val cur = surface.holder.surfaceFrame
        surface.holder.setFixedSize(size.width, size.height)
        previewBox.setAspectRatio(size.width.toFloat() / size.height)
        if (cur.width() == size.width && cur.height() == size.height) {
            scanner.start(cam.id, surface.holder, size)
        } else {
            // ننتظر حتى يستقر حجم السطح على حجم المعاينة (تفادي الشاشة السوداء)، مع مهلة احتياطية
            awaitSize = size; awaitCam = cam.id
            surface.postDelayed({
                if (awaitSize === size && cameraOn && surfaceReady) { awaitSize = null; scanner.start(cam.id, surface.holder, size) }
            }, 600)
        }
    }

    fun stopCamera() {
        awaitSize = null
        scanner.stop()
        cameraOn = false
        startPending = false
        if (::openBtn.isInitialized) {
            openBtn.text = s(R.string.cam_open)
            previewBox.visibility = View.GONE
            setStatus("idle", s(R.string.scan_ready))
        }
    }

    private fun cameraError(msg: String) {
        stopCamera()
        toast(fmtS(R.string.cam_error, msg))
    }

    fun onPermissionResult(req: Int, granted: Boolean) {
        if (req != REQ_CAMERA) return
        if (granted) toggleCamera() else toast(s(R.string.cam_perm))
    }

    // ───────── السجل التفصيلي ─────────
    /**
     * keep=true: لا تُفرَّغ القائمة ولا يقفز التمرير؛ تُعاد قراءة نفس عدد الصفوف المحمّلة
     * ويُستعاد موضع التمرير (للأزرار +/−/تعديل/حذف). keep=false: من البداية (بعد مسح جديد).
     */
    private fun reload(keep: Boolean = false) {
        val tok = ++token
        val q = query
        val limit = if (keep) maxOf(items.size, PAGE) else PAGE
        val firstPos = list.firstVisiblePosition
        val topOff = list.getChildAt(0)?.top ?: 0
        if (!keep) { items.clear(); endReached = false }
        loading = true
        bg {
            val n = db.countScanLog()
            val page = db.searchLog(q, limit, 0)
            ui.post {
                if (tok == token) {
                    logCount.text = n.toString()
                    items.clear()
                    items.addAll(page)
                    endReached = page.size < limit
                    loading = false
                    emptyText.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
                    adapter.notifyDataSetChanged()
                    if (keep) list.setSelectionFromTop(firstPos, topOff)
                }
            }
        }
    }

    private fun loadMore() {
        if (loading || endReached) return
        loading = true
        val tok = token
        val offset = items.size
        val q = query
        bg {
            val page = db.searchLog(q, PAGE, offset)
            ui.post {
                if (tok == token) {
                    items.addAll(page)
                    if (page.size < PAGE) endReached = true
                    loading = false
                    emptyText.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
                    adapter.notifyDataSetChanged()
                }
            }
        }
    }

    private fun changed(keep: Boolean = false) { reload(keep); onChanged() }

    private val timeFmt = SimpleDateFormat("hh:mm:ss a", Locale.getDefault())

    private inner class LogAdapter : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(i: Int): Any = items[i]
        override fun getItemId(i: Int) = items[i].id

        override fun getView(i: Int, convert: View?, parent: ViewGroup?): View {
            val c: Context = act
            val e = items[i]
            val wrap = FrameLayout(c)
            Ui.pad(wrap, c, 12f, 5f, 12f, 5f)
            val card = LinearLayout(c).apply {
                orientation = LinearLayout.VERTICAL
                background = Ui.rounded(c, t.surface2, t.border, 14f)
                clipToOutline = true     // شريط الأزرار لا يخرج عن حواف البطاقة
            }
            wrap.addView(card, FrameLayout.LayoutParams(-1, -2))

            val top = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL }
            Ui.pad(top, c, 12f, 10f, 12f, 8f)
            val qty = Ui.text(c, e.qty.toString(), 16f, t.accent, true).apply {
                gravity = Gravity.CENTER
                background = Ui.rounded(c, Theme.alpha(t.accent, 0.12f), Theme.alpha(t.accent, 0.35f), 10f)
                minWidth = Ui.dp(c, 40f); minHeight = Ui.dp(c, 40f)
            }
            top.addView(qty, Ui.margin(Ui.lp(-2, -2), c, 0f, 0f, 10f, 0f))
            val info = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
            info.addView(Ui.text(c, e.name, 14f, t.text, true))
            info.addView(Ui.text(c, e.itemCode + "  •  " + timeFmt.format(Date(e.timestamp)), 11f, t.muted))
            top.addView(info, Ui.lpWeight(1f))
            card.addView(top)

            val actions = LinearLayout(c)
            actions.addView(action("−  " + s(R.string.btn_minus), t.danger, 1f) { rowMinus(e) })
            actions.addView(action("✎  " + s(R.string.btn_edit), t.muted, 1.3f) { rowEdit(e) })
            actions.addView(action("+  " + s(R.string.btn_plus), t.accent, 1f) { rowPlus(e) })
            actions.addView(action("🗑", t.muted, 0.7f) { rowDelete(e) })
            card.addView(actions, Ui.lp(-1, Ui.dp(c, 40f)))
            return wrap
        }

        private fun action(label: String, color: Int, w: Float, onClick: () -> Unit): TextView {
            val tv = Ui.button(act, label, color, false, onClick)
            tv.minHeight = 0
            tv.textSize = 12f
            tv.background = Ui.rounded(act, Theme.alpha(color, 0.07f), 0, 0f)
            tv.layoutParams = LinearLayout.LayoutParams(0, -1, w)
            return tv
        }
    }

    private fun rowPlus(e: LogEntry) {
        Sfx.up()
        bg { db.logPlus(e.itemCode, e.name, e.barcode); ui.post { changed(true) } }
    }

    private fun rowMinus(e: LogEntry) {
        Sfx.down()
        bg {
            val ok = db.logMinus(e.itemCode)
            ui.post { if (!ok) toast(s(R.string.no_scan_log)); changed(true) }
        }
    }

    private fun rowDelete(e: LogEntry) {
        bg { db.logDelete(e.id); ui.post { toast(s(R.string.deleted)); changed(true) } }
    }

    private fun rowEdit(e: LogEntry) {
        val box = LinearLayout(act).apply { gravity = Gravity.CENTER_VERTICAL }
        val et = EditText(act).apply {
            setText(e.qty.toString())
            setTextColor(t.text); textSize = 26f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            inputType = InputType.TYPE_CLASS_NUMBER
            isSingleLine = true
            background = Ui.rounded(act, t.surface2, t.border, 14f)
            minHeight = Ui.dp(act, 56f)
            selectAll()
        }
        fun step(label: String, delta: Int, color: Int): TextView =
            Ui.button(act, label, color, false) {
                val v = (et.text.toString().trim().toIntOrNull() ?: 0) + delta
                et.setText(maxOf(0, v).toString()); et.setSelection(et.text.length)
            }.apply { textSize = 24f; minHeight = Ui.dp(act, 56f) }
        // + على جهة البداية و − على النهاية كما في سجل المسح
        box.addView(step("+", 1, t.accent), Ui.margin(Ui.lp(Ui.dp(act, 56f), Ui.dp(act, 56f)), act, 0f, 0f, 8f, 0f))
        box.addView(et, Ui.lpWeight(1f))
        box.addView(step("−", -1, t.negative), Ui.margin(Ui.lp(Ui.dp(act, 56f), Ui.dp(act, 56f)), act, 8f, 0f, 0f, 0f))
        CardDialog(act, t)
            .title(s(R.string.edit_qty), R.drawable.ic_dlg_edit)
            .subtitle(e.name)
            .content(box)
            .showKeyboard()
            .button(s(R.string.save), CardDialog.Kind.PRIMARY) {
                val q = et.text.toString().trim().toIntOrNull()
                if (q != null) bg { db.logSetQty(e.id, q); ui.post { changed(true) } }
            }
            .button(s(R.string.cancel))
            .show()
    }

    private fun confirmReset() {
        CardDialog(act, t)
            .title(s(R.string.reset_inventory), R.drawable.ic_dlg_trash, danger = true)
            .message(s(R.string.reset_confirm))
            .button(s(R.string.delete), CardDialog.Kind.DANGER) {
                bg { db.clearInventoryAndLog(); ui.post { toast(s(R.string.reset_done)); changed() } }
            }
            .button(s(R.string.cancel))
            .show()
    }

    fun refresh() { reload() }

    // تُنفَّذ بعد تهيئة كل الخصائص أعلاه (ترتيب التهيئة في كوتلين نصّي)
    init {
        list.divider = null
        list.dividerHeight = 0
        list.setSelector(android.R.color.transparent)
        list.isVerticalScrollBarEnabled = false
        list.overScrollMode = View.OVER_SCROLL_NEVER
        list.itemsCanFocus = true
        list.addHeaderView(buildHeader(), null, false)
        list.adapter = adapter
        list.setOnScrollListener(object : AbsListView.OnScrollListener {
            override fun onScrollStateChanged(v: AbsListView, s: Int) {}
            override fun onScroll(v: AbsListView, first: Int, visible: Int, total: Int) {
                if (first + visible >= total - 10) loadMore()
            }
        })
        addView(list, LayoutParams(-1, -1))
        reload()
        refreshCameras()
    }

    companion object {
        const val REQ_CAMERA = 201
        private const val CONFIRM_HITS = 2
        private const val CONFIRM_WINDOW = 700L
        private const val PAGE = 50
    }
}
