package com.alansary.a

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView

/** ScrollView بارتفاع أقصى (حتى لا تتجاوز النافذة الشاشة). */
class MaxHeightScrollView(ctx: Context, private val maxPx: Int) : ScrollView(ctx) {
    override fun onMeasure(w: Int, h: Int) {
        super.onMeasure(w, MeasureSpec.makeMeasureSpec(maxPx, MeasureSpec.AT_MOST))
    }
}

/**
 * نافذة منبثقة بتصميم التطبيق: بطاقة بزوايا مستديرة وحدّ خفيف، رأس بأيقونة متدرجة،
 * وأزرار مدوّرة (أساسي أخضر / حذف أحمر / ثانوي رمادي).
 */
class CardDialog(private val act: Activity, private val t: Theme) {
    enum class Kind { PRIMARY, DANGER, SECONDARY }
    private class Btn(val label: String, val kind: Kind, val dismiss: Boolean, val action: (() -> Unit)?)

    private var title: String? = null
    private var subtitle: String? = null
    private var iconRes = 0
    private var danger = false
    private var message: String? = null
    private var content: View? = null
    private var scrollContent = false
    private var cancelable = true
    private var keyboard = false
    private val buttons = ArrayList<Btn>()
    private var dialog: Dialog? = null

    fun title(text: String, icon: Int = 0, danger: Boolean = false) = apply { title = text; iconRes = icon; this.danger = danger }
    fun subtitle(text: String) = apply { subtitle = text }
    fun message(text: String) = apply { message = text }
    fun content(v: View, scroll: Boolean = false) = apply { content = v; scrollContent = scroll }
    fun cancelable(b: Boolean) = apply { cancelable = b }
    fun showKeyboard() = apply { keyboard = true }
    fun button(label: String, kind: Kind = Kind.SECONDARY, dismiss: Boolean = true, action: (() -> Unit)? = null) =
        apply { buttons.add(Btn(label, kind, dismiss, action)) }

    fun dismiss() { try { dialog?.dismiss() } catch (_: Exception) {} }

    fun show(): CardDialog {
        val c: Context = act
        val dlg = Dialog(act)
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog = dlg

        val outer = FrameLayout(c)
        Ui.pad(outer, c, 14f, 14f, 14f, 14f)          // مساحة لظل البطاقة
        val card = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.rounded(c, t.surface, t.border, 24f)
            elevation = Ui.dp(c, 14f).toFloat()
        }
        Ui.pad(card, c, 20f, 20f, 20f, 18f)
        outer.addView(card, FrameLayout.LayoutParams(-1, -2))

        // الرأس: أيقونة متدرجة + العنوان
        if (title != null) {
            val head = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL }
            if (iconRes != 0) {
                val colors = if (danger) intArrayOf(0xFFBE123C.toInt(), 0xFFFB7185.toInt()) else intArrayOf(t.accent2, t.accent)
                val ic = ImageView(c).apply {
                    setImageResource(iconRes)
                    scaleType = ImageView.ScaleType.CENTER_INSIDE
                    val p = Ui.dp(c, 9f); setPadding(p, p, p, p)
                    background = GradientDrawable(GradientDrawable.Orientation.TL_BR, colors).apply { cornerRadius = Ui.dp(c, 12f).toFloat() }
                    elevation = Ui.dp(c, 3f).toFloat()
                }
                head.addView(ic, Ui.margin(Ui.lp(Ui.dp(c, 40f), Ui.dp(c, 40f)), c, 0f, 0f, 12f, 0f))
            }
            head.addView(Ui.text(c, title!!, 18f, t.text, true), Ui.lpWeight(1f))
            card.addView(head, Ui.lp(-1, -2))
        }
        if (subtitle != null) {
            card.addView(Ui.text(c, subtitle!!, 13f, t.muted).apply { maxLines = 2; setLineSpacing(0f, 1.2f) },
                Ui.margin(Ui.lp(-1, -2), c, 0f, 10f, 0f, 0f))
        }
        if (message != null) {
            card.addView(Ui.text(c, message!!, 15f, t.muted).apply { setLineSpacing(0f, 1.3f) },
                Ui.margin(Ui.lp(-1, -2), c, 0f, if (title != null) 12f else 0f, 0f, 0f))
        }
        content?.let { v ->
            val maxH = (act.resources.displayMetrics.heightPixels * 0.58f).toInt()
            val lp = Ui.margin(Ui.lp(-1, -2), c, 0f, 12f, 0f, 0f)
            if (scrollContent) {
                val sv = MaxHeightScrollView(c, maxH).apply { isVerticalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER }
                sv.addView(v)
                card.addView(sv, lp)
            } else card.addView(v, lp)
        }

        // الأزرار
        if (buttons.isNotEmpty()) {
            val row = LinearLayout(c)
            buttons.forEachIndexed { i, b ->
                val (color, filled) = when (b.kind) {
                    Kind.PRIMARY -> Pair(t.accent, true)
                    Kind.DANGER -> Pair(0xFFDC2626.toInt(), true)
                    Kind.SECONDARY -> Pair(t.muted, false)
                }
                val tv = Ui.button(c, b.label, color, filled) {
                    if (b.dismiss) dismiss()
                    b.action?.invoke()
                }
                tv.minHeight = Ui.dp(c, 46f)
                val lp = LinearLayout.LayoutParams(0, Ui.dp(c, 46f), 1f)
                lp.marginStart = Ui.dp(c, if (i == 0) 0f else 5f)
                lp.marginEnd = Ui.dp(c, if (i == buttons.size - 1) 0f else 5f)
                row.addView(tv, lp)
            }
            card.addView(row, Ui.margin(Ui.lp(-1, -2), c, 0f, 18f, 0f, 0f))
        }

        dlg.setContentView(outer)
        dlg.setCancelable(cancelable)
        dlg.setCanceledOnTouchOutside(cancelable)
        dlg.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            setDimAmount(0.5f)
            val dm = act.resources.displayMetrics
            setLayout(minOf(dm.widthPixels - Ui.dp(c, 8f), Ui.dp(c, 420f)), ViewGroup.LayoutParams.WRAP_CONTENT)
            setSoftInputMode(
                if (keyboard) WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE
                else WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        }
        dlg.show()
        return this
    }

    companion object {
        /** حقل إدخال بنمط التطبيق (عنوان صغير فوقه). */
        fun field(act: Activity, t: Theme, parent: LinearLayout, label: String, value: String, type: Int): EditText {
            parent.addView(Ui.text(act, label, 12f, t.muted, true), Ui.margin(Ui.lp(-1, -2), act, 0f, 10f, 0f, 4f))
            val e = EditText(act).apply {
                setText(value); setTextColor(t.text); setHintTextColor(t.muted); textSize = 15f
                isSingleLine = true
                inputType = type
                background = Ui.rounded(act, t.surface2, t.border, 14f)
                minHeight = Ui.dp(act, 48f)
            }
            Ui.pad(e, act, 14f, 0f, 14f, 0f)
            parent.addView(e, Ui.lp(-1, -2))
            return e
        }
    }
}
