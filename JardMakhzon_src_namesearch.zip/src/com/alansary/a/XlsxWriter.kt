package com.alansary.a

import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** نمط خلية: تعبئة وخط وحدّ سفلي (مطابق لتنسيق ExcelJS في النسخة الأصلية). */
data class CellStyle(
    val fill: String?,            // ARGB مثل FF1A7A5E، أو null بدون تعبئة
    val font: String,             // ARGB
    val bold: Boolean = false,
    val size: Int = 11,
    val fontName: String? = null,
    val borderStyle: String = "thin",
    val borderColor: String = "FFD1D5DB",
    val wrap: Boolean = false
)

class XCol(val header: String, val width: Int)
class XRow(val cells: List<Any?>, val style: CellStyle, val boldCols: Set<Int> = emptySet())

/** كاتب xlsx مع ألوان وتنسيق: رأس ملوّن، صفوف بتعبئة، اتجاه الورقة من اليمين لليسار. */
object XlsxWriter {
    private const val NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
    private const val NS_R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    private const val XML = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"

    /** رأس الأعمدة (الأخضر) كما في exportStyledExcel الأصلية. */
    val HEADER_GREEN = CellStyle("FF1A7A5E", "FFFFFFFF", bold = true, borderStyle = "medium", borderColor = "FF0F5C46")
    val ROW_WHITE = CellStyle("FFFFFFFF", "FF1A202C")
    val ROW_ALT = CellStyle("FFF5F7FA", "FF1A202C")

    private class Reg {
        val fonts = LinkedHashMap<String, Int>()
        val fills = LinkedHashMap<String, Int>()
        val borders = LinkedHashMap<String, Int>()
        val xfs = LinkedHashMap<CellStyle, Int>()
        init { fonts["0|FF000000|11|Calibri"] = 0 }

        fun xf(s: CellStyle): Int = xfs.getOrPut(s) {
            fonts.getOrPut("${if (s.bold) 1 else 0}|${s.font}|${s.size}|${s.fontName ?: "Calibri"}") { fonts.size }
            if (s.fill != null) fills.getOrPut(s.fill) { fills.size + 2 }
            borders.getOrPut("${s.borderStyle}|${s.borderColor}") { borders.size + 1 }
            xfs.size + 1
        }
    }

    fun write(
        out: OutputStream, sheetName: String, cols: List<XCol>, headerStyle: CellStyle,
        rows: List<XRow>, frozen: Boolean = false, headerHeight: Int = 22, rowHeight: Int = 18
    ) {
        val reg = Reg()
        val hdrXf = reg.xf(headerStyle)
        // مرور أول لتسجيل الأنماط
        for (r in rows) {
            reg.xf(r.style)
            if (r.boldCols.isNotEmpty()) reg.xf(r.style.copy(bold = true))
        }

        ZipOutputStream(out).use { zip ->
            fun put(name: String, content: String) {
                zip.putNextEntry(ZipEntry(name)); zip.write(content.toByteArray(Charsets.UTF_8)); zip.closeEntry()
            }
            put("[Content_Types].xml", contentTypes())
            put("_rels/.rels", rootRels())
            put("xl/workbook.xml", workbook(sheetName))
            put("xl/_rels/workbook.xml.rels", workbookRels())
            put("xl/styles.xml", styles(reg))

            zip.putNextEntry(ZipEntry("xl/worksheets/sheet1.xml"))
            val w = zip.bufferedWriter(Charsets.UTF_8)
            w.write(XML)
            w.write("<worksheet xmlns=\"$NS\">")
            w.write("<sheetViews><sheetView workbookViewId=\"0\" rightToLeft=\"1\">")
            if (frozen) w.write("<pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/>")
            w.write("</sheetView></sheetViews><sheetFormatPr defaultRowHeight=\"15\"/><cols>")
            cols.forEachIndexed { i, c ->
                w.write("<col min=\"${i + 1}\" max=\"${i + 1}\" width=\"${c.width}\" customWidth=\"1\"/>")
            }
            w.write("</cols><sheetData>")
            w.write("<row r=\"1\" ht=\"$headerHeight\" customHeight=\"1\">")
            cols.forEachIndexed { c, col -> w.write(cell(c, 1, col.header, hdrXf)) }
            w.write("</row>")
            rows.forEachIndexed { r, row ->
                val rn = r + 2
                w.write("<row r=\"$rn\" ht=\"$rowHeight\" customHeight=\"1\">")
                val base = reg.xfs[row.style]!!
                val bold = if (row.boldCols.isEmpty()) base else reg.xfs[row.style.copy(bold = true)]!!
                for (c in cols.indices) {
                    val v = row.cells.getOrNull(c)
                    w.write(cell(c, rn, v, if (c in row.boldCols) bold else base))
                }
                w.write("</row>")
            }
            w.write("</sheetData></worksheet>")
            w.flush()
            zip.closeEntry()
        }
    }

    private fun colName(i: Int): String {
        val sb = StringBuilder()
        var n = i
        do { sb.append('A' + (n % 26)); n = n / 26 - 1 } while (n >= 0)
        return sb.reverse().toString()
    }

    private fun cell(c: Int, r: Int, v: Any?, xf: Int): String {
        val ref = colName(c) + r
        return when (v) {
            null -> "<c r=\"$ref\" s=\"$xf\"/>"
            is Number -> if (v is Double && (v.isNaN() || v.isInfinite())) "<c r=\"$ref\" s=\"$xf\"/>" else "<c r=\"$ref\" s=\"$xf\"><v>$v</v></c>"
            else -> "<c r=\"$ref\" s=\"$xf\" t=\"inlineStr\"><is><t xml:space=\"preserve\">${esc(v.toString())}</t></is></c>"
        }
    }

    private fun esc(s: String): String {
        val sb = StringBuilder(s.length + 8)
        for (ch in s) when {
            ch == '&' -> sb.append("&amp;")
            ch == '<' -> sb.append("&lt;")
            ch == '>' -> sb.append("&gt;")
            ch == '"' -> sb.append("&quot;")
            ch.code < 0x20 && ch != '\t' && ch != '\n' && ch != '\r' -> {}
            else -> sb.append(ch)
        }
        return sb.toString()
    }

    private fun safeSheetName(n: String): String {
        val cleaned = n.replace(Regex("[\\[\\]:*?/\\\\]"), " ").trim().ifEmpty { "Sheet1" }
        return esc(cleaned.take(31))
    }

    private fun contentTypes() = XML + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
        "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
        "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
        "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>" +
        "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" +
        "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/></Types>"

    private fun rootRels() = XML + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
        "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>"

    private fun workbook(sheetName: String) = XML + "<workbook xmlns=\"$NS\" xmlns:r=\"$NS_R\"><sheets>" +
        "<sheet name=\"${safeSheetName(sheetName)}\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>"

    private fun workbookRels() = XML + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
        "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/>" +
        "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/></Relationships>"

    private fun styles(reg: Reg): String {
        val sb = StringBuilder(XML)
        sb.append("<styleSheet xmlns=\"$NS\">")
        sb.append("<fonts count=\"${reg.fonts.size}\">")
        for (k in reg.fonts.keys) {
            val p = k.split('|')
            sb.append("<font>").append(if (p[0] == "1") "<b/>" else "")
                .append("<sz val=\"${p[2]}\"/><color rgb=\"${p[1]}\"/><name val=\"${p[3]}\"/></font>")
        }
        sb.append("</fonts><fills count=\"${reg.fills.size + 2}\">")
        sb.append("<fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill>")
        for (k in reg.fills.keys) {
            sb.append("<fill><patternFill patternType=\"solid\"><fgColor rgb=\"$k\"/><bgColor indexed=\"64\"/></patternFill></fill>")
        }
        sb.append("</fills><borders count=\"${reg.borders.size + 1}\">")
        sb.append("<border><left/><right/><top/><bottom/><diagonal/></border>")
        for (k in reg.borders.keys) {
            val p = k.split('|')
            sb.append("<border><left/><right/><top/><bottom style=\"${p[0]}\"><color rgb=\"${p[1]}\"/></bottom><diagonal/></border>")
        }
        sb.append("</borders><cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>")
        sb.append("<cellXfs count=\"${reg.xfs.size + 1}\">")
        sb.append("<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>")
        for (s in reg.xfs.keys) {
            val fontId = reg.fonts["${if (s.bold) 1 else 0}|${s.font}|${s.size}|${s.fontName ?: "Calibri"}"]!!
            val fillId = if (s.fill != null) reg.fills[s.fill]!! else 0
            val borderId = reg.borders["${s.borderStyle}|${s.borderColor}"]!!
            sb.append("<xf numFmtId=\"0\" fontId=\"$fontId\" fillId=\"$fillId\" borderId=\"$borderId\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\" applyBorder=\"1\" applyAlignment=\"1\">")
            sb.append("<alignment horizontal=\"center\" vertical=\"center\" readingOrder=\"2\"${if (s.wrap) " wrapText=\"1\"" else ""}/></xf>")
        }
        sb.append("</cellXfs><cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles></styleSheet>")
        return sb.toString()
    }
}
