package com.alansary.a

import android.app.Activity
import android.content.Context
import android.text.TextUtils
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import java.util.Locale

/** نافذة تعيين أعمدة عامة (تُستخدم في استيراد الجرد). */
object ColDialog {
    class Field(val labelRes: Int, val kind: ColumnDetector.Kind, val required: Boolean = false)

    private fun letter(i: Int): String {
        val sb = StringBuilder()
        var n = i
        do { sb.append('A' + (n % 26)); n = n / 26 - 1 } while (n >= 0)
        return sb.reverse().toString()
    }

    /** جدول معاينة: أول 5 صفوف من كل عمود (مع حرف العمود واسمه) لمعرفة مكان كل عمود. */
    fun preview(act: Activity, t: Theme, rows: List<List<String>>, hasHeader: Boolean): View {
        val colCount = rows.maxOf { it.size }
        val data = rows.drop(if (hasHeader) 1 else 0).take(5)
        val table = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
        for (i in 0 until colCount) {
            val col = LinearLayout(act).apply {
                orientation = LinearLayout.VERTICAL
                background = Ui.rounded(act, t.surface2, t.border, 8f)
            }
            val h = rows[0].getOrNull(i)?.trim().orEmpty()
            val head = Ui.text(act, if (hasHeader && h.isNotEmpty()) letter(i) + " · " + h else letter(i), 11.5f, t.accent, true).apply {
                isSingleLine = true; ellipsize = TextUtils.TruncateAt.END
                background = Ui.rounded(act, Theme.alpha(t.accent, 0.12f), 0, 8f)
            }
            Ui.pad(head, act, 8f, 5f, 8f, 5f)
            col.addView(head, Ui.lp(-1, -2))
            for (r in data) {
                val v = r.getOrNull(i)?.trim().orEmpty()
                val tv = Ui.text(act, if (v.isEmpty()) "—" else v, 12f, if (v.isEmpty()) t.muted else t.text).apply {
                    isSingleLine = true; ellipsize = TextUtils.TruncateAt.END
                }
                Ui.pad(tv, act, 8f, 4f, 8f, 4f)
                col.addView(tv, Ui.lp(-1, -2))
            }
            val lp = LinearLayout.LayoutParams(Ui.dp(act, 120f), -2)
            lp.marginEnd = Ui.dp(act, 6f)
            table.addView(col, lp)
        }
        return android.widget.HorizontalScrollView(act).apply {
            isHorizontalScrollBarEnabled = false
            addView(table)
        }
    }

    fun show(
        act: Activity, t: Theme, fileNames: String, rows: List<List<String>>, fields: List<Field>,
        onConfirm: (cols: IntArray, noHeader: Boolean) -> Unit
    ) {
        val colCount = rows.maxOf { it.size }
        val header = rows[0]
        fun s(id: Int) = act.getString(id)

        // تخمين ذكي: العنوان + تحليل محتوى كل عمود (باركود / رقم صنف / اسم / كمية ...)
        val det = ColumnDetector.detect(rows, fields.map { it.kind })
        val guess = IntArray(fields.size) { det.col(fields[it].kind) }

        val box = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        box.addView(Ui.text(act, fileNames, 12f, t.muted))
        val noHeader = CheckBox(act).apply { setText(R.string.no_header); setTextColor(t.text); isChecked = !det.hasHeader }
        box.addView(noHeader)
        val pv = LinearLayout(act)
        box.addView(pv, Ui.margin(Ui.lp(-1, -2), act, 0f, 6f, 0f, 4f))
        val paintPv = { pv.removeAllViews(); pv.addView(preview(act, t, rows, !noHeader.isChecked), Ui.lp(-1, -2)) }
        paintPv()

        val lettersL = (0 until colCount).map { String.format(Locale.US, s(R.string.col_letter), letter(it)) }
        val headerL = (0 until colCount).map { i ->
            val h = header.getOrNull(i)?.trim().orEmpty()
            if (h.isEmpty()) lettersL[i] else "$h  (${letter(i)})"
        }

        class Adp(c: Context, d: List<String>) : ArrayAdapter<String>(c, android.R.layout.simple_spinner_item, d) {
            override fun getView(p: Int, v: View?, parent: ViewGroup): View {
                val tv = super.getView(p, v, parent) as TextView
                tv.setTextColor(t.text); tv.isSingleLine = true; tv.ellipsize = TextUtils.TruncateAt.END
                return tv
            }
            override fun getDropDownView(p: Int, v: View?, parent: ViewGroup): View {
                val tv = super.getDropDownView(p, v, parent) as TextView
                tv.setTextColor(t.text); tv.setBackgroundColor(t.surface); tv.isSingleLine = true
                Ui.pad(tv, act, 14f, 12f, 14f, 12f)
                return tv
            }
        }

        val sp = Array(fields.size) { k ->
            val star = if (fields[k].required) " *" else ""
            box.addView(Ui.text(act, s(fields[k].labelRes) + star, 12f, t.muted), Ui.margin(Ui.lp(-1, -2), act, 0f, 10f, 0f, 2f))
            Spinner(act).also {
                it.background = Ui.rounded(act, t.surface2, t.border, 12f)
                box.addView(it, Ui.lp(-1, Ui.dp(act, 46f)))
            }
        }
        val fill = {
            val labels = if (noHeader.isChecked) lettersL else headerL
            for (k in sp.indices) {
                val keep = sp[k].selectedItemPosition
                val data = listOf(s(R.string.col_none)) + labels
                sp[k].adapter = Adp(act, data)
                if (keep >= 0) sp[k].setSelection(minOf(keep, data.size - 1))
            }
        }
        fill()
        for (k in sp.indices) sp[k].setSelection(if (guess[k] >= 0) guess[k] + 1 else 0)
        noHeader.setOnCheckedChangeListener { _, _ -> fill(); paintPv() }

        val cd = CardDialog(act, t).title(s(R.string.col_map_title), R.drawable.ic_dlg_upload).content(box, scroll = true)
        cd.button(s(R.string.confirm_process), CardDialog.Kind.PRIMARY) {
            val cols = IntArray(fields.size) { sp[it].selectedItemPosition - 1 }
            onConfirm(cols, noHeader.isChecked)
        }
        cd.button(s(R.string.cancel))
        cd.show()
    }
}
