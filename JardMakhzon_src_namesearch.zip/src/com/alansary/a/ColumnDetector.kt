package com.alansary.a

/**
 * تعرّف ذكي على الأعمدة: يجمع إشارة العنوان مع تحليل محتوى الأعمدة (باركود/رقم صنف/اسم/كمية...)،
 * فلا يضع الاسم مكان رقم الصنف حتى لو كان العنوان «اسم الصنف».
 */
object ColumnDetector {
    enum class Kind { BARCODE, ITEM_NO, NAME, QTY, PRICE_ORIG, PRICE_SALE, LAST_SCAN }

    class Result(val cols: Map<Kind, Int>, val hasHeader: Boolean) {
        fun col(k: Kind): Int = cols[k] ?: -1
    }

    private val H_BARCODE = listOf("باركود", "بار كود", "barcode", "bar code", "ean", "upc", "gtin")
    private val H_ITEM = listOf("رقم الصنف", "رقم المادة", "كود الصنف", "كود المادة", "رقم المنتج", "item no", "item code", "item number", "item#", "sku", "itemno")
    private val H_ITEM_WEAK = listOf("رقم", "code", "كود", "item")
    private val H_NAME = listOf("اسم", "الاسم", "وصف", "البيان", "بيان", "name", "desc", "المادة", "المنتج", "product")
    private val H_QTY = listOf("كمية", "الكمية", "qty", "quantity", "عدد", "رصيد", "الفعلي", "count", "النهائي", "تحويل")
    private val H_ORIG = listOf("السعر الأساسي", "سعر أساسي", "أساسي", "أصلي", "السعر الأصلي", "original", "قبل الخصم", "base price", "سعر1", "سعر قبل")
    private val H_SALE = listOf("بعد الخصم", "السعر بعد الخصم", "سعر العرض", "عرض", "خصم", "sale", "discount", "صافي", "net", "سعر2", "سعر بعد")
    private val H_DATE = listOf("آخر مسح", "تاريخ", "date", "time", "الوقت", "last scan", "مسح")

    private fun has(h: String, words: List<String>) = words.any { h.contains(it) }

    private fun isNumber(s: String) = s.replace(",", "").toDoubleOrNull() != null
    private fun looksDate(s: String) = s.length >= 8 && s.any { it.isDigit() } && (s.contains(':') || Regex("\\d{4}-\\d{1,2}-\\d{1,2}").containsMatchIn(s) || Regex("\\d{1,2}/\\d{1,2}/\\d{2,4}").containsMatchIn(s))

    /** هل الصف الأول عناوين؟ (نصوص فقط، لا باركود ولا رقم صنف ولا أرقام). */
    fun looksLikeHeader(row: List<String>?): Boolean {
        if (row == null) return false
        val cells = row.map { it.trim() }.filter { it.isNotEmpty() }
        if (cells.isEmpty()) return false
        if (cells.any { Codes.isBarcode(it) || Codes.isItemNo(it) || isNumber(it) }) return false
        return cells.any { c -> c.any { it.isLetter() } }
    }

    fun detect(rows: List<List<String>>, kinds: List<Kind>): Result {
        val sample = rows.take(60)
        val hasHeader = looksLikeHeader(sample.firstOrNull())
        val header = if (hasHeader) sample.first().map { it.trim().lowercase() } else emptyList()
        val data = if (hasHeader) sample.drop(1) else sample
        val ncols = sample.maxOfOrNull { it.size } ?: 0

        class Prof(val rBar: Double, val rItem: Double, val rName: Double, val rNum: Double, val rDate: Double, val n: Int)
        val prof = (0 until ncols).map { j ->
            val cells = data.mapNotNull { it.getOrNull(j)?.trim()?.takeIf { s -> s.isNotEmpty() } }
            val n = cells.size
            if (n == 0) Prof(0.0, 0.0, 0.0, 0.0, 0.0, 0) else Prof(
                cells.count { Codes.isBarcode(it) } / n.toDouble(),
                cells.count { Codes.isItemNo(it) } / n.toDouble(),
                cells.count { Codes.looksLikeName(it) } / n.toDouble(),
                cells.count { isNumber(it) && !Codes.isBarcode(it) && it.length <= 9 } / n.toDouble(),
                cells.count { looksDate(it) } / n.toDouble(), n)
        }

        class Cand(val kind: Kind, val col: Int, val score: Double)
        val cands = ArrayList<Cand>()
        for (j in 0 until ncols) {
            val h = header.getOrNull(j) ?: ""
            val p = prof[j]
            for (k in kinds) {
                var s = 0.0
                when (k) {
                    Kind.BARCODE -> { if (has(h, H_BARCODE)) s += 3.0; s += 4 * p.rBar }
                    Kind.ITEM_NO -> {
                        if (has(h, H_ITEM)) s += 3.0
                        else if (has(h, H_ITEM_WEAK) && !has(h, H_NAME) && !has(h, H_BARCODE)) s += 1.5
                        s += 4 * p.rItem
                    }
                    Kind.NAME -> { if (has(h, H_NAME)) s += 3.0; s += 4 * p.rName }
                    Kind.QTY -> { if (has(h, H_QTY)) s += 3.0; s += 3 * p.rNum - 2 * p.rName }
                    Kind.PRICE_ORIG -> { if (has(h, H_ORIG)) s += 3.0; s += p.rNum }
                    Kind.PRICE_SALE -> { if (has(h, H_SALE)) s += 3.0; s += p.rNum }
                    Kind.LAST_SCAN -> { if (has(h, H_DATE)) s += 3.0; s += 4 * p.rDate }
                }
                val min = when (k) {
                    Kind.BARCODE, Kind.ITEM_NO, Kind.NAME -> 2.0
                    Kind.QTY -> 2.5
                    Kind.PRICE_ORIG, Kind.PRICE_SALE -> 3.0      // الأسعار لا تُخمَّن من المحتوى وحده
                    Kind.LAST_SCAN -> 3.0
                }
                if (p.n > 0 || has(h, H_BARCODE + H_ITEM + H_NAME + H_QTY + H_ORIG + H_SALE + H_DATE)) {
                    if (s >= min) cands.add(Cand(k, j, s))
                }
            }
        }
        // تعيين جشع: الأعلى درجة أولاً، كل عمود لنوع واحد وكل نوع لعمود واحد
        val out = HashMap<Kind, Int>()
        val used = HashSet<Int>()
        for (c in cands.sortedByDescending { it.score }) {
            if (c.kind in out || c.col in used) continue
            out[c.kind] = c.col; used.add(c.col)
        }
        return Result(out, hasHeader)
    }
}
