package com.alansary.a

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Paint
import android.graphics.Typeface
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

/** تبويب الأسعار: بحث بالباركود/رقم الصنف/الاسم، سكانر، تفاصيل المنتج مع الرصيد، وقائمة المنتجات. */
class PricesView(
    private val act: Activity,
    private val t: Theme,
    private val onChanged: () -> Unit
) : FrameLayout(act) {

    private val db = Db.get(act)
    private val ui = Handler(Looper.getMainLooper())
    private val prefs = act.getSharedPreferences("prices", Context.MODE_PRIVATE)
    private val tone: ToneGenerator? = try { ToneGenerator(AudioManager.STREAM_MUSIC, 90) } catch (_: Exception) { null }

    private var searchType = "barcode"
    private var searchToken = 0
    private lateinit var input: EditText
    private lateinit var resultArea: LinearLayout
    private val typeChips = LinkedHashMap<String, TextView>()

    // السكانر
    private val scanner = CameraScanner(act, { onScan(it) }, { cameraError(it) })
    private var cameras: List<CameraScanner.Cam> = emptyList()
    private var cameraOn = false
    private var surfaceReady = false
    private var startPending = false
    private var awaitSize: android.util.Size? = null
    private var awaitCam = ""
    private var lastScan = 0L
    private var lastCode = ""
    private var lastCodeAt = 0L
    private var lastMiss = ""
    private lateinit var surface: SurfaceView
    private lateinit var previewBox: CameraBox
    private lateinit var camRow: LinearLayout
    private lateinit var toggleBtn: TextView

    // القائمة
    private var filtered: List<PItem> = emptyList()
    private var shown = PAGE
    private val scroll = StillScrollView(act)
    private val column = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
    private val rowsBox = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
    private var token = 0
    private var lastResults: List<PItem> = emptyList()
    private var resultLimit = PAGE
    private lateinit var listCount: TextView
    private lateinit var emptyText: TextView


    private fun s(id: Int) = act.getString(id)
    private fun fmtS(id: Int, vararg a: Any) = String.format(Locale.US, act.getString(id), *a)
    private fun toast(m: String) = Toast.makeText(act, m, Toast.LENGTH_SHORT).show()
    /** تنفيذ في خيط خلفي؛ أي خطأ غير متوقع يظهر كرسالة بدل أن يُغلق التطبيق. */
    private fun bg(block: () -> Unit) = Thread {
        try { block() } catch (e: Exception) {
            ui.post { toast(fmtS(R.string.op_error, e.message ?: e.javaClass.simpleName)) }
        }
    }.start()

    // ───────── الواجهة ─────────
    private fun buildHeader(): View {
        val c: Context = act
        val h = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        Ui.pad(h, c, 12f, 6f, 12f, 6f)

        val card = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.rounded(c, t.surface2, t.border, 20f)
        }
        Ui.pad(card, c, 14f, 14f, 14f, 14f)
        h.addView(card, Ui.margin(Ui.lp(-1, -2), c, 0f, 4f, 0f, 10f))
        card.addView(Ui.text(c, s(R.string.prices_title), 16f, t.text, true))

        val types = LinearLayout(c)
        val defs = listOf("barcode" to R.string.ps_barcode, "code" to R.string.ps_code, "name" to R.string.ps_name)
        defs.forEachIndexed { k, (key, res) ->
            val chip = Ui.button(c, s(res), t.accent, false) { setType(key) }
            chip.minHeight = Ui.dp(c, 42f)
            typeChips[key] = chip
            val lp = Ui.lpWeight(1f)
            lp.marginStart = Ui.dp(c, if (k == 0) 0f else 3f)
            lp.marginEnd = Ui.dp(c, if (k == defs.size - 1) 0f else 3f)
            types.addView(chip, lp)
        }
        card.addView(types, Ui.margin(Ui.lp(-1, -2), c, 0f, 10f, 0f, 0f))

        val row = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL }
        input = EditText(c).apply {
            setTextColor(t.text); setHintTextColor(t.muted); textSize = 15f
            isSingleLine = true
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            background = Ui.rounded(c, t.surface, t.border, 14f)
            minHeight = Ui.dp(c, 50f)
            setOnEditorActionListener { _, _, _ -> doSearch(); hideKeyboard(); true }
        }
        Ui.pad(input, c, 14f, 0f, 14f, 0f)
        row.addView(input, Ui.margin(Ui.lpWeight(1f), c, 0f, 0f, 8f, 0f))
        row.addView(Ui.button(c, "🔍", t.accent, true) { doSearch(); hideKeyboard() }, Ui.lp(Ui.dp(c, 54f), Ui.dp(c, 50f)))
        card.addView(row, Ui.margin(Ui.lp(-1, -2), c, 0f, 10f, 0f, 0f))
        setType("barcode")
        val liveSearch = Runnable {
            val v = input.text.toString().trim()
            if ((searchType == "name" && v.length >= 2) || (searchType == "code" && v.length >= 3)) doSearch()
        }
        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(a: CharSequence?, b: Int, d: Int, e: Int) {}
            override fun onTextChanged(a: CharSequence?, b: Int, d: Int, e: Int) {}
            override fun afterTextChanged(ed: Editable?) {
                ui.removeCallbacks(liveSearch)
                ui.postDelayed(liveSearch, 180)
            }
        })

        // المعاينة: نفس إطار الأصل (4:3 بارتفاع أقصى 260dp وزوايا مستديرة)
        previewBox = CameraBox(c, 4000, 0f, 14f, t.surface2, ratioMode = true).apply { visibility = View.GONE }
        surface = previewBox.surface
        surface.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(hd: SurfaceHolder) { surfaceReady = true; if (startPending) startCamera() }
            override fun surfaceChanged(hd: SurfaceHolder, f: Int, w: Int, hh: Int) {
                val aw = awaitSize
                if (aw != null && cameraOn && w == aw.width && hh == aw.height) { awaitSize = null; scanner.start(awaitCam, hd, aw) }
            }
            override fun surfaceDestroyed(hd: SurfaceHolder) {
                surfaceReady = false; awaitSize = null; scanner.stop()
                if (cameraOn) startPending = true   // الكاميرا ما زالت «مفتوحة»: تُعاد عند رجوع السطح بدل الشاشة السوداء
            }
        })
        val pLp = LinearLayout.LayoutParams(-1, -2)
        pLp.topMargin = Ui.dp(c, 10f)
        card.addView(previewBox, pLp)

        // اختيار الكاميرا
        camRow = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL; visibility = View.GONE }
        previewBox.setOnClickListener { scanner.refocus() }
        scanner.viewport = { previewBox.visibleFrac() }

        val btns = LinearLayout(c)
        toggleBtn = Ui.button(c, "📷  " + s(R.string.ps_start), t.accent, true) { toggleCamera() }
        btns.addView(toggleBtn, Ui.margin(Ui.lpWeight(1.6f), c, 0f, 0f, 8f, 0f))
        btns.addView(Ui.button(c, s(R.string.ps_clear), t.danger, false) { clearSearch() }, Ui.lpWeight(1f))
        card.addView(btns, Ui.margin(Ui.lp(-1, -2), c, 0f, 10f, 0f, 0f))

        resultArea = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        card.addView(resultArea, Ui.margin(Ui.lp(-1, -2), c, 0f, 10f, 0f, 0f))

        // قائمة المنتجات
        val title = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL }
        title.addView(Ui.text(c, s(R.string.prices_list_title), 16f, t.text, true), Ui.lpWeight(1f))
        listCount = Ui.text(c, "0", 14f, t.accent, true).apply {
            background = Ui.rounded(c, Theme.alpha(t.accent, 0.12f), Theme.alpha(t.accent, 0.4f), 10f)
        }
        Ui.pad(listCount, c, 14f, 4f, 14f, 4f)
        title.addView(listCount)
        h.addView(title, Ui.margin(Ui.lp(-1, -2), c, 0f, 4f, 0f, 8f))

        emptyText = Ui.text(c, s(R.string.no_products), 14f, t.muted).apply { gravity = Gravity.CENTER }
        Ui.pad(emptyText, c, 0f, 28f, 0f, 28f)
        h.addView(emptyText, Ui.lp(-1, -2))
        return h
    }

    private fun setType(type: String) {
        searchType = type
        input.hint = s(when (type) { "code" -> R.string.ps_hint_code; "name" -> R.string.ps_hint_name; else -> R.string.ps_hint_barcode })
        for ((k, tv) in typeChips) {
            val sel = k == type
            tv.setTextColor(if (sel) t.accent else t.muted)
            tv.background = Ui.rounded(act, if (sel) Theme.alpha(t.accent, 0.18f) else t.surface,
                if (sel) Theme.alpha(t.accent, 0.5f) else t.border, 14f)
        }
    }

    private fun clearSearch() {
        input.setText("")
        resultArea.removeAllViews()
    }

    // ───────── البحث (نفس doPriceSearch الأصلية) ─────────
    private fun hideKeyboard() {
        val imm = act.getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
        imm.hideSoftInputFromWindow(input.windowToken, 0)
    }

    /** ScrollView يحفظ موضعه ولا يتحرك وحده؛ هذه الدالة تُبقي الاستدعاءات كما هي. */
    private fun keepScroll(change: () -> Unit) = change()

    private fun doSearch(fromScan: Boolean = false) {
        val q = input.text.toString().trim()
        if (q.isEmpty()) return
        val type = searchType
        val tk = ++searchToken
        bg {
            val idx = PricesIndex.get(db)
            var single: PItem? = null
            var many: List<PItem> = emptyList()
            when (type) {
                "barcode" -> single = idx.findBarcode(q)
                "code" -> {
                    single = idx.findCode(q)
                    if (single == null) many = idx.filterCode(q)     // مرتّبة بالرصيد الأكثر أولاً
                }
                else -> many = idx.filterName(q)
            }
            if (single == null && many.size == 1) single = many[0]
            ui.post { if (tk != searchToken) return@post; keepScroll {
                resultArea.removeAllViews()
                if (single != null) {
                    resultArea.addView(detailCard(single))
                    lastMiss = ""
                    if (fromScan) { stopCamera(); scrollToResult() }   // وُجد المنتج: أغلق السكانر فوراً وأظهر البطاقة
                } else if (many.isEmpty()) {
                    if (fromScan) {
                        // لم يُوجد: نُبقي السكانر يعيد المحاولة (قراءة أخرى أو نفس الباركود) حتى يجد المنتج
                        if (q != lastMiss) beep(false)
                        lastMiss = q
                        lastCode = ""
                        lastScan = System.currentTimeMillis() - 1000
                    }
                    val msg = if (type == "barcode") fmtS(R.string.ps_not_found, q) else fmtS(R.string.ps_no_results, q)
                    resultArea.addView(Ui.text(act, msg, 14f, t.danger).apply {
                        gravity = Gravity.CENTER; setPadding(0, Ui.dp(act, 12f), 0, Ui.dp(act, 12f))
                    })
                } else {
                    lastResults = many
                    resultLimit = PAGE
                    paintResults()
                }
            } }
        }
    }

    private fun paintResults() {
        resultArea.removeAllViews()
        for (r in lastResults.take(resultLimit)) resultArea.addView(compactRow(r))
        if (lastResults.size > resultLimit) {
            resultArea.addView(Ui.button(act, s(R.string.more_results) + " (${lastResults.size - resultLimit})", t.accent, false) {
                resultLimit += PAGE
                keepScroll { paintResults() }
            }, Ui.lp(-1, Ui.dp(act, 44f)))
        }
    }

    // ───────── ألوان الرصيد (مطابقة للأصل) ─────────
    private val AMBER = 0xFFF59E0B.toInt()
    private val BLUE = 0xFF1A4FA8.toInt()
    private val RED = 0xFFDC2626.toInt()
    private val BLUE_DARK = 0xFF60A5FA.toInt()

    private fun stockBg(q: Double) = when {
        q == 0.0 -> Theme.alpha(RED, 0.08f)
        q <= 5 -> Theme.alpha(AMBER, 0.10f)
        t.dark -> Theme.alpha(BLUE_DARK, 0.14f)
        else -> 0xFFEEF4FF.toInt()
    }
    private fun stockFg(q: Double) = when { q == 0.0 -> t.negative; q <= 5 -> AMBER; t.dark -> BLUE_DARK; else -> BLUE }

    // ───────── بطاقة النتيجة (مطابقة لـ renderPriceProduct) ─────────
    private fun detailCard(r: PItem): View {
        val c: Context = act
        val card = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.rounded(c, t.surface2, t.border, 15f)
        }
        Ui.pad(card, c, 16f, 16f, 16f, 16f)

        // شارة «تم العثور على المنتج»
        val badge = Ui.text(c, s(R.string.ps_found), 13f, t.accent, true).apply {
            background = Ui.rounded(c, Theme.alpha(t.accent, 0.10f), 0, 20f)
        }
        Ui.pad(badge, c, 12f, 4f, 12f, 4f)
        card.addView(badge, Ui.margin(Ui.lp(-2, -2), c, 0f, 0f, 0f, 9f))

        // الاسم
        card.addView(Ui.text(c, r.name.ifEmpty { "—" }, 18f, t.text, true).apply { setLineSpacing(0f, 1.45f) },
            Ui.margin(Ui.lp(-1, -2), c, 0f, 0f, 0f, 5f))

        // صندوق رقم الصنف والباركودات
        val codes = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.rounded(c, t.surface3, 0, 9f)
        }
        Ui.pad(codes, c, 12f, 9f, 12f, 7f)
        if (r.itemNo.isNotEmpty()) codes.addView(codeRow("🔢 " + s(R.string.lbl_itemno), r.itemNo, false))
        for (b in r.barcodes) codes.addView(codeRow("📦 " + s(R.string.f_barcode), b, true))
        if (codes.childCount > 0) card.addView(codes, Ui.margin(Ui.lp(-1, -2), c, 0f, 0f, 0f, 14f))

        // أربعة مربعات: الأساسي / بعد الخصم / الخصم / الرصيد
        val grid = LinearLayout(c).apply { isBaselineAligned = false }
        val half = 4.5f
        fun add(v: View, first: Boolean, last: Boolean) {
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
            lp.marginStart = Ui.dp(c, if (first) 0f else half)
            lp.marginEnd = Ui.dp(c, if (last) 0f else half)
            grid.addView(v, lp)
        }
        val orig = valueText(if (r.orig != 0.0) Ui.qty(r.orig) else "—", t.muted).apply {
            paintFlags = paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
        }
        add(tile(s(R.string.lbl_orig_price), t.surface3, 0, orig), true, false)
        add(tile(s(R.string.lbl_sale_price), Theme.alpha(0xFF10B981.toInt(), 0.08f), Theme.alpha(0xFF34D399.toInt(), 0.2f),
            valueText(if (r.sale != 0.0) Ui.qty(r.sale) else "—", t.accent)), false, false)
        add(tile(s(R.string.lbl_disc), Theme.alpha(RED, 0.07f), Theme.alpha(0xFFFB7185.toInt(), 0.2f),
            valueText("${r.disc}%", t.negative)), false, false)
        val stockTv = valueText(Ui.qty(r.stock), stockFg(r.stock))   // الرقم فقط بدون كلمة قطعة
        add(tile(s(R.string.lbl_stock), stockBg(r.stock), Theme.alpha(if (t.dark) BLUE_DARK else BLUE, 0.25f), stockTv), false, true)
        card.addView(grid, Ui.lp(-1, -2))
        return card
    }

    private fun valueText(v: String, color: Int): TextView =
        Ui.text(act, v, 17.5f, color, true).apply { textAlignment = View.TEXT_ALIGNMENT_CENTER; gravity = Gravity.CENTER_HORIZONTAL }

    private fun tile(label: String, bg: Int, border: Int, value: View): View {
        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = Ui.rounded(act, bg, border, 12f)
        }
        Ui.pad(box, act, 6f, 10f, 6f, 10f)
        box.addView(Ui.text(act, label, 10.5f, t.muted, true).apply {
            textAlignment = View.TEXT_ALIGNMENT_CENTER; gravity = Gravity.CENTER_HORIZONTAL
        }, Ui.lp(-1, -2))
        box.addView(value, Ui.margin(Ui.lp(-1, -2), act, 0f, 5f, 0f, 0f))
        return box
    }

    /** سطر في صندوق الأكواد: العنوان في البداية والقيمة في صندوق بحدود في النهاية. */
    private fun codeRow(label: String, value: String, mono: Boolean): View {
        val row = LinearLayout(act).apply { gravity = Gravity.CENTER_VERTICAL }
        row.addView(Ui.text(act, label, 13f, t.muted, true), Ui.lpWeight(1f))
        val v = Ui.text(act, value, if (mono) 13f else 14.5f, t.text, true).apply {
            if (mono) { setTypeface(Typeface.MONOSPACE, Typeface.BOLD); letterSpacing = 0.08f }
            background = Ui.rounded(act, t.surface2, t.border, 6f)
        }
        Ui.pad(v, act, 9f, 3f, 9f, 3f)
        row.addView(v, Ui.lp(-2, -2))
        row.layoutParams = Ui.margin(Ui.lp(-1, -2), act, 0f, 0f, 0f, 4f)
        return row
    }

    // ───────── صف المنتج في القوائم (مطابق لصف renderPricesList) ─────────
    private fun rowView(r: PItem): LinearLayout {
        val c: Context = act
        val row = LinearLayout(c).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = Ui.rounded(c, t.surface2, t.border, 12f)
        }
        Ui.pad(row, c, 14f, 11f, 14f, 11f)

        val info = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        info.addView(Ui.text(c, r.name.ifEmpty { "—" }, 15f, t.text, true).apply {
            isSingleLine = true; ellipsize = TextUtils.TruncateAt.END
        })
        info.addView(Ui.text(c, r.code.ifEmpty { "—" }, 11.5f, t.muted))
        val stk = Ui.text(c, "📦 " + Ui.qty(r.stock), 11.5f, stockFg(r.stock), true).apply {
            background = Ui.rounded(c, stockBg(r.stock), 0, 5f)
        }
        Ui.pad(stk, c, 6f, 1f, 6f, 1f)
        info.addView(stk, Ui.margin(Ui.lp(-2, -2), c, 0f, 3f, 0f, 0f))
        row.addView(info, Ui.margin(Ui.lpWeight(1f), c, 0f, 0f, 10f, 0f))

        val price = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        val shownPrice = if (r.sale != 0.0) r.sale else r.orig
        price.addView(Ui.text(c, if (shownPrice != 0.0) Ui.qty(shownPrice) else "—", 17f, AMBER, true))
        if (r.orig != 0.0 && r.sale != 0.0 && r.orig != r.sale) {
            price.addView(Ui.text(c, Ui.qty(r.orig), 11.5f, t.muted).apply {
                paintFlags = paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            })
        }
        if (r.disc != 0) {
            val d = Ui.text(c, "${r.disc}%", 11.5f, t.negative, true).apply {
                textAlignment = View.TEXT_ALIGNMENT_CENTER; gravity = Gravity.CENTER_HORIZONTAL
                background = Ui.rounded(c, Theme.alpha(RED, 0.10f), 0, 5f)
            }
            Ui.pad(d, c, 7f, 1f, 7f, 1f)
            price.addView(d, Ui.margin(Ui.lp(-2, -2), c, 0f, 2f, 0f, 0f))
        }
        row.addView(price)
        return row
    }

    private fun compactRow(r: PItem): View {
        val row = rowView(r)
        row.setOnClickListener { showCardAndScroll(r) }
        row.layoutParams = Ui.margin(Ui.lp(-1, -2), act, 0f, 0f, 0f, 6f)
        return row
    }

    // ───────── السكانر ─────────
    private fun onScan(raw: String) {
        val now = System.currentTimeMillis()
        val code = raw.trim().replace(Regex("[\\x00-\\x1F\\x7F]"), "").replace(Regex("\\.0+$"), "")
        if (code.isEmpty()) return
        // نفس الباركود ما دام أمام الكاميرا: نتجاهله (نجدّد المهلة) حتى يغيب 3 ثوانٍ
        if (code == lastCode && now - lastCodeAt < 3000) { lastCodeAt = now; return }
        if (now - lastScan < 1500) return
        lastCode = code; lastCodeAt = now
        lastScan = now
        beep(true)
        setType("barcode")
        input.setText(code)
        doSearch(fromScan = true)
    }

    private fun beep(ok: Boolean) {
        try { tone?.startTone(if (ok) ToneGenerator.TONE_PROP_ACK else ToneGenerator.TONE_PROP_NACK, if (ok) 120 else 300) } catch (_: Exception) {}
    }

    fun release() { try { tone?.release() } catch (_: Exception) {} }

    private fun refreshCameras() {
        // العدسة تُختار تلقائياً (الأفضل أولاً) بلا قائمة اختيار
        val l = CameraScanner.list(act)
        cameras = CameraScanner.bestFirst(act, l)
    }

    private fun toggleCamera() {
        if (cameraOn) { stopCamera(); return }
        if (cameras.isEmpty()) refreshCameras()
        if (cameras.isEmpty()) { toast(s(R.string.cam_none)); return }
        if (act.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            act.requestPermissions(arrayOf(Manifest.permission.CAMERA), REQ_CAMERA)
            return
        }
        cameraOn = true
        lastCode = ""
        toggleBtn.text = "⏹  " + s(R.string.ps_stop)
        previewBox.visibility = View.VISIBLE
        camRow.visibility = View.VISIBLE
        startPending = true
        if (surfaceReady) startCamera()
    }

    private fun startCamera() {
        startPending = false
        val cam = cameras.firstOrNull() ?: return
        val size = CameraScanner.chooseSize(act, cam.id)
        if (size == null) { cameraError("size"); return }
        val cur = surface.holder.surfaceFrame
        surface.holder.setFixedSize(size.width, size.height)
        previewBox.setAspectRatio(size.width.toFloat() / size.height)
        if (cur.width() == size.width && cur.height() == size.height) {
            scanner.start(cam.id, surface.holder, size)
        } else {
            // ننتظر حتى يستقر حجم السطح على حجم المعاينة (تفادي الشاشة السوداء)، مع مهلة احتياطية
            awaitSize = size; awaitCam = cam.id
            surface.postDelayed({
                if (awaitSize === size && cameraOn && surfaceReady) { awaitSize = null; scanner.start(cam.id, surface.holder, size) }
            }, 600)
        }
    }

    fun stopCamera() {
        awaitSize = null
        scanner.stop()
        cameraOn = false
        startPending = false
        if (::toggleBtn.isInitialized) {
            toggleBtn.text = "📷  " + s(R.string.ps_start)
            previewBox.visibility = View.GONE
            camRow.visibility = View.GONE
        }
    }

    private fun cameraError(msg: String) { stopCamera(); toast(fmtS(R.string.cam_error, msg)) }

    fun onPermissionResult(req: Int, granted: Boolean) {
        if (req != REQ_CAMERA) return
        if (granted) toggleCamera() else toast(s(R.string.cam_perm))
    }

    // ───────── قائمة المنتجات (من الفهرس، الرصيد الأكثر أولاً) ─────────
    fun refresh() { reload() }

    private fun reload() {
        val tok = ++token
        bg {
            val res = PricesIndex.get(db).list
            ui.post {
                if (tok == token) {
                    filtered = res
                    shown = 0
                    rowsBox.removeAllViews()
                    listCount.text = res.size.toString()
                    emptyText.visibility = if (res.isEmpty()) View.VISIBLE else View.GONE
                    appendMore()
                }
            }
        }
    }

    /** يضيف الدفعة التالية من الصفوف (50) عند الاقتراب من نهاية الصفحة. */
    private fun appendMore() {
        val end = minOf(shown + PAGE, filtered.size)
        for (i in shown until end) rowsBox.addView(productRow(filtered[i]))
        shown = end
    }

    /** يحمّل دفعة واحدة فقط، وبعد أن تُقاس الشاشة (وإلا قد تتكرر الإضافة بلا نهاية). */
    private fun maybeLoadMore() {
        if (scroll.height == 0 || column.height == 0) return
        if (shown < filtered.size && column.height - (scroll.scrollY + scroll.height) < Ui.dp(act, 900f)) {
            appendMore()
        }
    }

    /** عند الضغط على منتج: تظهر بطاقته وترتفع الصفحة إليها (الحركة هنا بطلب المستخدم فقط). */
    private fun showCardAndScroll(r: PItem) {
        resultArea.removeAllViews()
        resultArea.addView(detailCard(r))
        scrollToResult()
    }

    private fun scrollToResult() {
        scroll.post {
            var y = 0
            var v: View = resultArea
            while (v !== column && v.parent is View) { y += v.top; v = v.parent as View }
            scroll.smoothScrollTo(0, maxOf(0, y - Ui.dp(act, 10f)))
        }
    }

    private fun productRow(r: PItem): View {
        val wrap = FrameLayout(act)
        Ui.pad(wrap, act, 12f, 4f, 12f, 4f)
        val row = rowView(r)
        row.setOnClickListener { showCardAndScroll(r) }
        wrap.addView(row, FrameLayout.LayoutParams(-1, -2))
        return wrap
    }


    // تُنفَّذ بعد تهيئة كل الخصائص أعلاه (ترتيب التهيئة في كوتلين نصّي)
    init {
        scroll.isVerticalScrollBarEnabled = false      // بلا شريط التمرير الرمادي
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        column.addView(buildHeader(), LinearLayout.LayoutParams(-1, -2))
        column.addView(rowsBox, LinearLayout.LayoutParams(-1, -2))
        scroll.addView(column, FrameLayout.LayoutParams(-1, -2))
        // لا يركّز على حقل الكتابة ولا يمرّر إليه عند فتح لوحة المفاتيح
        input.revealOnFocusHint = false
        scroll.setOnScrollChangeListener { _, _, _, _, _ -> maybeLoadMore() }
        // بعد كل قياس للصفحة (مثلاً أول ظهور): إن كان المحتوى أقصر من الشاشة نُكمله بدفعة واحدة
        column.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> scroll.post { maybeLoadMore() } }
        addView(scroll, LayoutParams(-1, -1))
        refreshCameras()
        reload()
    }

    companion object {
        const val REQ_CAMERA = 202
        private const val PAGE = 50
    }
}
