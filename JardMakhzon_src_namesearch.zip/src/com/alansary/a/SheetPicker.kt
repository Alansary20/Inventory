package com.alansary.a

import android.app.Activity
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup

/** إن كان ملف xlsx بأكثر من ورقة، يسأل المستخدم عن الورقة المطلوبة (لكل ملف) قبل القراءة. */
object SheetPicker {
    fun ensure(act: Activity, t: Theme, uris: List<Uri>, done: () -> Unit) {
        val ui = Handler(Looper.getMainLooper())
        Thread {
            val multi = ArrayList<Pair<Uri, List<String>>>()
            for (u in uris) {
                val names = TableReader.sheetNames(act, u)
                if (names.size > 1) multi.add(u to names)
            }
            ui.post { next(act, t, multi, 0, done) }
        }.start()
    }

    private fun next(act: Activity, t: Theme, list: List<Pair<Uri, List<String>>>, i: Int, done: () -> Unit) {
        if (i >= list.size) { done(); return }
        val (uri, names) = list[i]
        val group = RadioGroup(act).apply { orientation = RadioGroup.VERTICAL }
        names.forEachIndexed { k, n ->
            group.addView(RadioButton(act).apply {
                id = k + 1; text = n; setTextColor(t.text); isChecked = k == 0
                Ui.pad(this, act, 6f, 10f, 6f, 10f)
            }, LinearLayout.LayoutParams(-1, -2))
        }
        val cd = CardDialog(act, t)
            .title(act.getString(R.string.sheet_pick_title), R.drawable.ic_dlg_upload)
            .subtitle(TableReader.fileName(act, uri))
            .content(group, scroll = true)
            .cancelable(false)
        cd.button(act.getString(R.string.confirm_process), CardDialog.Kind.PRIMARY) {
            TableReader.setSheet(uri, (group.checkedRadioButtonId - 1).coerceAtLeast(0))
            next(act, t, list, i + 1, done)
        }
        cd.button(act.getString(R.string.cancel)) { /* إلغاء العملية كلها */ }
        cd.show()
    }
}
