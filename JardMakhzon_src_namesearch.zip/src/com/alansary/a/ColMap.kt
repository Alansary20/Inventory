package com.alansary.a

import java.util.Locale

/** فهارس الأعمدة المختارة (-1 = غير مستخدم). */
class ColMap {
    var barcode = -1
    var itemNo = -1
    var name = -1
    var priceOrig = -1
    var priceSale = -1
    var noHeader = false

    companion object {
        private val KW_BARCODE = listOf("باركود", "barcode", "بار", "كود")
        private val KW_ITEM = listOf("رقم الصنف", "رقم", "item", "صنف")
        private val KW_NAME = listOf("اسم", "name", "وصف", "desc", "المادة")
        private val KW_ORIG = listOf("السعر الأساسي", "أساسي", "أصلي", "السعر الأصلي", "original", "قبل الخصم", "سعر قبل", "سعر أصلي", "سعر1")
        private val KW_SALE = listOf("بعد الخصم", "السعر بعد الخصم", "عرض", "سعر العرض", "خصم", "sale", "بعد", "صافي", "net", "سعر بعد", "سعر2")

        private fun find(header: List<String>, kws: List<String>, used: MutableSet<Int>): Int {
            for (i in header.indices) {
                if (i in used) continue
                val h = header[i].lowercase(Locale.ROOT)
                if (kws.any { h.contains(it.lowercase(Locale.ROOT)) }) { used.add(i); return i }
            }
            return -1
        }

        /** تخمين الأعمدة من صف الرؤوس بالكلمات المفتاحية (نفس كلمات النسخة السابقة). */
        fun guess(header: List<String>?): ColMap {
            val m = ColMap()
            if (header == null) return m
            val used = HashSet<Int>()
            m.barcode = find(header, KW_BARCODE, used)
            m.itemNo = find(header, KW_ITEM, used)
            m.name = find(header, KW_NAME, used)
            m.priceOrig = find(header, KW_ORIG, used)
            m.priceSale = find(header, KW_SALE, used)
            return m
        }
    }
}
