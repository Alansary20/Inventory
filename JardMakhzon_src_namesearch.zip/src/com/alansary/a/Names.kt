package com.alansary.a

/** صنف معروف بالاسم (منتج أو صنف من الرصيد). key = رقم الصنف أو الباركود أو مفتاح الرصيد. */
class NameHit(val name: String, val itemNo: String, val barcode: String, val key: String, val tokens: Set<String>)

class NameIndex(val version: Long, private val byKey: HashMap<String, MutableList<NameHit>>, private val all: List<NameHit>) {
    /** تطابق تام في الكلمات (الترتيب لا يهم) ويكون وحيداً، وإلا null. */
    fun exact(q: String): NameHit? {
        val l = byKey[Codes.nameKey(q)]
        return if (l != null && l.size == 1) l[0] else null
    }

    /** نتيجة البحث: القائمة، وهل كلها تطابق كل الكلمات المكتوبة (full) أم هي أقرب النتائج فقط. */
    class Found(val list: List<NameHit>, val full: Boolean)

    /** كلمة المستخدم تطابق كلمة الصنف: بداية الكلمة أولاً، ثم أي جزء منها. */
    private fun tokMatch(q: String, t: String): Int = when {
        t == q -> 3
        t.startsWith(q) -> 2
        q.length >= 2 && t.contains(q) -> 1
        else -> 0
    }

    /** أصناف تحوي كل كلمات النص (ولو ناقصة الحروف)، فإن لم يوجد فالأكثر تطابقاً في الكلمات. */
    fun search(q: String, max: Int = 8): Found {
        val qt = Codes.normTokens(q).distinct()
        if (qt.isEmpty() || (qt.size == 1 && qt[0].length < 2)) return Found(emptyList(), true)
        byKey[qt.sorted().joinToString(" ")]?.let { return Found(it.take(max), true) }
        class Sc(val h: NameHit, val matched: Int, val score: Int)
        val scored = ArrayList<Sc>()
        for (h in all) {
            var m = 0; var sc = 0
            for (w in qt) {
                var best = 0
                for (t in h.tokens) { val v = tokMatch(w, t); if (v > best) best = v; if (best == 3) break }
                if (best > 0) { m++; sc += best }
            }
            if (m > 0) scored.add(Sc(h, m, sc))
        }
        val full = scored.filter { it.matched == qt.size }
        if (full.isNotEmpty())
            return Found(full.sortedWith(compareByDescending<Sc> { it.score }.thenBy { it.h.tokens.size }).take(max).map { it.h }, true)
        val need = maxOf(1, (qt.size + 1) / 2)
        val part = scored.filter { it.matched >= need }
            .sortedWith(compareByDescending<Sc> { it.matched }.thenByDescending { it.score }.thenBy { it.h.tokens.size })
        return Found(part.take(max).map { it.h }, false)
    }

    fun candidates(q: String, max: Int = 8): List<NameHit> = search(q, max).list
}

object Names {
    @Volatile private var cache: NameIndex? = null

    fun get(db: Db): NameIndex {
        val v = db.dataVersion
        cache?.let { if (it.version == v) return it }
        synchronized(this) {
            cache?.let { if (it.version == v) return it }
            val idx = build(db, v)
            cache = idx
            return idx
        }
    }

    private fun build(db: Db, version: Long): NameIndex {
        val prods = db.allProducts()
        val stock = db.allStock()
        val list = ArrayList<NameHit>(prods.size + stock.size)
        val codes = HashSet<String>()
        val nameKeyByCode = HashMap<String, String>()
        fun add(name: String, itemNo: String, barcode: String, key: String) {
            if (name.isBlank()) return
            list.add(NameHit(name, itemNo, barcode, key, Codes.normTokens(name).toSet()))
        }
        for (p in prods) {
            add(p.name, p.itemNo, p.barcode, p.itemNo.ifEmpty { p.barcode })
            if (p.itemNo.isNotEmpty()) codes.add(p.itemNo)
            if (p.barcode.isNotEmpty()) codes.add(p.barcode)
            codes.addAll(p.altList())
            val nk = Codes.nameKey(p.name)
            if (p.itemNo.isNotEmpty()) nameKeyByCode[p.itemNo] = nk
            if (p.barcode.isNotEmpty()) nameKeyByCode[p.barcode] = nk
        }
        // أصناف الرصيد التي ليس لها منتج
        for (s in stock) {
            val known = s.key in codes || (s.itemNo.isNotEmpty() && s.itemNo in codes) || (s.barcode.isNotEmpty() && s.barcode in codes)
            if (known) {
                // له منتج: نضيف اسمه في الرصيد فقط إن اختلف عن اسم المنتج (ليُعثر عليه بالاسمين)
                val pk = nameKeyByCode[s.key] ?: nameKeyByCode[s.itemNo] ?: nameKeyByCode[s.barcode]
                if (pk != null && pk != Codes.nameKey(s.name)) add(s.name, s.itemNo, s.barcode, s.key)
                continue
            }
            add(s.name, s.itemNo, s.barcode, s.key)
        }
        val byKey = HashMap<String, MutableList<NameHit>>(list.size * 2)
        for (h in list) byKey.getOrPut(h.tokens.sorted().joinToString(" ")) { ArrayList(1) }.add(h)
        return NameIndex(version, byKey, list)
    }
}
