package com.alansary.a

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.view.SurfaceView
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.FrameLayout

/**
 * إطار الكاميرا كما في الأصل: عرض حتى 340dp وارتفاع 280dp، زوايا مستديرة،
 * الصورة تملأ الإطار (قصّ من المنتصف) مع خط مسح أخضر متحرك.
 * ratioMode: الارتفاع = العرض × 3/4 بحد أقصى 260dp (ماسح الأسعار).
 */
class CameraBox(
    ctx: Context,
    private val maxWidthDp: Int,
    private val heightDp: Float,
    private val radiusDp: Float,
    private val maskColor: Int,
    private val ratioMode: Boolean = false
) : FrameLayout(ctx) {

    val surface = SurfaceView(ctx)
    private val overlay = Overlay(ctx)
    private var aspect = 4f / 3f          // ارتفاع/عرض للصورة القائمة على الشاشة

    init {
        setBackgroundColor(Color.BLACK)
        clipChildren = true
        addView(surface)
        addView(overlay)
    }

    fun setAspectRatio(a: Float) {
        if (a > 0f && Math.abs(a - aspect) > 0.001f) { aspect = a; requestLayout() }
    }

    private fun dp(v: Float) = Ui.dp(context, v)

    private var sw = 0
    private var sh = 0

    /** الجزء الظاهر من الصورة (نسبة العرض، نسبة الارتفاع) بعد القص المركزي. */
    fun visibleFrac(): FloatArray {
        if (sw <= 0 || sh <= 0 || measuredWidth <= 0) return floatArrayOf(1f, 1f)
        return floatArrayOf(minOf(1f, measuredWidth.toFloat() / sw), minOf(1f, measuredHeight.toFloat() / sh))
    }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val avail = MeasureSpec.getSize(wSpec)
        val w = minOf(avail, dp(maxWidthDp.toFloat()))
        val h = if (ratioMode) minOf((w * 0.75f).toInt(), dp(260f)) else dp(heightDp)
        setMeasuredDimension(w, h)
        // تغطية كاملة (cover): نكبّر الصورة حتى تملأ الإطار ثم نقصّ الزائد
        var cw = w
        var ch = (w * aspect).toInt()
        if (ch < h) { ch = h; cw = (h / aspect).toInt() }
        sw = cw; sh = ch
        surface.measure(MeasureSpec.makeMeasureSpec(cw, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(ch, MeasureSpec.EXACTLY))
        overlay.measure(MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY))
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val w = r - l
        val h = b - t
        val left = (w - sw) / 2
        val top = (h - sh) / 2
        surface.layout(left, top, left + sw, top + sh)
        overlay.layout(0, 0, w, h)
    }

    /** زوايا مستديرة (قناع بلون الخلفية) + خط مسح أخضر متحرك. */
    private inner class Overlay(c: Context) : View(c) {
        private val mask = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = maskColor; style = Paint.Style.FILL }
        private val line = Paint(Paint.ANTI_ALIAS_FLAG)
        private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
        private val path = Path()
        private var p = 0f
        private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1800
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { p = it.animatedValue as Float; invalidate() }
        }

        override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
            path.reset()
            path.fillType = Path.FillType.EVEN_ODD
            path.addRect(0f, 0f, w.toFloat(), h.toFloat(), Path.Direction.CW)
            val r = Ui.dp(context, radiusDp).toFloat()
            path.addRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), r, r, Path.Direction.CW)
            val g = LinearGradient(w * 0.10f, 0f, w * 0.90f, 0f,
                intArrayOf(0x0010B981, 0xFF10B981.toInt(), 0x0010B981), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
            line.shader = g; line.strokeWidth = Ui.dp(context, 2f).toFloat()
            glow.shader = g; glow.strokeWidth = Ui.dp(context, 7f).toFloat()
        }

        override fun onDraw(canvas: Canvas) {
            val w = width.toFloat(); val h = height.toFloat()
            val y = h * (0.15f + 0.67f * p)
            val a = (255 * (0.4f + 0.6f * p)).toInt()
            glow.alpha = (a * 0.30f).toInt(); line.alpha = a
            canvas.drawLine(w * 0.10f, y, w * 0.90f, y, glow)
            canvas.drawLine(w * 0.10f, y, w * 0.90f, y, line)
            canvas.drawPath(path, mask)
        }

        override fun onVisibilityChanged(changedView: View, visibility: Int) {
            super.onVisibilityChanged(changedView, visibility)
            updateAnim()
        }
        override fun onAttachedToWindow() { super.onAttachedToWindow(); updateAnim() }
        override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

        private fun updateAnim() {
            if (isShown && isAttachedToWindow) { if (!anim.isStarted) anim.start() } else anim.cancel()
        }
    }
}
