package com.alansary.a

import java.io.ByteArrayOutputStream
import java.io.File
import java.math.BigDecimal
import java.util.TreeMap

/**
 * قارئ ملفات Excel 97–2003 (.xls = OLE2 + BIFF8) بدون مكتبات خارجية.
 * يدعم: النصوص (SST/LABEL)، الأرقام (NUMBER/RK/MULRK)، نتائج الصيغ، القيم المنطقية، والأوراق المتعددة.
 */
object XlsReader {
    class Sheet(val name: String, val offset: Int)

    private class Eof : Exception()

    private fun u8(b: ByteArray, p: Int) = b[p].toInt() and 0xFF
    private fun u16(b: ByteArray, p: Int) = u8(b, p) or (u8(b, p + 1) shl 8)
    private fun i32(b: ByteArray, p: Int) = u8(b, p) or (u8(b, p + 1) shl 8) or (u8(b, p + 2) shl 16) or (u8(b, p + 3) shl 24)

    /** هل الملف حاوية OLE2 (xls القديم)؟ */
    fun isXls(file: File): Boolean = try {
        file.inputStream().use { i ->
            val h = ByteArray(8)
            i.read(h) == 8 && u8(h, 0) == 0xD0 && u8(h, 1) == 0xCF && u8(h, 2) == 0x11 && u8(h, 3) == 0xE0 &&
                u8(h, 4) == 0xA1 && u8(h, 5) == 0xB1 && u8(h, 6) == 0x1A && u8(h, 7) == 0xE1
        }
    } catch (_: Exception) { false }

    fun sheetNames(file: File): List<String> = load(file).sheets.map { it.name }

    fun read(file: File, sheetIndex: Int = 0): List<List<String>> {
        val wb = load(file)
        val sh = wb.sheets.getOrNull(sheetIndex) ?: wb.sheets.firstOrNull()
            ?: throw IllegalArgumentException("لا توجد ورقة بيانات في الملف")
        return parseSheet(wb.stream, sh.offset, wb.sst)
    }

    // ───────── حاوية OLE2 ─────────
    private fun workbookStream(all: ByteArray): ByteArray {
        if (all.size < 512) throw IllegalArgumentException("ملف .xls تالف")
        val ssh = u16(all, 0x1E); val mssh = u16(all, 0x20)
        if (ssh !in 7..16 || mssh !in 1..16) throw IllegalArgumentException("ملف .xls تالف")
        val ss = 1 shl ssh
        val mss = 1 shl mssh
        val dirStart = i32(all, 0x30)
        val cutoff = i32(all, 0x38)
        val miniStart = i32(all, 0x3C)
        val nDif = i32(all, 0x48)
        val difStart = i32(all, 0x44)
        fun off(id: Int): Long = (id.toLong() + 1) * ss

        val fatSecs = ArrayList<Int>()
        for (i in 0 until 109) { val v = i32(all, 0x4C + i * 4); if (v >= 0) fatSecs.add(v) }
        var d = difStart; var cnt = 0
        while (d >= 0 && cnt < nDif && cnt < 4096) {
            val o = off(d)
            if (o + ss > all.size) break
            for (i in 0 until ss / 4 - 1) { val v = i32(all, (o + i * 4).toInt()); if (v >= 0) fatSecs.add(v) }
            d = i32(all, (o + ss - 4).toInt()); cnt++
        }
        val per = ss / 4
        // حماية: لا يمكن أن يزيد عدد قطاعات FAT عمّا يتسع له الملف فعلاً
        if (per <= 0 || fatSecs.size.toLong() * per > all.size.toLong() * 4 + 4096) throw IllegalArgumentException("ملف .xls تالف")
        val fat = IntArray(fatSecs.size * per) { -1 }
        for ((k, sec) in fatSecs.withIndex()) {
            val o = off(sec)
            if (o + ss > all.size) continue
            for (i in 0 until per) fat[k * per + i] = i32(all, (o + i * 4).toInt())
        }

        fun chain(start: Int): ByteArray {
            val out = ByteArrayOutputStream()
            var id = start; var guard = 0
            while (id >= 0 && id < fat.size && guard++ <= fat.size) {
                val o = off(id)
                if (o >= all.size) break
                out.write(all, o.toInt(), minOf(ss.toLong(), all.size - o).toInt())
                id = fat[id]
            }
            return out.toByteArray()
        }

        val dir = chain(dirStart)
        var wbStart = -1; var wbSize = 0; var rootStart = -1; var rootSize = 0
        var e = 0
        while (e + 128 <= dir.size) {
            val nameLen = u16(dir, e + 0x40)
            val name = if (nameLen >= 2) String(dir, e, nameLen - 2, Charsets.UTF_16LE) else ""
            val type = u8(dir, e + 0x42)
            val start = i32(dir, e + 0x74); val size = i32(dir, e + 0x78)
            if (type == 5) { rootStart = start; rootSize = size }
            if (type == 2 && (name == "Workbook" || name == "Book") && wbStart < 0) { wbStart = start; wbSize = size }
            e += 128
        }
        if (wbStart < 0) throw IllegalArgumentException("ملف .xls غير مدعوم (لا يحتوي مصنف Excel)")
        if (wbSize < 0) wbSize = 0

        if (wbSize < cutoff) {
            val mini = chain(rootStart).let { if (rootSize in 0 until it.size) it.copyOf(rootSize) else it }
            val miniFatBytes = chain(miniStart)
            val miniFat = IntArray(miniFatBytes.size / 4) { i32(miniFatBytes, it * 4) }
            val out = ByteArrayOutputStream()
            var id = wbStart; var guard = 0
            while (id >= 0 && id < miniFat.size && guard++ <= miniFat.size) {
                val o = id * mss
                if (o >= mini.size) break
                out.write(mini, o, minOf(mss, mini.size - o))
                id = miniFat[id]
            }
            return out.toByteArray().let { if (it.size > wbSize) it.copyOf(wbSize) else it }
        }
        return chain(wbStart).let { if (it.size > wbSize) it.copyOf(wbSize) else it }
    }

    // ───────── مصنف BIFF8 ─────────
    private class Book(val stream: ByteArray, val sheets: List<Sheet>, val sst: List<String>)

    private fun load(file: File): Book {
        val s = workbookStream(file.readBytes())
        val sheets = ArrayList<Sheet>()
        var sst: List<String> = emptyList()
        var p = 0
        var first = true
        loop@ while (p + 4 <= s.size) {
            val id = u16(s, p); val len = u16(s, p + 2); val st = p + 4
            if (st + len > s.size) break
            when (id) {
                0x0809 -> if (first) {
                    first = false
                    if (len >= 2 && u16(s, st) < 0x0600)
                        throw IllegalArgumentException("ملف Excel قديم جدًا (قبل 97) غير مدعوم. احفظه بصيغة .xlsx")
                }
                0x002F -> throw IllegalArgumentException("الملف محمي بكلمة مرور، أزل الحماية ثم أعد المحاولة")
                0x0085 -> if (len >= 8 && u8(s, st + 5) == 0) {       // ورقة بيانات (لا مخطط)
                    val cch = u8(s, st + 6); val fl = u8(s, st + 7)
                    val nb = if (fl and 1 != 0) cch * 2 else cch
                    val name = if (st + 8 + nb <= s.size)
                        String(s, st + 8, nb, if (fl and 1 != 0) Charsets.UTF_16LE else Charsets.ISO_8859_1) else ""
                    sheets.add(Sheet(name.ifEmpty { "Sheet ${sheets.size + 1}" }, i32(s, st)))
                }
                0x00FC -> {
                    val segs = ArrayList<ByteArray>()
                    segs.add(s.copyOfRange(st, st + len))
                    var q = st + len
                    while (q + 4 <= s.size && u16(s, q) == 0x003C) {
                        val l = u16(s, q + 2)
                        if (q + 4 + l > s.size) break
                        segs.add(s.copyOfRange(q + 4, q + 4 + l)); q += 4 + l
                    }
                    sst = parseSst(segs)
                    p = q
                    continue@loop
                }
                0x000A -> break@loop
            }
            p = st + len
        }
        return Book(s, sheets, sst)
    }

    /** جدول النصوص المشتركة؛ قد تمتد النصوص عبر سجلات CONTINUE (وعندها يتكرر بايت الترميز). */
    private class Cur(val segs: List<ByteArray>) {
        var si = 0; var pos = 0
        fun more(): Boolean { if (si + 1 < segs.size) { si++; pos = 0; return true }; return false }
        fun avail() = segs[si].size - pos
        fun u8(): Int { while (pos >= segs[si].size) { if (!more()) throw Eof() }; return segs[si][pos++].toInt() and 0xFF }
        fun u16(): Int { val a = u8(); return a or (u8() shl 8) }
        fun i32(): Int { val a = u16(); return a or (u16() shl 16) }
        fun skip(n: Int) {
            var r = n
            while (r > 0) {
                if (pos >= segs[si].size) { if (!more()) return }
                val k = minOf(r, avail()); pos += k; r -= k
            }
        }
    }

    private fun parseSst(segs: List<ByteArray>): List<String> {
        val out = ArrayList<String>()
        try {
            val c = Cur(segs)
            c.i32(); val unique = c.i32()
            for (n in 0 until unique) {
                val cch = c.u16(); val fl = c.u8()
                val runs = if (fl and 8 != 0) c.u16() else 0
                val ext = if (fl and 4 != 0) c.i32() else 0
                var hi = fl and 1 != 0
                val sb = StringBuilder(cch)
                var left = cch
                while (left > 0) {
                    if (c.pos >= c.segs[c.si].size) {
                        if (!c.more()) throw Eof()
                        hi = (c.u8() and 1) != 0          // بداية جزء جديد: بايت ترميز جديد
                        continue
                    }
                    val unit = if (hi) 2 else 1
                    val k = minOf(left, c.avail() / unit)
                    if (k <= 0) { c.skip(1); continue }
                    val seg = c.segs[c.si]
                    sb.append(String(seg, c.pos, k * unit, if (hi) Charsets.UTF_16LE else Charsets.ISO_8859_1))
                    c.pos += k * unit; left -= k
                }
                c.skip(runs * 4 + maxOf(0, ext))
                out.add(sb.toString())
            }
        } catch (_: Eof) { /* نكتفي بما قُرئ */ }
        return out
    }

    // ───────── الورقة ─────────
    private fun numStr(d: Double): String {
        if (d.isNaN() || d.isInfinite()) return ""
        return try { BigDecimal(java.lang.Double.toString(d)).stripTrailingZeros().toPlainString() } catch (_: Exception) { d.toString() }
    }

    private fun rk(v: Int): Double {
        var d = if (v and 2 != 0) (v shr 2).toDouble()
        else java.lang.Double.longBitsToDouble((v.toLong() and 0xFFFFFFFCL) shl 32)
        if (v and 1 != 0) d /= 100.0
        return d
    }

    private fun xlString(s: ByteArray, p: Int, end: Int): String {
        if (p + 3 > end) return ""
        val cch = u16(s, p); val fl = u8(s, p + 2)
        var q = p + 3
        if (fl and 8 != 0) q += 2
        if (fl and 4 != 0) q += 4
        val hi = fl and 1 != 0
        val nb = minOf(if (hi) cch * 2 else cch, maxOf(0, end - q))
        return String(s, q, nb, if (hi) Charsets.UTF_16LE else Charsets.ISO_8859_1)
    }

    private fun parseSheet(s: ByteArray, offset: Int, sst: List<String>): List<List<String>> {
        val cells = TreeMap<Int, TreeMap<Int, String>>()
        fun put(r: Int, c: Int, v: String) { if (v.isNotEmpty()) cells.getOrPut(r) { TreeMap() }[c] = v }
        var p = offset; var depth = 0
        var pendR = -1; var pendC = -1
        loop@ while (p >= 0 && p + 4 <= s.size) {
            val id = u16(s, p); val len = u16(s, p + 2); val st = p + 4
            if (st + len > s.size) break
            when (id) {
                0x0809 -> depth++
                0x000A -> { depth--; if (depth <= 0) break@loop }
                0x00FD -> if (len >= 10) put(u16(s, st), u16(s, st + 2), sst.getOrElse(i32(s, st + 6)) { "" })
                0x0204 -> if (len >= 9) put(u16(s, st), u16(s, st + 2), xlString(s, st + 6, st + len))
                0x0203 -> if (len >= 14) put(u16(s, st), u16(s, st + 2),
                    numStr(java.lang.Double.longBitsToDouble(i32(s, st + 6).toLong() and 0xFFFFFFFFL or (i32(s, st + 10).toLong() shl 32))))
                0x027E -> if (len >= 10) put(u16(s, st), u16(s, st + 2), numStr(rk(i32(s, st + 6))))
                0x00BD -> if (len >= 6) {
                    val r = u16(s, st); val c1 = u16(s, st + 2)
                    val n = (len - 6) / 6
                    for (i in 0 until n) put(r, c1 + i, numStr(rk(i32(s, st + 4 + i * 6 + 2))))
                }
                0x0006 -> if (len >= 14) {
                    val r = u16(s, st); val c = u16(s, st + 2)
                    if (u16(s, st + 12) == 0xFFFF) {
                        when (u8(s, st + 6)) {
                            0 -> { pendR = r; pendC = c }
                            1 -> put(r, c, if (u8(s, st + 8) != 0) "TRUE" else "FALSE")
                        }
                    } else {
                        put(r, c, numStr(java.lang.Double.longBitsToDouble(
                            i32(s, st + 6).toLong() and 0xFFFFFFFFL or (i32(s, st + 10).toLong() shl 32))))
                    }
                }
                0x0207 -> if (pendR >= 0) { put(pendR, pendC, xlString(s, st, st + len)); pendR = -1 }
                0x0205 -> if (len >= 8 && u8(s, st + 7) == 0) put(u16(s, st), u16(s, st + 2), if (u8(s, st + 6) != 0) "TRUE" else "FALSE")
            }
            p = st + len
        }
        val rows = ArrayList<List<String>>()
        for ((_, m) in cells) {
            val row = ArrayList<String>()
            for ((c, v) in m) { while (row.size < c) row.add(""); row.add(v) }
            while (row.isNotEmpty() && row.last().isBlank()) row.removeAt(row.size - 1)
            if (row.isNotEmpty()) rows.add(row)
        }
        return rows
    }
}
