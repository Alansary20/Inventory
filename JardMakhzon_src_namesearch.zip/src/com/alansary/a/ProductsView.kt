package com.alansary.a

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AbsListView
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import com.alansary.a.ColumnDetector.Kind
import java.util.Locale

/** تبويب المنتجات: رفع Excel/CSV، بحث، إضافة وتعديل وحذف، دمج المكرر، مسح الكل، تصدير. */
class ProductsView(
    private val act: Activity,
    private val t: Theme,
    private val onChanged: () -> Unit
) : FrameLayout(act) {

    private val db = Db.get(act)
    private val ui = Handler(Looper.getMainLooper())
    private val items = ArrayList<Product>()
    private val list = StillListView(act)
    private val adapter = CardAdapter()

    private var query = ""
    private var token = 0
    private var loading = false
    private var endReached = false

    private var merge = false
    private val files = ArrayList<ProductImporter.Source>()

    private lateinit var fileBtn: TextView
    private lateinit var modeUpdate: TextView
    private lateinit var modeMerge: TextView
    private lateinit var modeDesc: TextView
    private lateinit var countText: TextView
    private lateinit var emptyText: TextView

    init {
        list.divider = null
        list.dividerHeight = 0
        list.setSelector(android.R.color.transparent)
        list.isVerticalScrollBarEnabled = false      // بدون شريط التمرير الرمادي
        list.overScrollMode = View.OVER_SCROLL_NEVER
        list.itemsCanFocus = true
        list.addHeaderView(buildHeader(), null, false)
        list.adapter = adapter
        list.setOnScrollListener(object : AbsListView.OnScrollListener {
            override fun onScrollStateChanged(v: AbsListView, s: Int) {}
            override fun onScroll(v: AbsListView, first: Int, visible: Int, totalCount: Int) {
                if (first + visible >= totalCount - 10) loadMore()
            }
        })
        addView(list, LayoutParams(-1, -1))
        reload()
    }

    private fun s(id: Int) = act.getString(id)
    private fun fmtS(id: Int, vararg a: Any) = String.format(Locale.US, act.getString(id), *a)
    private fun toast(m: String) = Toast.makeText(act, m, Toast.LENGTH_LONG).show()
    /** تنفيذ في خيط خلفي؛ أي خطأ غير متوقع يظهر كرسالة بدل أن يُغلق التطبيق. */
    private fun bg(block: () -> Unit) = Thread {
        try { block() } catch (e: Exception) {
            ui.post { toast(fmtS(R.string.op_error, e.message ?: e.javaClass.simpleName)) }
        }
    }.start()

    // ───────── الواجهة ─────────
    private fun buildHeader(): View {
        val c: Context = act
        val h = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        Ui.pad(h, c, 12f, 6f, 12f, 6f)

        val card = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.rounded(c, t.surface2, t.border, 20f)
        }
        Ui.pad(card, c, 14f, 14f, 14f, 14f)
        h.addView(card, Ui.margin(Ui.lp(-1, -2), c, 0f, 4f, 0f, 10f))
        card.addView(Ui.text(c, s(R.string.upload_products), 16f, t.text, true))

        fileBtn = Ui.button(c, s(R.string.choose_file), t.accent, false) { pickFiles() }
        card.addView(fileBtn, Ui.margin(Ui.lp(-1, -2), c, 0f, 10f, 0f, 0f))

        val modes = LinearLayout(c)
        modeUpdate = chip(s(R.string.mode_update)) { setMode(false) }
        modeMerge = chip(s(R.string.mode_merge)) { setMode(true) }
        modes.addView(modeUpdate, Ui.margin(Ui.lp(-2, -2), c, 0f, 0f, 8f, 0f))
        modes.addView(modeMerge, Ui.lp(-2, -2))
        card.addView(modes, Ui.margin(Ui.lp(-2, -2), c, 0f, 10f, 0f, 0f))

        modeDesc = Ui.text(c, "", 12f, t.muted)
        card.addView(modeDesc, Ui.margin(Ui.lp(-1, -2), c, 0f, 6f, 0f, 0f))
        setMode(false)

        card.addView(Ui.button(c, s(R.string.process_products), t.accent, true) { startMapping() },
            Ui.margin(Ui.lp(-1, Ui.dp(c, 50)), c, 0f, 10f, 0f, 0f))

        val r1 = LinearLayout(c)
        r1.addView(Ui.button(c, s(R.string.export_products), t.accent, false) { startExport() },
            Ui.margin(Ui.lpWeight(1f), c, 0f, 0f, 4f, 0f))
        r1.addView(Ui.button(c, s(R.string.add_product), t.accent, false) { showEdit(Product()) },
            Ui.margin(Ui.lpWeight(1f), c, 4f, 0f, 0f, 0f))
        h.addView(r1, Ui.margin(Ui.lp(-1, -2), c, 0f, 0f, 0f, 8f))

        val r2 = LinearLayout(c)
        r2.addView(Ui.button(c, s(R.string.dedupe_products), t.accent, false) { dedupe() },
            Ui.margin(Ui.lpWeight(1f), c, 0f, 0f, 4f, 0f))
        r2.addView(Ui.button(c, s(R.string.clear_products), t.danger, false) { confirmClear() },
            Ui.margin(Ui.lpWeight(1f), c, 4f, 0f, 0f, 0f))
        h.addView(r2, Ui.margin(Ui.lp(-1, -2), c, 0f, 0f, 0f, 10f))

        val search = EditText(c).apply {
            hint = s(R.string.search_hint)
            setHintTextColor(t.muted)
            setTextColor(t.text)
            textSize = 14f
            isSingleLine = true
            background = Ui.rounded(c, t.surface2, t.border, 16f)
            minHeight = Ui.dp(c, 48f)
        }
        Ui.pad(search, c, 14f, 0f, 14f, 0f)
        val apply = Runnable { reload() }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(a: CharSequence?, b: Int, d: Int, e: Int) {}
            override fun onTextChanged(a: CharSequence?, b: Int, d: Int, e: Int) {}
            override fun afterTextChanged(ed: Editable?) {
                query = ed?.toString()?.trim() ?: ""
                ui.removeCallbacks(apply)
                ui.postDelayed(apply, if (query.isEmpty()) 0L else 250L)
            }
        })
        h.addView(search, Ui.lp(-1, -2))

        countText = Ui.text(c, "", 16f, t.text, true)
        h.addView(countText, Ui.margin(Ui.lp(-1, -2), c, 0f, 14f, 0f, 4f))

        emptyText = Ui.text(c, s(R.string.no_products), 14f, t.muted)
        emptyText.gravity = Gravity.CENTER
        Ui.pad(emptyText, c, 0f, 28f, 0f, 28f)
        h.addView(emptyText, Ui.lp(-1, -2))
        return h
    }

    private fun chip(label: String, r: () -> Unit): TextView {
        val tv = Ui.button(act, label, t.accent, false, r)
        tv.minHeight = Ui.dp(act, 40f)
        Ui.pad(tv, act, 18f, 0f, 18f, 0f)
        return tv
    }

    private fun setMode(m: Boolean) {
        merge = m
        styleChip(modeUpdate, !m)
        styleChip(modeMerge, m)
        modeDesc.text = s(if (m) R.string.mode_merge_desc else R.string.mode_update_desc)
    }

    private fun styleChip(tv: TextView, selected: Boolean) {
        tv.setTextColor(if (selected) t.accent else t.muted)
        tv.background = Ui.rounded(act, if (selected) Theme.alpha(t.accent, 0.18f) else t.surface2,
            if (selected) Theme.alpha(t.accent, 0.5f) else t.border, 14f)
    }

    // ───────── تحميل القائمة (صفحات) ─────────
    private fun reload() {
        token++
        items.clear()
        adapter.notifyDataSetChanged()
        endReached = false
        loading = false
        val tok = token
        bg {
            val n = db.countProducts()
            ui.post { if (tok == token) countText.text = fmtS(R.string.products_count, n) }
        }
        loadMore()
    }

    private fun loadMore() {
        if (loading || endReached) return
        loading = true
        val tok = token
        val offset = items.size
        val q = query
        bg {
            val page = db.searchProducts(q, PAGE, offset)
            ui.post {
                if (tok == token) {
                    items.addAll(page)
                    if (page.size < PAGE) endReached = true
                    loading = false
                    emptyText.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
                    adapter.notifyDataSetChanged()
                }
            }
        }
    }

    private fun changed() { reload(); onChanged() }

    private fun fmt(d: Double): String =
        if (d % 1.0 == 0.0) d.toLong().toString() else String.format(Locale.US, "%.2f", d)

    private inner class CardAdapter : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(i: Int): Any = items[i]
        override fun getItemId(i: Int) = i.toLong()

        override fun getView(i: Int, convert: View?, parent: ViewGroup?): View {
            val c: Context = act
            val wrap: FrameLayout
            val card: LinearLayout
            if (convert == null) {
                wrap = FrameLayout(c)
                Ui.pad(wrap, c, 12f, 5f, 12f, 5f)
                card = LinearLayout(c).apply {
                    orientation = LinearLayout.VERTICAL
                    background = Ui.rounded(c, t.surface, t.border, 16f)
                }
                Ui.pad(card, c, 12f, 12f, 12f, 12f)
                wrap.addView(card, FrameLayout.LayoutParams(-1, -2))
            } else {
                wrap = convert as FrameLayout
                card = wrap.getChildAt(0) as LinearLayout
            }
            card.removeAllViews()
            val p = items[i]
            card.addView(Ui.text(c, p.name, 15f, t.text, true))
            if (p.barcode.isNotEmpty()) card.addView(Ui.text(c, s(R.string.f_barcode) + ": " + p.barcode, 12f, t.muted))
            if (p.itemNo.isNotEmpty()) card.addView(Ui.text(c, s(R.string.f_itemno) + ": " + p.itemNo, 12f, t.muted))
            if (p.priceOrig != 0.0 || p.priceSale != 0.0) {
                val row = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL }
                row.addView(Ui.text(c, fmt(if (p.priceSale != 0.0) p.priceSale else p.priceOrig), 14f, t.accent, true),
                    Ui.margin(Ui.lp(-2, -2), c, 0f, 0f, 10f, 0f))
                if (p.priceOrig != 0.0 && p.priceSale != 0.0 && p.priceOrig != p.priceSale) {
                    row.addView(Ui.text(c, fmt(p.priceOrig), 12f, t.muted).apply {
                        paintFlags = paintFlags or android.graphics.Paint.STRIKE_THRU_TEXT_FLAG
                    }, Ui.margin(Ui.lp(-2, -2), c, 0f, 0f, 10f, 0f))
                    val pct = Math.round((1 - p.priceSale / p.priceOrig) * 100).toInt()
                    row.addView(Ui.text(c, if (pct >= 0) "-$pct%" else "+${-pct}%", 11f, t.danger, true))
                }
                card.addView(row)
            }
            card.setOnClickListener { showEdit(p) }
            return wrap
        }
    }

    // ───────── الحوارات ─────────
    private fun showEdit(p: Product) { ProductEditor.show(act, t, db, p) { changed() } }

    private fun confirmClear() {
        CardDialog(act, t)
            .title(s(R.string.clear_products), R.drawable.ic_dlg_trash, danger = true)
            .message(s(R.string.clear_confirm))
            .button(s(R.string.delete), CardDialog.Kind.DANGER) {
                bg { db.clearProducts(); ui.post { toast(s(R.string.clear_done)); changed() } }
            }
            .button(s(R.string.cancel))
            .show()
    }

    private fun dedupe() {
        bg {
            val removed = ProductImporter(act).dedupe()
            ui.post { toast(fmtS(R.string.dedupe_done, removed)); changed() }
        }
    }

    // ───────── اختيار الملفات والاستيراد ─────────
    private fun pickFiles() {
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        act.startActivityForResult(i, REQ_PICK)
    }

    private fun startExport() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        i.putExtra(Intent.EXTRA_TITLE, Exports.fileName(act, "prods"))
        act.startActivityForResult(i, REQ_EXPORT)
    }

    fun onActivityResult(req: Int, result: Int, data: Intent?) {
        if (result != Activity.RESULT_OK || data == null) return
        if (req == REQ_PICK) {
            val uris = ArrayList<Uri>()
            val clip = data.clipData
            if (clip != null) for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri)
            else data.data?.let { uris.add(it) }
            files.clear()
            uris.forEach { files.add(ProductImporter.Source(it, TableReader.fileName(act, it))) }
            fileBtn.text = if (files.isEmpty()) s(R.string.choose_file) else fmtS(R.string.files_selected, files.size)
        } else if (req == REQ_EXPORT) {
            data.data?.let { doExport(it) }
        }
    }

    private fun doExport(uri: Uri) {
        bg {
            val msg = try {
                val os = act.contentResolver.openOutputStream(uri, "wt") ?: throw IllegalStateException("output")
                val n = os.use { Exports.products(act, db, it) }
                fmtS(R.string.export_done, n)
            } catch (e: Exception) {
                fmtS(R.string.export_failed, e.message ?: "")
            }
            ui.post { toast(msg) }
        }
    }

    private fun startMapping() {
        if (files.isEmpty()) { toast(s(R.string.choose_file_first)); return }
        val first = files[0]
        SheetPicker.ensure(act, t, files.map { it.uri }) {
            bg {
                try {
                    val rows = TableReader.read(act, first.uri)
                    ui.post { if (rows.isEmpty()) toast(s(R.string.empty_file)) else showColMap(rows.take(30)) }
                } catch (e: Exception) {
                    ui.post { toast(fmtS(R.string.read_error, e.message ?: "")) }
                }
            }
        }
    }

    private fun letter(i: Int): String {
        val sb = StringBuilder()
        var n = i
        do { sb.append('A' + (n % 26)); n = n / 26 - 1 } while (n >= 0)
        return sb.reverse().toString()
    }

    private inner class ColorAdapter(c: Context, data: List<String>) :
        ArrayAdapter<String>(c, android.R.layout.simple_spinner_item, data) {
        override fun getView(pos: Int, v: View?, parent: ViewGroup): View {
            val tv = super.getView(pos, v, parent) as TextView
            tv.setTextColor(t.text); tv.isSingleLine = true; tv.ellipsize = TextUtils.TruncateAt.END
            return tv
        }
        override fun getDropDownView(pos: Int, v: View?, parent: ViewGroup): View {
            val tv = super.getDropDownView(pos, v, parent) as TextView
            tv.setTextColor(t.text); tv.setBackgroundColor(t.surface); tv.isSingleLine = true
            Ui.pad(tv, act, 14f, 12f, 14f, 12f)
            return tv
        }
    }

    private fun showColMap(rows: List<List<String>>) {
        val colCount = rows.maxOf { it.size }
        val header = rows[0]
        val det = ColumnDetector.detect(rows, listOf(Kind.BARCODE, Kind.ITEM_NO, Kind.NAME, Kind.PRICE_ORIG, Kind.PRICE_SALE))

        val box = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        box.addView(Ui.text(act, files.joinToString(", ") { it.name }, 12f, t.muted))

        val noHeader = CheckBox(act).apply { setText(R.string.no_header); setTextColor(t.text); isChecked = !det.hasHeader }
        box.addView(noHeader)
        val pv = LinearLayout(act)
        box.addView(pv, Ui.margin(Ui.lp(-1, -2), act, 0f, 6f, 0f, 4f))
        val paintPv = { pv.removeAllViews(); pv.addView(ColDialog.preview(act, t, rows, !noHeader.isChecked), Ui.lp(-1, -2)) }
        paintPv()

        val labelsLetters = (0 until colCount).map { fmtS(R.string.col_letter, letter(it)) }
        val labelsHeader = (0 until colCount).map { i ->
            val h = header.getOrNull(i)?.trim().orEmpty()
            if (h.isEmpty()) labelsLetters[i] else "$h  (${letter(i)})"
        }

        val labelIds = intArrayOf(R.string.f_barcode, R.string.f_itemno, R.string.f_name, R.string.f_price_orig, R.string.f_price_sale)
        val guessIdx = intArrayOf(det.col(Kind.BARCODE), det.col(Kind.ITEM_NO), det.col(Kind.NAME), det.col(Kind.PRICE_ORIG), det.col(Kind.PRICE_SALE))
        val sp = Array(5) { k ->
            box.addView(Ui.text(act, s(labelIds[k]), 12f, t.muted), Ui.margin(Ui.lp(-1, -2), act, 0f, 10f, 0f, 2f))
            Spinner(act).also {
                it.background = Ui.rounded(act, t.surface2, t.border, 12f)
                box.addView(it, Ui.lp(-1, Ui.dp(act, 46f)))
            }
        }
        val fill = {
            val labels = if (noHeader.isChecked) labelsLetters else labelsHeader
            for (k in 0 until 5) {
                val keep = sp[k].selectedItemPosition
                val data = listOf(s(R.string.col_none)) + labels
                sp[k].adapter = ColorAdapter(act, data)
                if (keep >= 0) sp[k].setSelection(minOf(keep, data.size - 1))
            }
        }
        fill()
        for (k in 0 until 5) sp[k].setSelection(if (guessIdx[k] >= 0) guessIdx[k] + 1 else 0)
        noHeader.setOnCheckedChangeListener { _, _ -> fill(); paintPv() }

        val cd = CardDialog(act, t).title(s(R.string.col_map_title), R.drawable.ic_dlg_upload).content(box, scroll = true)
        cd.button(s(R.string.confirm_process), CardDialog.Kind.PRIMARY, dismiss = false) {
            val m = ColMap()
            m.noHeader = noHeader.isChecked
            m.barcode = sp[0].selectedItemPosition - 1
            m.itemNo = sp[1].selectedItemPosition - 1
            m.name = sp[2].selectedItemPosition - 1
            m.priceOrig = sp[3].selectedItemPosition - 1
            m.priceSale = sp[4].selectedItemPosition - 1
            if (m.barcode < 0 && m.itemNo < 0) { toast(s(R.string.select_barcode_or_item)) }
            else { cd.dismiss(); runImport(m) }
        }
        cd.button(s(R.string.cancel))
        cd.show()
    }


    private fun runImport(map: ColMap) {
        val box = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        val bar = ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal).apply { max = 1000 }
        box.addView(bar, Ui.lp(-1, -2))
        val label = Ui.text(act, s(R.string.uploading), 12f, t.muted)
        box.addView(label, Ui.margin(Ui.lp(-1, -2), act, 0f, 10f, 0f, 0f))
        val dlg = CardDialog(act, t).title(s(R.string.uploading), R.drawable.ic_dlg_upload).content(box).cancelable(false).show()

        val srcs = ArrayList(files)
        val mergeMode = merge
        bg {
            val msg = try {
                val r = ProductImporter(act).run(srcs, map, mergeMode, s(R.string.no_name)) { f, l ->
                    ui.post {
                        bar.progress = Math.round(f * 1000)
                        if (l.isNotEmpty()) label.text = l
                    }
                }
                db.reconcile(unknownLabels(act))
                fmtS(if (mergeMode) R.string.import_done_merge else R.string.import_done, r.added, r.updated, r.skipped)
            } catch (e: Exception) {
                fmtS(R.string.read_error, e.message ?: "")
            }
            ui.post {
                try { dlg.dismiss() } catch (_: Exception) {}   // قد تكون النافذة أُغلقت مع الـActivity
                files.clear()
                fileBtn.text = s(R.string.choose_file)
                changed()
                toast(msg)
            }
        }
    }

    companion object {
        const val REQ_PICK = 101
        const val REQ_EXPORT = 102
        private const val PAGE = 50
    }
}
