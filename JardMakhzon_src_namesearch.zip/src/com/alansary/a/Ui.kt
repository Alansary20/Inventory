package com.alansary.a

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

object Ui {
    fun dp(c: Context, v: Float): Int =
        Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, c.resources.displayMetrics))

    fun dp(c: Context, v: Int): Int = dp(c, v.toFloat())

    fun rounded(c: Context, fill: Int, stroke: Int, radiusDp: Float): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(c, radiusDp).toFloat()
            if (stroke != 0) setStroke(dp(c, 1f), stroke)
        }

    fun text(c: Context, s: CharSequence, sp: Float, color: Int, bold: Boolean = false): TextView =
        TextView(c).apply {
            text = s
            setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            // نسخ النص بالضغط المطوّل، مع إبقاء نقرة الصف الأصلية تعمل
            setOnLongClickListener { copy(c, this.text.toString()); true }
            setOnClickListener { forwardClick(this) }
        }

    fun lp(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)

    fun lpWeight(weight: Float) = LinearLayout.LayoutParams(0, -2, weight)

    fun pad(v: View, c: Context, l: Float, t: Float, r: Float, b: Float) {
        v.setPadding(dp(c, l), dp(c, t), dp(c, r), dp(c, b))
    }

    fun margin(p: LinearLayout.LayoutParams, c: Context, l: Float, t: Float, r: Float, b: Float):
        LinearLayout.LayoutParams {
        // l = جهة البداية، r = جهة النهاية (تعمل صحيحة في RTL وLTR)
        p.setMargins(0, dp(c, t), 0, dp(c, b))
        p.marginStart = dp(c, l)
        p.marginEnd = dp(c, r)
        return p
    }

    /** زر بحواف مدورة. filled=true: خلفية خضراء ونص أبيض، وإلا حدود فقط. */
    fun button(c: Context, label: CharSequence, color: Int, filled: Boolean, onClick: () -> Unit): TextView =
        TextView(c).apply {
            text = label
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            gravity = Gravity.CENTER
            isSingleLine = true
            ellipsize = TextUtils.TruncateAt.END
            setTypeface(typeface, Typeface.BOLD)
            pad(this, c, 10f, 0f, 10f, 0f)
            minHeight = dp(c, 48f)
            if (filled) {
                setTextColor(0xFFFFFFFF.toInt())
                background = rounded(c, color, 0, 14f)
            } else {
                setTextColor(color)
                background = rounded(c, Theme.alpha(color, 0.06f), Theme.alpha(color, 0.5f), 14f)
            }
            isClickable = true
            setOnClickListener { onClick() }
        }

    fun qty(d: Double): String =
        if (d % 1.0 == 0.0) d.toLong().toString() else String.format(java.util.Locale.US, "%.2f", d)

    /** يمرّر النقر القصير إلى أقرب أب له مستمع نقر (صف المنتج، التبويب...). */
    fun forwardClick(v: View) {
        var p = v.parent
        while (p is View) {
            if (p.hasOnClickListeners()) { p.performClick(); return }
            p = p.parent
        }
    }

    /** ينسخ النص للحافظة (بدون الرمز التعبيري الذي في أوله). */
    fun copy(c: Context, raw: String) {
        val txt = raw.replace(Regex("^[\\p{So}\\p{Sk}\\uFE0F\\u200D\\s]+"), "").trim()
        if (txt.isEmpty() || txt == "—") return
        try {
            val cm = c.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("text", txt))
            // أندرويد 13+ يعرض تأكيده الخاص
            if (android.os.Build.VERSION.SDK_INT < 33)
                android.widget.Toast.makeText(c, c.getString(R.string.copied) + ": " + txt.take(40), android.widget.Toast.LENGTH_SHORT).show()
        } catch (_: Exception) {}
    }
}
