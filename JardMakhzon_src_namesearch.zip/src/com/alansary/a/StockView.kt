package com.alansary.a

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

/** تبويب الرصيد: رفع ملف الرصيد الفعلي (تحديث/دمج)، تصدير، وعرض الأصناف. */
private val ZEROS_RE = Regex("\\.0+$")

class StockView(
    private val act: Activity,
    private val t: Theme,
    private val onChanged: () -> Unit
) : FrameLayout(act) {

    private val db = Db.get(act)
    private val ui = Handler(Looper.getMainLooper())
    private val items = ArrayList<StockRow>()
    private val list = StillListView(act)
    private val adapter = RowAdapter()
    private var query = ""
    private var token = 0
    private var loading = false
    private var endReached = false

    private var merge = false
    private val files = ArrayList<ProductImporter.Source>()
    private lateinit var fileBtn: TextView
    private lateinit var modeUpdate: TextView
    private lateinit var modeMerge: TextView
    private lateinit var modeDesc: TextView
    private lateinit var countText: TextView
    private lateinit var emptyText: TextView

    init {
        list.divider = null
        list.dividerHeight = 0
        list.setSelector(android.R.color.transparent)
        list.isVerticalScrollBarEnabled = false
        list.overScrollMode = View.OVER_SCROLL_NEVER
        list.itemsCanFocus = true
        list.addHeaderView(buildHeader(), null, false)
        list.adapter = adapter
        list.setOnScrollListener(object : AbsListView.OnScrollListener {
            override fun onScrollStateChanged(v: AbsListView, s: Int) {}
            override fun onScroll(v: AbsListView, first: Int, visible: Int, total: Int) {
                if (first + visible >= total - 10) loadMore()
            }
        })
        addView(list, LayoutParams(-1, -1))
        reload()
    }

    private fun s(id: Int) = act.getString(id)
    private fun fmtS(id: Int, vararg a: Any) = String.format(Locale.US, act.getString(id), *a)
    private fun toast(m: String) = Toast.makeText(act, m, Toast.LENGTH_LONG).show()
    /** تنفيذ في خيط خلفي؛ أي خطأ غير متوقع يظهر كرسالة بدل أن يُغلق التطبيق. */
    private fun bg(block: () -> Unit) = Thread {
        try { block() } catch (e: Exception) {
            ui.post { toast(fmtS(R.string.op_error, e.message ?: e.javaClass.simpleName)) }
        }
    }.start()

    private fun buildHeader(): View {
        val c: Context = act
        val h = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        Ui.pad(h, c, 12f, 6f, 12f, 6f)
        val card = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.rounded(c, t.surface2, t.border, 20f)
        }
        Ui.pad(card, c, 14f, 14f, 14f, 14f)
        h.addView(card, Ui.margin(Ui.lp(-1, -2), c, 0f, 4f, 0f, 10f))
        card.addView(Ui.text(c, s(R.string.stock_upload_title), 16f, t.text, true))

        fileBtn = Ui.button(c, s(R.string.choose_stock_file), t.accent, false) { pickFiles() }
        card.addView(fileBtn, Ui.margin(Ui.lp(-1, -2), c, 0f, 10f, 0f, 0f))

        val modes = LinearLayout(c)
        modeUpdate = chip(s(R.string.mode_update)) { setMode(false) }
        modeMerge = chip(s(R.string.mode_merge)) { setMode(true) }
        modes.addView(modeUpdate, Ui.margin(Ui.lp(-2, -2), c, 0f, 0f, 8f, 0f))
        modes.addView(modeMerge, Ui.lp(-2, -2))
        card.addView(modes, Ui.margin(Ui.lp(-2, -2), c, 0f, 10f, 0f, 0f))
        modeDesc = Ui.text(c, "", 12f, t.muted)
        card.addView(modeDesc, Ui.margin(Ui.lp(-1, -2), c, 0f, 6f, 0f, 0f))
        setMode(false)

        card.addView(Ui.button(c, s(R.string.process_stock), t.accent, true) { startMapping() },
            Ui.margin(Ui.lp(-1, Ui.dp(c, 50f)), c, 0f, 10f, 0f, 0f))
        h.addView(Ui.button(c, s(R.string.export_stock), t.accent, false) { startExport() },
            Ui.margin(Ui.lp(-1, -2), c, 0f, 0f, 0f, 10f))

        val search = EditText(c).apply {
            hint = "🔍  " + s(R.string.search_hint)
            setHintTextColor(t.muted); setTextColor(t.text); textSize = 14f
            isSingleLine = true
            background = Ui.rounded(c, t.surface2, t.border, 16f)
            minHeight = Ui.dp(c, 48f)
        }
        Ui.pad(search, c, 14f, 0f, 14f, 0f)
        val apply = Runnable { reload() }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(a: CharSequence?, b: Int, d: Int, e: Int) {}
            override fun onTextChanged(a: CharSequence?, b: Int, d: Int, e: Int) {}
            override fun afterTextChanged(ed: Editable?) {
                query = ed?.toString()?.trim() ?: ""
                ui.removeCallbacks(apply)
                ui.postDelayed(apply, if (query.isEmpty()) 0L else 250L)
            }
        })
        h.addView(search, Ui.lp(-1, -2))
        countText = Ui.text(c, "", 16f, t.text, true)
        h.addView(countText, Ui.margin(Ui.lp(-1, -2), c, 0f, 14f, 0f, 4f))
        emptyText = Ui.text(c, s(R.string.no_stock), 14f, t.muted).apply { gravity = Gravity.CENTER }
        Ui.pad(emptyText, c, 0f, 28f, 0f, 28f)
        h.addView(emptyText, Ui.lp(-1, -2))
        return h
    }

    private fun chip(label: String, r: () -> Unit): TextView {
        val tv = Ui.button(act, label, t.accent, false, r)
        tv.minHeight = Ui.dp(act, 40f)
        Ui.pad(tv, act, 18f, 0f, 18f, 0f)
        return tv
    }

    private fun setMode(m: Boolean) {
        merge = m
        styleChip(modeUpdate, !m)
        styleChip(modeMerge, m)
        modeDesc.text = s(if (m) R.string.stock_mode_merge_desc else R.string.stock_mode_update_desc)
    }

    private fun styleChip(tv: TextView, selected: Boolean) {
        tv.setTextColor(if (selected) t.accent else t.muted)
        tv.background = Ui.rounded(act, if (selected) Theme.alpha(t.accent, 0.18f) else t.surface2,
            if (selected) Theme.alpha(t.accent, 0.5f) else t.border, 14f)
    }

    // ───────── القائمة ─────────
    fun refresh() { reload() }

    private fun reload() {
        token++
        items.clear()
        adapter.notifyDataSetChanged()
        endReached = false
        loading = false
        val tok = token
        bg {
            val n = db.countStock()
            ui.post { if (tok == token) countText.text = fmtS(R.string.stock_count, n) }
        }
        loadMore()
    }

    private fun loadMore() {
        if (loading || endReached) return
        loading = true
        val tok = token
        val offset = items.size
        val q = query
        bg {
            val page = db.searchStock(q, PAGE, offset)
            ui.post {
                if (tok == token) {
                    items.addAll(page)
                    if (page.size < PAGE) endReached = true
                    loading = false
                    emptyText.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
                    adapter.notifyDataSetChanged()
                }
            }
        }
    }

    private inner class RowAdapter : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(i: Int): Any = items[i]
        override fun getItemId(i: Int) = i.toLong()
        override fun getView(i: Int, convert: View?, parent: ViewGroup?): View {
            val c: Context = act
            val r = items[i]
            val qtyColor = if (r.qty == 0.0) t.danger else if (r.qty <= 5) 0xFFF59E0B.toInt() else t.accent
            val wrap = FrameLayout(c)
            Ui.pad(wrap, c, 12f, 4f, 12f, 4f)
            val row = LinearLayout(c).apply {
                gravity = Gravity.CENTER_VERTICAL
                background = Ui.rounded(c, t.surface2, t.border, 12f)
            }
            Ui.pad(row, c, 12f, 10f, 12f, 10f)
            val info = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
            info.addView(Ui.text(c, r.name.ifEmpty { "—" }, 13f, t.text, true).apply {
                isSingleLine = true; ellipsize = TextUtils.TruncateAt.END
            })
            info.addView(Ui.text(c, r.key, 10f, t.muted))
            row.addView(info, Ui.margin(Ui.lpWeight(1f), c, 0f, 0f, 8f, 0f))
            val q = Ui.text(c, Ui.qty(r.qty), 16f, qtyColor, true).apply {
                gravity = Gravity.CENTER
                background = Ui.rounded(c, Theme.alpha(qtyColor, 0.12f), Theme.alpha(qtyColor, 0.35f), 10f)
                minWidth = Ui.dp(c, 44f)
            }
            Ui.pad(q, c, 10f, 6f, 10f, 6f)
            row.addView(q)
            wrap.addView(row, FrameLayout.LayoutParams(-1, -2))
            return wrap
        }
    }

    // ───────── الاستيراد والتصدير ─────────
    private fun pickFiles() {
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        act.startActivityForResult(i, REQ_PICK)
    }

    private fun startExport() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        i.putExtra(Intent.EXTRA_TITLE, Exports.fileName(act, "ref"))
        act.startActivityForResult(i, REQ_EXPORT)
    }

    fun onActivityResult(req: Int, result: Int, data: Intent?) {
        if (result != Activity.RESULT_OK || data == null) return
        if (req == REQ_PICK) {
            val uris = ArrayList<Uri>()
            val clip = data.clipData
            if (clip != null) for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri)
            else data.data?.let { uris.add(it) }
            files.clear()
            uris.forEach { files.add(ProductImporter.Source(it, TableReader.fileName(act, it))) }
            fileBtn.text = if (files.isEmpty()) s(R.string.choose_stock_file) else fmtS(R.string.files_selected, files.size)
        } else if (req == REQ_EXPORT) {
            data.data?.let { doExport(it) }
        }
    }

    private fun startMapping() {
        if (files.isEmpty()) { toast(s(R.string.choose_file_first)); return }
        val first = files[0]
        SheetPicker.ensure(act, t, files.map { it.uri }) {
            bg {
                try {
                    val rows = TableReader.read(act, first.uri)
                    ui.post {
                        if (rows.isEmpty()) { toast(s(R.string.empty_file)); return@post }
                        val fields = listOf(
                            ColDialog.Field(R.string.f_itemno, ColumnDetector.Kind.ITEM_NO),
                            ColDialog.Field(R.string.f_barcode, ColumnDetector.Kind.BARCODE),
                            ColDialog.Field(R.string.f_name, ColumnDetector.Kind.NAME),
                            ColDialog.Field(R.string.f_qty, ColumnDetector.Kind.QTY, true)
                        )
                        ColDialog.show(act, t, files.joinToString(", ") { it.name }, rows.take(30), fields) { cols, noHeader ->
                            if (cols[0] < 0 && cols[1] < 0) { toast(s(R.string.select_barcode_or_item)); return@show }
                            if (cols[3] < 0) { toast(s(R.string.select_qty)); return@show }
                            runImport(cols, noHeader)
                        }
                    }
                } catch (e: Exception) {
                    ui.post { toast(fmtS(R.string.read_error, e.message ?: "")) }
                }
            }
        }
    }

    private fun runImport(cols: IntArray, noHeader: Boolean) {
        val box = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        val bar = ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal).apply { max = 1000 }
        box.addView(bar, Ui.lp(-1, -2))
        val label = Ui.text(act, s(R.string.uploading), 12f, t.muted)
        box.addView(label, Ui.margin(Ui.lp(-1, -2), act, 0f, 10f, 0f, 0f))
        val dlg = CardDialog(act, t).title(s(R.string.process_stock), R.drawable.ic_dlg_upload).content(box).cancelable(false).show()

        val srcs = ArrayList(files)
        val mergeMode = merge
        bg {
            val msg = try {
                if (!mergeMode) db.clearStock()
                val byKey = HashMap<String, StockRow>()
                if (mergeMode) for (e in db.allStock()) {
                    if (e.itemNo.isNotEmpty()) byKey[e.itemNo] = e
                    if (e.barcode.isNotEmpty()) byKey[e.barcode] = e
                    byKey[e.key] = e
                }
                srcs.forEachIndexed { fi, src ->
                    ui.post { label.text = src.name }
                    val all = TableReader.read(act, src.uri)
                    val rows = if (noHeader) all else all.drop(1)
                    fun cell(r: List<String>, i: Int) = if (i >= 0 && i < r.size) r[i].trim().replace(ZEROS_RE, "") else ""
                    var start = 0
                    while (start < rows.size) {
                        val end = minOf(start + 500, rows.size)
                        val batch = LinkedHashMap<String, StockRow>()
                        for (ri in start until end) {
                            val r = rows[ri]
                            val (barcode, itemNo) = Codes.fix(cell(r, cols[1]), cell(r, cols[0]))   // يصحّح تبديل الباركود/رقم الصنف
                            val key = itemNo.ifEmpty { barcode }
                            if (key.isEmpty()) continue
                            val name = cell(r, cols[2])
                            val qty = cell(r, cols[3]).replace(",", "").toDoubleOrNull()?.toInt()?.toDouble() ?: 0.0
                            val ex = if (mergeMode) ((if (itemNo.isNotEmpty()) byKey[itemNo] else null)
                                ?: (if (barcode.isNotEmpty()) byKey[barcode] else null)) else null
                            // في الدمج نحدّث نفس السجل الموجود؛ في الرفع داخل نفس الملف نجمع المكرر أيضاً كما في الأصل
                            val same = batch[ex?.key ?: key]
                            val base = same ?: ex
                            val rec = StockRow(
                                key = ex?.key ?: key,
                                itemNo = itemNo.ifEmpty { base?.itemNo ?: "" },
                                barcode = barcode.ifEmpty { base?.barcode ?: "" },
                                name = name.ifEmpty { base?.name ?: "" },
                                qty = (base?.qty ?: 0.0) + qty
                            )
                            batch[rec.key] = rec
                            if (mergeMode) {
                                if (rec.itemNo.isNotEmpty()) byKey[rec.itemNo] = rec
                                if (rec.barcode.isNotEmpty()) byKey[rec.barcode] = rec
                                byKey[rec.key] = rec
                            }
                        }
                        db.upsertStock(batch.values.toList())
                        start = end
                        val frac = (fi + start.toFloat() / maxOf(1, rows.size)) / srcs.size
                        ui.post { bar.progress = Math.round(frac * 1000); label.text = "${src.name}  $start / ${rows.size}" }
                    }
                    db.addUploadedFile(src.name, "stock")
                }
                db.reconcile(unknownLabels(act))
                fmtS(R.string.stock_done, db.countStock())
            } catch (e: Exception) {
                fmtS(R.string.read_error, e.message ?: "")
            }
            ui.post {
                try { dlg.dismiss() } catch (_: Exception) {}   // قد تكون النافذة أُغلقت مع الـActivity
                files.clear()
                fileBtn.text = s(R.string.choose_stock_file)
                toast(msg)
                reload()
                onChanged()
            }
        }
    }

    private fun doExport(uri: Uri) {
        bg {
            val msg = try {
                val os = act.contentResolver.openOutputStream(uri, "wt") ?: throw IllegalStateException("output")
                val n = os.use { Exports.stock(act, db, it) }
                fmtS(R.string.export_done, n)
            } catch (e: Exception) {
                fmtS(R.string.export_failed, e.message ?: "")
            }
            ui.post { toast(msg) }
        }
    }

    companion object {
        const val REQ_PICK = 121
        const val REQ_EXPORT = 122
        private const val PAGE = 50
    }
}
