package com.alansary.a

/** بحث عربي ذكي: يتجاهل الفروق بين الهمزات (ا أ إ آ) والتاء المربوطة/الهاء (ة ه) والألف المقصورة/الياء (ى ي ئ) والواو/المهموزة (و ؤ) والتشكيل. */
object Ar {
    private val TASHKEEL = Regex("[\\u064B-\\u065F\\u0670\\u0640]")

    private fun fold(ch: Char): Char = when (ch) {
        'أ', 'إ', 'آ', 'ٱ' -> 'ا'
        'ة' -> 'ه'
        'ى', 'ئ' -> 'ي'
        'ؤ' -> 'و'
        in '٠'..'٩' -> '0' + (ch - '٠')
        in '۰'..'۹' -> '0' + (ch - '۰')
        else -> ch
    }

    /** نص مُطبَّع للمقارنة داخل الذاكرة. */
    fun norm(s: String): String {
        val t = TASHKEEL.replace(s, "")
        val sb = StringBuilder(t.length)
        for (ch in t) sb.append(fold(ch.lowercaseChar()))
        return sb.toString()
    }

    private fun cls(ch: Char): String = when (fold(ch.lowercaseChar())) {
        'ا' -> "[اأإآٱ]"
        'ه' -> "[هة]"
        'ي' -> "[يىئ]"
        'و' -> "[وؤ]"
        in '0'..'9' -> { val d = fold(ch); "[" + d + ('٠' + (d - '0')) + ('۰' + (d - '0')) + "]" }
        '*' -> "[*]"
        '?' -> "[?]"
        '[' -> "[[]"
        else -> {
            val lo = ch.lowercaseChar(); val up = ch.uppercaseChar()
            if (lo != up) "[$lo$up]" else ch.toString()
        }
    }

    /** نمط GLOB لـ SQLite يطابق أي كتابة مكافئة للنص (للبحث «يحتوي»). */
    fun glob(q: String): String {
        val t = TASHKEEL.replace(q, "")
        val sb = StringBuilder("*")
        for (ch in t) sb.append(cls(ch))
        return sb.append('*').toString()
    }

    /** نمط LIKE آمن: يُهرَّب % و _ و \ فلا تعمل كمحارف بدل (يُستعمل مع ESCAPE '\\'). */
    fun like(q: String): String {
        val sb = StringBuilder("%")
        for (ch in q) { if (ch == '%' || ch == '_' || ch == '\\') sb.append('\\'); sb.append(ch) }
        return sb.append('%').toString()
    }
}
