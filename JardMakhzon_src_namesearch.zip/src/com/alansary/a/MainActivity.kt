package com.alansary.a

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var t: Theme
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var statProducts: TextView
    private lateinit var statItems: TextView
    private lateinit var statOps: TextView
    private val tabViews = arrayOfNulls<LinearLayout>(6)
    private val tabIcons = arrayOfNulls<ImageView>(6)
    private val tabTexts = arrayOfNulls<TextView>(6)
    private lateinit var content: FrameLayout
    private lateinit var products: ProductsView
    private lateinit var scan: ScanView
    private lateinit var inventory: InventoryView
    private lateinit var stock: StockView
    private lateinit var compare: CompareView
    private lateinit var prices: PricesView
    private var selected = TAB_SCAN

    override fun attachBaseContext(base: Context) {
        val loc = Locale(Settings.lang(base))
        Locale.setDefault(loc)
        val cfg = Configuration(base.resources.configuration)
        cfg.setLocale(loc)
        cfg.setLayoutDirection(loc)
        super.attachBaseContext(base.createConfigurationContext(cfg))
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        t = Theme.of(this)
        if (b != null) selected = b.getInt("tab", TAB_SCAN)
        window.statusBarColor = t.accent2
        window.navigationBarColor = t.bg

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(t.bg); clipChildren = false; clipToPadding = false }

        val header = FrameLayout(this)
        val r = Ui.dp(this, 24f).toFloat()
        header.background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(t.accent2, t.accent, 0xFF34D399.toInt())).apply {
            cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
        }
        val title = Ui.text(this, getString(R.string.app_name), 20f, 0xFFFFFFFF.toInt(), true).apply {
            gravity = Gravity.CENTER
            textAlignment = View.TEXT_ALIGNMENT_CENTER
        }
        header.addView(title, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
        val isAr = Settings.lang(this) == "ar"
        val themeBtn = TextView(this).apply {
            text = if (t.dark) "☀️" else "🌙"
            textSize = 18f; gravity = Gravity.CENTER
            background = Ui.rounded(this@MainActivity, 0x33FFFFFF, 0, 22f)
            setOnClickListener {
                Settings.setTheme(this@MainActivity, if (t.dark) "light" else "dark")
                recreate()
            }
        }
        val langBtn = TextView(this).apply {
            text = if (isAr) "EN" else "ع"
            textSize = 14f; gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            background = Ui.rounded(this@MainActivity, 0x33FFFFFF, 0, 22f)
            setOnClickListener {
                Settings.setLang(this@MainActivity, if (isAr) "en" else "ar")
                recreate()
            }
        }
        val bs = Ui.dp(this, 40f)
        header.addView(themeBtn, FrameLayout.LayoutParams(bs, bs, Gravity.START or Gravity.CENTER_VERTICAL))
        header.addView(langBtn, FrameLayout.LayoutParams(bs, bs, Gravity.END or Gravity.CENTER_VERTICAL))
        root.addView(header, Ui.lp(-1, -2))
        val hp = Ui.dp(this, 16f)
        header.setPadding(hp, hp, hp, hp)

        val stats = LinearLayout(this)
        Ui.pad(stats, this, 12f, 10f, 12f, 10f)
        statProducts = statCard(stats, R.string.stat_products, 0)
        statItems = statCard(stats, R.string.stat_items, 1)
        statOps = statCard(stats, R.string.stat_ops, 2)
        root.addView(stats, Ui.lp(-1, -2))

        // التبويبات الستة في صف واحد بعرض الشاشة (مثل الأصل)
        val tabs = LinearLayout(this).apply { clipChildren = false; clipToPadding = false }
        Ui.pad(tabs, this, 8f, 0f, 8f, 12f)
        for (i in 0 until 6) tabs.addView(buildTab(i))
        root.addView(tabs, Ui.lp(-1, -2))

        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))

        products = ProductsView(this, t) { refreshStats() }
        scan = ScanView(this, t) { refreshStats(); inventory.refresh() }
        inventory = InventoryView(this, t) { refreshStats(); scan.refresh() }
        stock = StockView(this, t) { refreshStats() }
        compare = CompareView(this, t)
        prices = PricesView(this, t) { refreshStats() }

        root.setOnApplyWindowInsetsListener { _, ins ->
            header.setPadding(hp, hp + ins.systemWindowInsetTop, hp, hp)
            content.setPadding(0, 0, 0, ins.systemWindowInsetBottom)
            ins
        }

        setContentView(root)
        root.isFocusableInTouchMode = true
        root.requestFocus()
        select(selected)
        refreshStats()
        // عند التشغيل: حذف أصناف الجرد ذات الصفر، وملء أسماء المجهول إن ظهرت في المنتجات/الرصيد
        Thread {
            val db = Db.get(this)
            val a = db.reconcile(unknownLabels(this))
            if (a > 0) ui.post { refreshStats(); inventory.refresh(); scan.refresh() }
        }.start()
    }

    override fun onSaveInstanceState(out: Bundle) {
        super.onSaveInstanceState(out)
        out.putInt("tab", selected)
    }

    private fun statCard(parent: LinearLayout, labelRes: Int, idx: Int): TextView {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = Ui.rounded(this@MainActivity, t.surface, t.border, 18f)
        }
        Ui.pad(card, this, 6f, 10f, 6f, 10f)
        val v = Ui.text(this, "0", 20f, t.accent, true).apply { textAlignment = View.TEXT_ALIGNMENT_CENTER }
        val l = Ui.text(this, getString(labelRes), 11f, t.muted).apply {
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            isSingleLine = true
        }
        card.addView(v)
        card.addView(l)
        val bar = View(this)
        bar.background = Ui.rounded(this, Theme.alpha(t.accent, 0.35f), 0, 2f)
        card.addView(bar, Ui.margin(Ui.lp(Ui.dp(this, 36f), Ui.dp(this, 3f)), this, 0f, 6f, 0f, 0f))
        val lp = Ui.lpWeight(1f)
        lp.marginStart = Ui.dp(this, if (idx == 0) 0f else 4f)
        lp.marginEnd = Ui.dp(this, if (idx == 2) 0f else 4f)
        parent.addView(card, lp)
        return v
    }

    private fun buildTab(i: Int): View {
        val tab = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        Ui.pad(tab, this, 2f, 8f, 2f, 6f)
        val icon = ImageView(this).apply {
            setImageResource(TAB_ICONS[i])
            scaleType = ImageView.ScaleType.CENTER_INSIDE
        }
        Ui.pad(icon, this, 10f, 10f, 10f, 10f)
        tab.addView(icon, Ui.lp(Ui.dp(this, 42f), Ui.dp(this, 42f)))
        val label = Ui.text(this, getString(TAB_LABELS[i]), 10f, t.muted).apply {
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            gravity = Gravity.CENTER
            isSingleLine = true
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        tab.addView(label, Ui.margin(Ui.lp(-2, -2), this, 0f, 4f, 0f, 0f))
        tab.setOnClickListener { select(i, true) }
        val lp = Ui.lpWeight(1f)
        lp.marginStart = Ui.dp(this, 2f)
        lp.marginEnd = Ui.dp(this, 2f)
        tab.layoutParams = lp
        tabViews[i] = tab; tabIcons[i] = icon; tabTexts[i] = label
        return tab
    }

    /** ألوان كل تبويب نشط (من CSS الأصل): سماوي، أخضر، أزرق، برتقالي، نعناعي، ذهبي. */
    private class TP(
        val l1: Int, val l2: Int, val lblL: Int, val g1: Int, val g2: Int, val glow: Int,
        val d1: Int, val d2: Int, val lblD: Int
    )

    private fun rgb(v: Int) = 0xFF000000.toInt() or v

    private fun select(idx: Int, animate: Boolean = false) {
        selected = idx
        for (i in 0 until 6) {
            val sel = i == idx
            val p = PAL[i]
            val tab = tabViews[i]!!
            val icon = tabIcons[i]!!
            val label = tabTexts[i]!!
            val r20 = Ui.dp(this, 20f).toFloat()
            if (sel) {
                tab.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                    if (t.dark) intArrayOf(rgb(p.d1), rgb(p.d2)) else intArrayOf(rgb(p.l1), rgb(p.l2))).apply { cornerRadius = r20 }
                icon.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(rgb(p.g1), rgb(p.g2))).apply {
                    cornerRadius = Ui.dp(this@MainActivity, 14f).toFloat()
                }
                icon.setColorFilter(0xFFFFFFFF.toInt())
                label.setTextColor(rgb(if (t.dark) p.lblD else p.lblL))
                glow(tab, p.glow, 8f)
                glow(icon, p.glow, 5f)
                if (animate) {
                    // نفس iconBounce: تصغير ودوران ثم ارتداد
                    icon.scaleX = 0.6f; icon.scaleY = 0.6f; icon.rotation = -10f
                    icon.animate().scaleX(1f).scaleY(1f).rotation(0f).setDuration(400)
                        .setInterpolator(android.view.animation.OvershootInterpolator(2.4f)).start()
                }
            } else {
                tab.background = GradientDrawable().apply {
                    setColor(if (t.dark) t.surface else 0xFFFFFFFF.toInt()); cornerRadius = r20
                }
                icon.background = GradientDrawable().apply {
                    setColor(if (t.dark) t.surface2 else 0xFFF3F4F6.toInt()); cornerRadius = Ui.dp(this@MainActivity, 14f).toFloat()
                }
                val gray = if (t.dark) t.muted else 0xFF9CA3AF.toInt()
                icon.setColorFilter(gray)
                label.setTextColor(gray)
                tab.elevation = Ui.dp(this, 2f).toFloat()
                icon.elevation = 0f
                if (android.os.Build.VERSION.SDK_INT >= 28) {
                    tab.outlineSpotShadowColor = 0xFF000000.toInt(); tab.outlineAmbientShadowColor = 0xFF000000.toInt()
                    icon.outlineSpotShadowColor = 0xFF000000.toInt(); icon.outlineAmbientShadowColor = 0xFF000000.toInt()
                }
            }
            label.setTypeface(null, if (sel) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
        }
        content.removeAllViews()
        if (idx != TAB_SCAN) scan.stopCamera()
        if (idx != TAB_PRICES) prices.stopCamera()
        if (idx == TAB_SCAN) {
            scan.refresh()
            content.addView(scan, FrameLayout.LayoutParams(-1, -1))
        } else if (idx == TAB_INV) {
            inventory.refresh()
            content.addView(inventory, FrameLayout.LayoutParams(-1, -1))
        } else if (idx == TAB_STOCK) {
            stock.refresh()
            content.addView(stock, FrameLayout.LayoutParams(-1, -1))
        } else if (idx == TAB_CMP) {
            compare.refresh()
            content.addView(compare, FrameLayout.LayoutParams(-1, -1))
        } else if (idx == TAB_PRICES) {
            prices.refresh()
            content.addView(prices, FrameLayout.LayoutParams(-1, -1))
        } else if (idx == TAB_PRODUCTS) {
            content.addView(products, FrameLayout.LayoutParams(-1, -1))
        } else {
            val soon = Ui.text(this, getString(R.string.coming_soon), 15f, t.muted).apply {
                gravity = Gravity.CENTER
                textAlignment = View.TEXT_ALIGNMENT_CENTER
            }
            content.addView(soon, FrameLayout.LayoutParams(-1, -1))
        }
    }

    fun refreshStats() {
        Thread {
            val db = Db.get(this)
            val p = db.countProducts(); val i = db.countInventory(); val o = db.countScanLog()
            ui.post {
                statProducts.text = String.format(Locale.US, "%d", p)
                statItems.text = String.format(Locale.US, "%d", i)
                statOps.text = String.format(Locale.US, "%d", o)
            }
        }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, result: Int, data: Intent?) {
        super.onActivityResult(req, result, data)
        products.onActivityResult(req, result, data)
        inventory.onActivityResult(req, result, data)
        stock.onActivityResult(req, result, data)
        compare.onActivityResult(req, result, data)
    }

    override fun onRequestPermissionsResult(req: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(req, perms, res)
        val ok = res.isNotEmpty() && res[0] == android.content.pm.PackageManager.PERMISSION_GRANTED
        scan.onPermissionResult(req, ok)
        prices.onPermissionResult(req, ok)
    }

    override fun onDestroy() {
        if (::scan.isInitialized) scan.release()
        if (::prices.isInitialized) prices.release()
        super.onDestroy()
    }

    override fun onPause() {
        super.onPause()
        if (::scan.isInitialized) scan.stopCamera()
        if (::prices.isInitialized) prices.stopCamera()
    }

    /** توهج بلون التبويب (على أندرويد 9+ يتلوّن الظل؛ قبل ذلك ظل عادي). */
    private fun glow(view: View, color: Int, elevDp: Float) {
        view.elevation = Ui.dp(this, elevDp).toFloat()
        if (android.os.Build.VERSION.SDK_INT >= 28) {
            view.outlineSpotShadowColor = rgb(color)
            view.outlineAmbientShadowColor = rgb(color)
        }
    }

    companion object {
        private val PAL = arrayOf(
            TP(0xE0F7FA, 0xB2EBF2, 0x00838F, 0x00838F, 0x00BCD4, 0x00BCD4, 0x0C3040, 0x0E4F63, 0x67E8F9), // المسح: سماوي
            TP(0xE8F5E9, 0xC8E6C9, 0x2E7D32, 0x2E7D32, 0x43A047, 0x43A047, 0x0A2E1A, 0x133D24, 0x6EE7B7), // الجرد: أخضر
            TP(0xE3F2FD, 0xBBDEFB, 0x1565C0, 0x1565C0, 0x2196F3, 0x2196F3, 0x0A1F40, 0x0E2D5E, 0x93C5FD), // الرصيد: أزرق
            TP(0xFFF8E1, 0xFFECB3, 0xE65100, 0xE65100, 0xFFA000, 0xFFA000, 0x2A1800, 0x3D2400, 0xFDE68A), // المقارنة: برتقالي
            TP(0xD1FAE5, 0xA7F3D0, 0x065F40, 0x065F40, 0x10B981, 0x10B981, 0x0A2E1A, 0x133D24, 0x6EE7B7), // المنتجات: نعناعي
            TP(0xFEF9C3, 0xFDE68A, 0x92400E, 0xB45309, 0xF59E0B, 0xF59E0B, 0x2A1E00, 0x3A2A00, 0xFBBF24)  // الأسعار: ذهبي
        )
        private const val TAB_SCAN = 0
        private const val TAB_INV = 1
        private const val TAB_STOCK = 2
        private const val TAB_CMP = 3
        private const val TAB_PRICES = 5
        private const val TAB_PRODUCTS = 4
        private val TAB_LABELS = intArrayOf(R.string.tab_scan, R.string.tab_inv, R.string.tab_stock,
            R.string.tab_cmp, R.string.tab_products, R.string.tab_prices)
        private val TAB_ICONS = intArrayOf(R.drawable.ic_scan, R.drawable.ic_inv, R.drawable.ic_stock,
            R.drawable.ic_cmp, R.drawable.ic_products, R.drawable.ic_prices)
    }
}
