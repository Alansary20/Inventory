package com.alansary.a

import java.util.UUID

/** منطق البحث بعد قراءة الكود (نفس lookupAndAdd الأصلية). يُستدعى من خيط خلفي. */
class ScanEngine(private val db: Db, private val unknownName: String) {

    enum class Kind { FOUND, AUTO, UNKNOWN, INVALID, CHOOSE, NAME_ONLY }
    class Outcome(val kind: Kind, val name: String = "", val code: String = "", val choices: List<NameHit> = emptyList())

    /** إضافة صنف اختاره المستخدم من قائمة الأسماء المحتملة. */
    fun addHit(h: NameHit): Outcome {
        db.addToInventory(h.key, h.name, h.barcode, h.itemNo)
        return Outcome(Kind.FOUND, h.name, h.key)
    }

    private val digits = Regex("^\\d+$")
    private val itemNoRe = Regex("^\\d+-[\\d-]+$")
    private val ctrlRe = Regex("[\\x00-\\x1F\\x7F]")
    private val zerosRe = Regex("\\.0+$")

    fun sanitize(raw: String?): String? {
        if (raw == null) return null
        val v = raw.trim().replace(ctrlRe, "").replace(zerosRe, "")
        return v.ifEmpty { null }
    }

    fun process(raw: String): Outcome {
        val code = sanitize(raw) ?: return Outcome(Kind.INVALID)
        val isBarcode = digits.matches(code)
        val isItemNo = itemNoRe.matches(code)

        // بحث حسب النوع أولاً ثم الكل
        val match: Product? = when {
            isBarcode -> db.findByBarcode(code) ?: db.findByItemNo(code)
            isItemNo -> db.findByItemNo(code) ?: db.findByBarcode(code)
            else -> db.findByBarcode(code) ?: db.findByItemNo(code)
        }
        if (match != null) {
            val key = match.itemNo.ifEmpty { match.barcode }
            db.addToInventory(key, match.name, match.barcode, match.itemNo)
            return Outcome(Kind.FOUND, match.name, code)
        }

        // غير موجود في المنتجات (أو لم تُرفع المنتجات): نبحث في الرصيد بالمفتاح أو رقم الصنف أو الباركود
        val st = db.findStock(code)
        if (st != null) {
            val keyIsDigits = digits.matches(st.key)
            val itemNo = st.itemNo.ifEmpty { if (!keyIsDigits) st.key else "" }
            val barcode = st.barcode.ifEmpty { if (isBarcode) code else if (keyIsDigits) st.key else "" }
            val name = st.name.ifEmpty { st.key }
            db.upsertProducts(listOf(Product(
                id = UUID.randomUUID().toString(), barcode = barcode, itemNo = itemNo, name = name
            )))
            // نفس مفتاح الرصيد كي تتطابق المقارنة لاحقاً
            db.addToInventory(itemNo.ifEmpty { barcode.ifEmpty { st.key } }, name, barcode, itemNo)
            return Outcome(Kind.AUTO, name, code)
        }

        // نص فيه حروف وليس باركوداً ولا رقم صنف (ولو كلمة واحدة): نبحث عنه بالاسم في المنتجات والرصيد
        if (Codes.searchableAsName(code)) {
            val idx = Names.get(db)
            idx.exact(code)?.let { return addHit(it) }
            val r = idx.search(code)
            if (r.list.size == 1 && r.full) return addHit(r.list[0])
            if (r.list.isNotEmpty()) return Outcome(Kind.CHOOSE, code = code, choices = r.list)
            if (Codes.looksLikeName(code)) {
                // اسم غير موجود: يُحفظ كاسم، ولا يوضع مكان رقم الصنف أو الباركود
                db.addToInventory(code, code, "", "")
                return Outcome(Kind.NAME_ONLY, code, code)
            }
        }

        // لم يُعثر عليه
        val unknownItemNo = if (isItemNo) code else ""
        val unknownBarcode = if (isBarcode) code else ""
        val key = unknownItemNo.ifEmpty { unknownBarcode.ifEmpty { code } }
        db.addToInventory(key, unknownName, unknownBarcode, unknownItemNo)
        return Outcome(Kind.UNKNOWN, unknownName, code)
    }
}
