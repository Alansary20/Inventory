package com.alansary.a

/** عنصر في فهرس الأسعار (منتج، أو صنف من الرصيد غير مطابق لأي منتج). */
class PItem(
    val code: String, val name: String, val orig: Double, val sale: Double, val disc: Int,
    val stock: Double, val itemNo: String, val barcode: String,
    val product: Product?, val barcodes: List<String>
) {
    val lcName = Ar.norm(name)
    val lcCode = code.lowercase()
    val lcItem = itemNo.lowercase()
    val lcBar = barcode.lowercase()
}

/**
 * نفس rebuildPricesIndex الأصلية: كل المنتجات + أصناف الرصيد التي لم تُطابَق مع منتج،
 * مع الرصيد من ملف الرصيد. الترتيب: الرصيد الأكثر أولاً ثم الاسم.
 */
object PricesIndex {
    class Built(
        val version: Long, val list: List<PItem>,
        val byCode: HashMap<String, PItem>, val byBarcode: HashMap<String, PItem>,
        val byBarcodeNorm: HashMap<String, PItem> = HashMap()
    ) {
        /** بحث بالباركود يتسامح مع الأصفار الأولى (UPC-A 12 خانة ↔ EAN-13 13 خانة، أو صفر ضاع في الإكسل). */
        fun findBarcode(q: String): PItem? {
            byBarcode[q]?.let { return it }
            val n = normBarcode(q) ?: return null
            return byBarcodeNorm[n]
        }
        fun findCode(q: String): PItem? = byCode[q] ?: findBarcode(q)
        fun filterCode(q: String): List<PItem> {
            val ql = q.lowercase()
            return list.filter { it.lcCode.contains(ql) || it.lcItem.contains(ql) || it.lcBar.contains(ql) }
        }
        fun filterName(q: String): List<PItem> {
            val ql = Ar.norm(q)
            return list.filter { it.lcName.contains(ql) }
        }
    }

    /** مفتاح الباركود بلا أصفار أولى (للأرقام فقط وبطول 6 فأكثر)، وإلا null. */
    fun normBarcode(s: String): String? {
        val t = s.trim()
        if (t.length < 6 || !t.all { it in '0'..'9' }) return null
        return t.trimStart('0').ifEmpty { null }
    }

    @Volatile private var cache: Built? = null

    fun get(db: Db): Built {
        val v = db.dataVersion
        cache?.let { if (it.version == v) return it }
        synchronized(this) {
            cache?.let { if (it.version == v) return it }
            val b = build(db, v)
            cache = b
            return b
        }
    }

    private fun build(db: Db, version: Long): Built {
        val prods = db.allProducts()
        val stockArr = db.allStock()
        val qtyMap = HashMap<String, Double>(stockArr.size * 2)
        val nameMap = HashMap<String, String>(stockArr.size * 2)
        for (s in stockArr) { qtyMap[s.key] = s.qty; nameMap[s.key] = s.name.ifEmpty { s.key } }

        val items = ArrayList<PItem>(prods.size + 16)
        val byCode = HashMap<String, PItem>()
        val byBarcode = HashMap<String, PItem>()
        val matched = HashSet<String>()

        for (p in prods) {
            val code = p.itemNo.ifEmpty { p.barcode }
            if (code.isEmpty()) continue
            val name = p.name.ifEmpty { code }
            val orig = p.priceOrig
            val sale = if (p.priceSale != 0.0) p.priceSale else orig
            val disc = if (orig > 0) Math.round((orig - sale) / orig * 100).toInt() else 0
            var stk = 0.0
            if (p.itemNo.isNotEmpty()) qtyMap[p.itemNo]?.let { stk = it; matched.add(p.itemNo) }
            if (p.barcode.isNotEmpty()) qtyMap[p.barcode]?.let { stk = it; matched.add(p.barcode) }
            val alts = p.altList()
            val codes = ArrayList<String>()
            if (p.barcode.isNotEmpty()) codes.add(p.barcode)
            for (a in alts) if (a != p.barcode) codes.add(a)
            val item = PItem(code, name, orig, sale, disc, stk, p.itemNo, p.barcode, p, codes)
            items.add(item)
            if (p.itemNo.isNotEmpty()) { byCode[p.itemNo] = item; matched.add(p.itemNo) }
            if (p.barcode.isNotEmpty()) { byCode[p.barcode] = item; byBarcode[p.barcode] = item; matched.add(p.barcode) }
            for (a in alts) { byCode[a] = item; byBarcode[a] = item; matched.add(a) }
        }
        // أصناف الرصيد التي لم تُطابَق مع أي منتج
        val digits = Regex("^\\d+$")
        for (s in stockArr) {
            if (s.key in matched) continue
            val code = s.key
            val keyDigits = digits.matches(code)
            val itemNo = s.itemNo.ifEmpty { if (!keyDigits) code else "" }
            val bc = s.barcode.ifEmpty { if (keyDigits) code else "" }
            val item = PItem(code, nameMap[code] ?: code, 0.0, 0.0, 0, s.qty, itemNo, bc, null,
                if (bc.isNotEmpty()) listOf(bc) else emptyList())
            items.add(item)
            byCode[code] = item
            if (itemNo.isNotEmpty()) byCode[itemNo] = item
            if (bc.isNotEmpty()) { byCode[bc] = item; byBarcode[bc] = item }
        }
        // الرصيد الأكثر في الأعلى، ثم الاسم
        items.sortWith(Comparator { a, b ->
            val c = b.stock.compareTo(a.stock)
            if (c != 0) c else a.lcName.compareTo(b.lcName)
        })
        val norm = HashMap<String, PItem>(byBarcode.size * 2)
        for ((k, v) in byBarcode) { val n = normBarcode(k); if (n != null) norm.putIfAbsent(n, v) }
        return Built(version, items, byCode, byBarcode, norm)
    }
}
