package com.alansary.a

import android.app.Activity
import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.TextWatcher
import android.widget.EditText
import android.widget.ImageView
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

/** تبويب المقارنة: الرصيد مقابل المجرود مع فلاتر وتصدير. */
class CompareView(
    private val act: Activity,
    private val t: Theme
) : FrameLayout(act) {

    private val db = Db.get(act)
    private val ui = Handler(Looper.getMainLooper())
    private val list = StillListView(act)
    private val adapter = RowAdapter()
    private var data: CmpResult? = null
    private var shown: List<CmpRow> = emptyList()
    private var filter = "all"
    private var query = ""
    private var loadToken = 0

    private lateinit var sRef: TextView
    private lateinit var sInc: TextView
    private lateinit var sDec: TextView
    private lateinit var sMatch: TextView
    private lateinit var sScanned: TextView
    private lateinit var sDiff: TextView
    private lateinit var emptyText: TextView


    private fun s(id: Int) = act.getString(id)
    private fun fmtS(id: Int, vararg a: Any) = String.format(Locale.US, act.getString(id), *a)
    private fun toast(m: String) = Toast.makeText(act, m, Toast.LENGTH_LONG).show()

    // ───────── لوحة ألوان الأصل: بطاقات الإحصاء + أزرار الفلتر ─────────
    private fun rgb(v: Int) = 0xFF000000.toInt() or v

    private class V(
        val g1: Int, val g2: Int,
        val sBgL: Int, val sBorL: Int, val sNumL: Int, val sLblL: Int,
        val sBgD: Int, val sBorD: Int, val sNumD: Int, val sLblD: Int,
        val fBgL: Int, val fLblL: Int, val fBgD: Int, val fLblD: Int, val glow: Int
    )

    private val NEUTRAL = V(0x475569, 0x94A3B8,
        0xF8FAFC, 0x14000000, 0x475569, 0x94A3B8, 0x1494A3B8, 0x3394A3B8, 0xCBD5E1, 0x94A3B8,
        0xF1F5F9, 0x475569, 0x1A94A3B8, 0xE2E8F0, 0x94A3B8)
    private val GREEN = V(0x059669, 0x34D399,
        0xF0FDF4, 0x3310B981, 0x059669, 0x6EE7B7, 0x1410B981, 0x4034D399, 0x34D399, 0x6EE7B7,
        0xECFDF5, 0x059669, 0x1A10B981, 0x6EE7B7, 0x10B981)
    private val RED = V(0xBE123C, 0xFB7185,
        0xFFF1F2, 0x33F43F5E, 0xE11D48, 0xFDA4AF, 0x12F43F5E, 0x40FB7185, 0xFB7185, 0xFDA4AF,
        0xFFF1F2, 0xE11D48, 0x17F43F5E, 0xFDA4AF, 0xF43F5E)
    private val BLUE = V(0x1D4ED8, 0x60A5FA,
        0xEFF6FF, 0x333B82F6, 0x2563EB, 0x93C5FD, 0x143B82F6, 0x4060A5FA, 0x60A5FA, 0x93C5FD,
        0xEFF6FF, 0x2563EB, 0x1A3B82F6, 0x93C5FD, 0x3B82F6)
    private val AMBER = V(0xB45309, 0xFBBF24,
        0xFFFBEB, 0x33F59E0B, 0xB45309, 0xFDE68A, 0x14F59E0B, 0x40FBBF24, 0xFBBF24, 0xFDE68A,
        0xFFFBEB, 0xB45309, 0x1AF59E0B, 0xFDE68A, 0xF59E0B)
    private val VIOLET = V(0x7E22CE, 0xC084FC,
        0xFAF5FF, 0x33A855F7, 0x7E22CE, 0xD8B4FE, 0x14A855F7, 0x40C084FC, 0xC084FC, 0xD8B4FE,
        0xFAF5FF, 0x7E22CE, 0x1AA855F7, 0xD8B4FE, 0xA855F7)

    /** القيم المعرَّفة بدون ألفا (مثل 0xF8FAFC) تُحوَّل إلى ألوان معتمة؛ والمعرَّفة بألفا تبقى كما هي. */
    private fun col(v: Int) = if ((v ushr 24) == 0) rgb(v) else v

    private fun gradient(v: V, radiusDp: Float): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(rgb(v.g1), rgb(v.g2))).apply {
            cornerRadius = Ui.dp(act, radiusDp).toFloat()
        }

    /** توهج ملوّن حول العنصر (يعمل بلون الظل على أندرويد 9+؛ ظل عادي قبلها). */
    private fun glow(view: View, color: Int, elevDp: Float) {
        view.elevation = Ui.dp(act, elevDp).toFloat()
        if (android.os.Build.VERSION.SDK_INT >= 28) {
            view.outlineSpotShadowColor = rgb(color)
            view.outlineAmbientShadowColor = rgb(color)
        }
    }

    private fun iconBox(v: V?, icon: Int, sizeDp: Float, radiusDp: Float): ImageView =
        ImageView(act).apply {
            setImageResource(icon)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            val p = Ui.dp(act, sizeDp * 0.26f)
            setPadding(p, p, p, p)
            layoutParams = LinearLayout.LayoutParams(Ui.dp(act, sizeDp), Ui.dp(act, sizeDp))
        }

    /** بطاقة إحصاء ملوّنة: أيقونة متدرجة + رقم كبير + عنوان. */
    private fun statCard(v: V, icon: Int, label: String): Pair<View, TextView> {
        val c: Context = act
        val dark = t.dark
        val card = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = Ui.rounded(c, col(if (dark) v.sBgD else v.sBgL), col(if (dark) v.sBorD else v.sBorL), 18f)
        }
        Ui.pad(card, c, 6f, 11f, 6f, 10f)
        val ib = iconBox(v, icon, 32f, 10f)
        ib.background = gradient(v, 10f)
        glow(ib, v.glow, 2f)
        card.addView(ib, Ui.margin(Ui.lp(Ui.dp(c, 32f), Ui.dp(c, 32f)), c, 0f, 0f, 0f, 7f))
        val num = Ui.text(c, "0", 30f, col(if (dark) v.sNumD else v.sNumL), true).apply {
            textAlignment = View.TEXT_ALIGNMENT_CENTER; gravity = Gravity.CENTER_HORIZONTAL; isSingleLine = true
            textDirection = View.TEXT_DIRECTION_LTR
        }
        card.addView(num, Ui.lp(-1, -2))
        card.addView(Ui.text(c, label, 11f, col(if (dark) v.sLblD else v.sLblL), true).apply {
            textAlignment = View.TEXT_ALIGNMENT_CENTER; gravity = Gravity.CENTER_HORIZONTAL; isSingleLine = true
        }, Ui.margin(Ui.lp(-1, -2), c, 0f, 5f, 0f, 0f))
        return Pair(card, num)
    }

    private class FBtn(val key: String, val v: V, val box: LinearLayout, val icon: ImageView, val label: TextView)
    private val fbtns = LinkedHashMap<String, FBtn>()

    private fun filterButton(key: String, v: V, icon: Int, label: String): LinearLayout {
        val c: Context = act
        val box = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        Ui.pad(box, c, 4f, 10f, 4f, 8f)
        val ic = iconBox(v, icon, 40f, 13f)
        box.addView(ic, Ui.lp(Ui.dp(c, 40f), Ui.dp(c, 40f)))
        val lb = Ui.text(c, label, 11f, 0xFF94A3B8.toInt(), true).apply {
            textAlignment = View.TEXT_ALIGNMENT_CENTER; gravity = Gravity.CENTER_HORIZONTAL; isSingleLine = true
        }
        box.addView(lb, Ui.margin(Ui.lp(-2, -2), c, 0f, 5f, 0f, 0f))
        box.setOnClickListener { setFilter(key, true) }
        fbtns[key] = FBtn(key, v, box, ic, lb)
        return box
    }

    private fun buildHeader(): View {
        val c: Context = act
        val h = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; clipChildren = false; clipToPadding = false }
        Ui.pad(h, c, 12f, 6f, 12f, 6f)

        val cells = listOf(
            statCard(NEUTRAL, R.drawable.ic_products, s(R.string.cmp_reference)),
            statCard(GREEN, R.drawable.ic_f_up, s(R.string.cmp_increase)),
            statCard(RED, R.drawable.ic_f_down, s(R.string.cmp_decrease)),
            statCard(BLUE, R.drawable.ic_f_match, s(R.string.cmp_match)),
            statCard(AMBER, R.drawable.ic_f_bar, s(R.string.cmp_scanned)),
            statCard(VIOLET, R.drawable.ic_f_scale, s(R.string.cmp_diff)))
        sRef = cells[0].second; sInc = cells[1].second; sDec = cells[2].second
        sMatch = cells[3].second; sScanned = cells[4].second; sDiff = cells[5].second
        for (rowIdx in 0..1) {
            val row = LinearLayout(c).apply { clipChildren = false }
            for (k in 0..2) {
                val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                lp.marginStart = Ui.dp(c, if (k == 0) 0f else 5f)
                lp.marginEnd = Ui.dp(c, if (k == 2) 0f else 5f)
                row.addView(cells[rowIdx * 3 + k].first, lp)
            }
            h.addView(row, Ui.margin(Ui.lp(-1, -2), c, 0f, 5f, 0f, 5f))
        }

        // أزرار الفلتر الملوّنة
        val fr = LinearLayout(c).apply { clipChildren = false; clipToPadding = false }
        val defs = listOf(
            Triple("all", NEUTRAL, Pair(R.drawable.ic_f_all, R.string.flt_all)),
            Triple("increase", GREEN, Pair(R.drawable.ic_f_up, R.string.flt_increase)),
            Triple("decrease", RED, Pair(R.drawable.ic_f_down, R.string.flt_decrease)),
            Triple("match", BLUE, Pair(R.drawable.ic_f_match, R.string.flt_match)),
            Triple("scanned", AMBER, Pair(R.drawable.ic_f_bar, R.string.flt_scanned)))
        defs.forEachIndexed { k, (key, v, io) ->
            val btn = filterButton(key, v, io.first, s(io.second))
            val lp = Ui.lpWeight(1f)
            lp.marginStart = Ui.dp(c, if (k == 0) 0f else 3f)
            lp.marginEnd = Ui.dp(c, if (k == defs.size - 1) 0f else 3f)
            fr.addView(btn, lp)
        }
        h.addView(fr, Ui.margin(Ui.lp(-1, -2), c, 0f, 10f, 0f, 14f))
        styleFilters(false)

        h.addView(Ui.button(c, s(R.string.export_compare), t.accent, false) { startExport() },
            Ui.margin(Ui.lp(-1, -2), c, 0f, 0f, 0f, 10f))

        val search = EditText(c).apply {
            hint = s(R.string.cmp_search_hint)
            setHintTextColor(t.muted); setTextColor(t.text); textSize = 14f
            isSingleLine = true
            background = Ui.rounded(c, t.surface2, t.border, 16f)
            minHeight = Ui.dp(c, 48f)
        }
        Ui.pad(search, c, 14f, 0f, 14f, 0f)
        val apply = Runnable { applyFilter() }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(a: CharSequence?, b: Int, d: Int, e: Int) {}
            override fun onTextChanged(a: CharSequence?, b: Int, d: Int, e: Int) {}
            override fun afterTextChanged(ed: Editable?) {
                query = Ar.norm(ed?.toString()?.trim() ?: "")
                ui.removeCallbacks(apply)
                ui.postDelayed(apply, 200)
            }
        })
        h.addView(search, Ui.margin(Ui.lp(-1, -2), c, 0f, 0f, 0f, 6f))

        emptyText = Ui.text(c, s(R.string.no_cmp), 14f, t.muted).apply { gravity = Gravity.CENTER }
        Ui.pad(emptyText, c, 0f, 28f, 0f, 28f)
        emptyText.visibility = View.GONE
        h.addView(emptyText, Ui.lp(-1, -2))
        return h
    }

    /** ألوان الزر المحدد (متدرج + توهج) وغير المحدد (رمادي مزرق) كما في الأصل. */
    private fun styleFilters(animate: Boolean) {
        val c: Context = act
        for ((key, f) in fbtns) {
            val sel = key == filter
            val v = f.v
            if (sel) {
                f.box.background = Ui.rounded(c, col(if (t.dark) v.fBgD else v.fBgL), 0, 16f)
                f.icon.background = gradient(v, 13f)
                f.icon.setColorFilter(0xFFFFFFFF.toInt())
                f.label.setTextColor(col(if (t.dark) v.fLblD else v.fLblL))
                glow(f.box, v.glow, 6f)
                glow(f.icon, v.glow, 4f)
                if (animate) {
                    f.icon.scaleX = 0.7f; f.icon.scaleY = 0.7f
                    f.icon.animate().scaleX(1f).scaleY(1f).setDuration(300)
                        .setInterpolator(android.view.animation.OvershootInterpolator(2.2f)).start()
                }
            } else {
                f.box.background = Ui.rounded(c, if (t.dark) t.surface else 0xFFFFFFFF.toInt(), 0, 16f)
                f.icon.background = Ui.rounded(c, if (t.dark) t.surface3 else 0xFFF1F5F9.toInt(), 0, 13f)
                f.icon.setColorFilter(0xFF94A3B8.toInt())
                f.label.setTextColor(0xFF94A3B8.toInt())
                f.box.elevation = 0f
                f.icon.elevation = 0f
            }
        }
    }

    private fun setFilter(f: String, animate: Boolean = false) {
        filter = f
        styleFilters(animate)
        applyFilter()
    }

    /** يعيد بناء المقارنة من قاعدة البيانات (ثقيل: على خيط خلفي). */
    fun refresh() {
        val tok = ++loadToken
        Thread {
            val res = try { CompareBuilder.build(db, unknownLabels(act)) } catch (e: Exception) { null }
            ui.post {
                if (tok == loadToken && res != null) {
                    data = res
                    applyFilter()
                }
            }
        }.start()
    }

    private fun applyFilter() {
        val d = data ?: return
        var rows = when (filter) {
            "increase" -> d.rows.filter { it.diff > 0 }
            "decrease" -> d.rows.filter { it.diff < 0 }
            "match" -> d.rows.filter { it.diff == 0.0 && it.qi > 0 }
            "scanned" -> d.rows.filter { it.qi > 0 }
            else -> d.rows
        }
        if (query.isNotEmpty()) {
            rows = rows.filter {
                Ar.norm(it.name).contains(query) || it.itemNo.lowercase().contains(query) ||
                    it.barcode.lowercase().contains(query) || it.key.lowercase().contains(query)
            }
        }
        shown = rows
        sRef.text = d.stockLen.toString()
        sInc.text = d.inc.toString()
        sDec.text = d.dec.toString()
        sMatch.text = d.match.toString()
        sScanned.text = d.invLen.toString()
        sDiff.text = Ui.qty(shown.sumOf { it.diff })
        emptyText.visibility = if (shown.isEmpty()) View.VISIBLE else View.GONE
        adapter.notifyDataSetChanged()
    }

    private inner class RowAdapter : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(i: Int): Any = shown[i]
        override fun getItemId(i: Int) = i.toLong()
        override fun getView(i: Int, convert: View?, parent: ViewGroup?): View {
            val c: Context = act
            val r = shown[i]
            val pos = r.diff > 0
            val neg = r.diff < 0
            val zero = r.diff == 0.0 && r.qi > 0
            val clr = if (pos) 0xFF10B981.toInt() else if (neg) 0xFFFB7185.toInt() else if (zero) 0xFF60A5FA.toInt() else t.muted
            val icon = if (pos) "⬆" else if (neg) "⬇" else if (zero) "✓" else "—"

            val wrap = FrameLayout(c)
            Ui.pad(wrap, c, 12f, 4f, 12f, 4f)
            val row = LinearLayout(c).apply {
                gravity = Gravity.CENTER_VERTICAL
                background = Ui.rounded(c, t.surface2, t.border, 12f)
            }
            Ui.pad(row, c, 12f, 10f, 12f, 10f)
            val info = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
            info.addView(Ui.text(c, r.name.ifEmpty { "—" }, 13f, t.text, true).apply {
                isSingleLine = true; ellipsize = TextUtils.TruncateAt.END
            })
            info.addView(Ui.text(c, r.itemNo.ifEmpty { r.barcode.ifEmpty { "—" } }, 10f, t.muted))
            info.addView(Ui.text(c, "${s(R.string.th_actual)} ${Ui.qty(r.qs)} → ${s(R.string.th_counted)} ${Ui.qty(r.qi)}", 11f, t.muted))
            row.addView(info, Ui.margin(Ui.lpWeight(1f), c, 0f, 0f, 8f, 0f))
            val diffTxt = icon + " " + (if (r.diff > 0) "+" else "") + Ui.qty(r.diff)
            val badge = Ui.text(c, diffTxt, 14f, clr, true).apply {
                textDirection = View.TEXT_DIRECTION_LTR
                gravity = Gravity.CENTER
                background = Ui.rounded(c, Theme.alpha(clr, 0.12f), Theme.alpha(clr, 0.35f), 10f)
                minWidth = Ui.dp(c, 56f)
            }
            Ui.pad(badge, c, 10f, 6f, 10f, 6f)
            row.addView(badge)
            wrap.addView(row, FrameLayout.LayoutParams(-1, -2))
            return wrap
        }
    }

    // ───────── التصدير ─────────
    private fun startExport() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        i.putExtra(Intent.EXTRA_TITLE, Exports.fileName(act, "cmp"))
        act.startActivityForResult(i, REQ_EXPORT)
    }

    fun onActivityResult(req: Int, result: Int, data: Intent?) {
        if (req == REQ_EXPORT && result == Activity.RESULT_OK) data?.data?.let { doExport(it) }
    }

    private fun doExport(uri: Uri) {
        Thread {
            val msg = try {
                val res = data ?: CompareBuilder.build(db, unknownLabels(act))
                val os = act.contentResolver.openOutputStream(uri, "wt") ?: throw IllegalStateException("output")
                val n = os.use { Exports.compare(act, res, it) }
                fmtS(R.string.export_done, n)
            } catch (e: Exception) {
                fmtS(R.string.export_failed, e.message ?: "")
            }
            ui.post { toast(msg) }
        }.start()
    }

    // تُنفَّذ بعد تهيئة كل الخصائص أعلاه (ترتيب التهيئة في كوتلين نصّي)
    init {
        list.divider = null
        list.dividerHeight = 0
        list.setSelector(android.R.color.transparent)
        list.isVerticalScrollBarEnabled = false
        list.overScrollMode = View.OVER_SCROLL_NEVER
        list.addHeaderView(buildHeader(), null, false)
        list.adapter = adapter
        addView(list, LayoutParams(-1, -1))
    }

    companion object {
        const val REQ_EXPORT = 132
    }
}
