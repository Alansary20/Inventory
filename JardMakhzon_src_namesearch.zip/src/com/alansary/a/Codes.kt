package com.alansary.a

import android.content.Context

/** تمييز الباركود عن رقم الصنف عن الاسم بمحتوى القيمة نفسها (لا بمكان العمود). */
object Codes {
    private val barcodeRe = Regex("^\\d{8,14}$")                               // EAN/UPC: أرقام فقط
    private val itemRe = Regex("^[A-Za-z0-9]+(?:[-_/.][A-Za-z0-9]+)+$")          // أجزاء بفاصل (-) وبلا مسافات

    fun isBarcode(s: String): Boolean = barcodeRe.matches(s.trim())

    fun isItemNo(s: String): Boolean {
        val t = s.trim()
        return t.length <= 40 && !isBarcode(t) && itemRe.matches(t) && t.any { it.isDigit() }
    }

    /** نص وصفي: فيه حروف ومسافات (أو طويل)، وليس باركوداً ولا رقم صنف. */
    fun looksLikeName(s: String): Boolean {
        val t = s.trim()
        return !isBarcode(t) && !isItemNo(t) && t.any { it.isLetter() } && (t.contains(' ') || t.length >= 8)
    }

    /** نص يستحق البحث بالاسم: فيه حرف، وليس باركوداً ولا رقم صنف (حتى لو كلمة واحدة قصيرة). */
    fun searchableAsName(s: String): Boolean {
        val t = s.trim()
        return !isBarcode(t) && !isItemNo(t) && t.any { it.isLetter() }
    }

    private val tashkeel = Regex("[\\u064B-\\u065F\\u0670\\u0640]")
    private val splitRe = Regex("[^\\p{L}\\p{N}]+")

    /** كلمات الاسم بعد التطبيع: حروف صغيرة، توحيد الهمزات والياء والتاء المربوطة، أرقام لاتينية، بلا رموز. */
    fun normTokens(s: String): List<String> {
        var t = tashkeel.replace(s.lowercase(), "")
        t = t.replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا').replace('ى', 'ي').replace('ة', 'ه')
        val sb = StringBuilder(t.length)
        for (ch in t) sb.append(when (ch) {
            in '٠'..'٩' -> '0' + (ch - '٠')
            in '۰'..'۹' -> '0' + (ch - '۰')
            else -> ch
        })
        return sb.toString().split(splitRe).filter { it.isNotEmpty() }
    }

    /** مفتاح الاسم: مجموعة الكلمات مرتبة، فيتطابق «مارين رجالي H2O 150 مل» مع «مارين رجالي 150 مل H2O». */
    fun nameKey(s: String): String = normTokens(s).distinct().sorted().joinToString(" ")

    /** يوزّع قيمتين على مكانهما الصحيح: لو كان الباركود في خانة رقم الصنف أو العكس يبدّلهما. */
    fun fix(barcode: String, itemNo: String): Pair<String, String> {
        var b = barcode.trim()
        var i = itemNo.trim()
        if (b.isNotEmpty() && !isBarcode(b) && isItemNo(b)) {
            if (i.isEmpty() || isBarcode(i)) { val t = i; i = b; b = t }
        }
        if (i.isNotEmpty() && isBarcode(i) && !isBarcode(b)) {
            if (b.isEmpty() || isItemNo(b)) { val t = b; b = i; i = t }
        }
        return Pair(b, i)
    }
}

/** كل صيغ «غير معروف» (عربي/إنجليزي) لإعادة التعرف على الأصناف المجهولة بعد رفع المنتجات أو الرصيد. */
fun unknownLabels(ctx: Context): List<String> =
    listOf(ctx.getString(R.string.unknown_name), "❓ غير معروف", "❓ Unknown").distinct()
