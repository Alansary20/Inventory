package com.alansary.a

import android.content.Context
import android.net.Uri
import java.util.UUID

class ProductImporter(context: Context) {
    class Source(val uri: Uri, val name: String)
    /** ملاحظة على صف في الملف (تُعرض في تقرير الاستيراد وتُصدَّر). */
    class Issue(val file: String, val row: Int, val reason: Int, val cells: List<String>)
    class Result {
        var added = 0; var updated = 0; var skipped = 0
        var badPrice = 0; var dupBarcode = 0; var dupItem = 0
        val issues = ArrayList<Issue>()
    }

    companion object {
        const val R_NO_CODE = 1        // بلا باركود ولا رقم صنف (تُخطّي)
        const val R_BAD_PRICE = 2      // سعر غير مفهوم (استُورد بصفر)
        const val R_DUP_BARCODE = 3    // نفس الباركود لصنفين مختلفين
        const val R_DUP_ITEM = 4       // رقم الصنف مكرر في الملف
        private const val MAX_ISSUES = 5000
        private val TRAIL_ZEROS = Regex("\\.0+$")
        private val CODE_SEP = Regex("[,;،؛\n\r\t|]+")
        private val WS = Regex("\\s+")
    }

    private val ctx = context.applicationContext
    private val db = Db.get(context)

    /** تنظيف الكود: أرقام عربية→لاتينية، حذف الرموز الخفية والمسافات، علامة ' في البداية، و .0 في النهاية. */
    private fun cleanCode(s: String?): String {
        if (s == null) return ""
        val sb = StringBuilder(s.length)
        for (ch in s) when (ch) {
            in '\u0660'..'\u0669' -> sb.append('0' + (ch - '\u0660'))
            in '\u06F0'..'\u06F9' -> sb.append('0' + (ch - '\u06F0'))
            '\u200B', '\u200C', '\u200D', '\u200E', '\u200F', '\uFEFF' -> {}
            '\u00A0' -> sb.append(' ')
            else -> sb.append(ch)
        }
        var t = sb.toString().trim()
        if (t.startsWith("'") || t.startsWith("\u2019")) t = t.substring(1).trim()
        t = t.replace(TRAIL_ZEROS, "")
        if (t.isNotEmpty() && t.all { it.isDigit() || it == ' ' }) t = t.replace(" ", "")
        return t
    }
    /** تقسيم خانة الباركود إلى عدة باركودات: بفاصلة/فاصلة منقوطة/سطر جديد/|، أو بمسافات إن كانت كل القطع أرقام باركود. */
    private fun splitCodes(s: String): List<String> {
        val parts = s.split(CODE_SEP).map { it.trim() }.filter { it.isNotEmpty() }
        val out = ArrayList<String>()
        for (p in parts) {
            val sp = p.split(WS).filter { it.isNotEmpty() }
            if (sp.size > 1 && sp.all { Codes.isBarcode(cleanCode(it)) }) out.addAll(sp) else out.add(p)
        }
        return out
    }
    private fun number(s: String?): Double? {
        if (s == null) return null
        val sb = StringBuilder(s.length)
        for (ch in s.trim()) when (ch) {
            in '\u0660'..'\u0669' -> sb.append('0' + (ch - '\u0660'))
            in '\u06F0'..'\u06F9' -> sb.append('0' + (ch - '\u06F0'))
            '\u066B' -> sb.append('.')                 // الفاصلة العشرية العربية
            ',', '\u066C', ' ', '\u00A0' -> {}
            else -> sb.append(ch)
        }
        return sb.toString().toDoubleOrNull()
    }
    private fun cell(row: List<String>, i: Int) = if (i >= 0 && i < row.size) row[i] else ""

    private fun index(p: Product, byItemNo: MutableMap<String, Product>, byBarcode: MutableMap<String, Product>) {
        if (p.itemNo.isNotEmpty()) byItemNo[p.itemNo] = p
        if (p.barcode.isNotEmpty()) byBarcode[p.barcode] = p
        for (a in p.altList()) byBarcode[a] = p
    }

    fun run(
        sources: List<Source>, map: ColMap, merge: Boolean, noNameLabel: String,
        progress: (fraction: Float, label: String) -> Unit
    ): Result {
        progress(0.02f, "")
        if (!merge) db.clearProducts()

        val byItemNo = HashMap<String, Product>()
        val byBarcode = HashMap<String, Product>()
        if (merge) db.allProducts().forEach { index(it, byItemNo, byBarcode) }

        val sourceId = System.currentTimeMillis()
        val res = Result()
        val barcodeItem = HashMap<String, String>()      // لكشف باركود واحد لصنفين
        val seenItem = HashSet<String>()                  // لكشف رقم صنف مكرر
        val touched = HashSet<String>()                   // منتجات حُدِّثت/أُضيفت في هذا الاستيراد
        fun note(src: Source, ri: Int, reason: Int, row: List<String>) {
            if (res.issues.size < MAX_ISSUES) res.issues.add(Issue(src.name, ri + 1, reason, row))
        }

        sources.forEachIndexed { fi, src ->
            progress(0.05f + 0.9f * fi / sources.size, src.name)
            val rows = TableReader.read(ctx, src.uri)
            val from = if (map.noHeader) 0 else 1
            val total = maxOf(0, rows.size - from)
            var start = from
            while (start < rows.size) {
                val end = minOf(start + 500, rows.size)
                val changed = ArrayList<Product>()
                for (ri in start until end) {
                    val row = rows[ri]
                    val bParts = splitCodes(cell(row, map.barcode)).map { cleanCode(it) }.filter { it.isNotEmpty() }
                    val (barcode, itemNo) = Codes.fix(bParts.firstOrNull() ?: "", cleanCode(cell(row, map.itemNo)))
                    // كل باركودات الصف: الأول رئيسي والباقي إضافية (خانة واحدة بعدة باركودات)
                    val allB = LinkedHashSet<String>()
                    if (barcode.isNotEmpty()) allB.add(barcode)
                    for (k in 1 until bParts.size) if (bParts[k].isNotEmpty() && bParts[k] != itemNo) allB.add(bParts[k])
                    val name = cell(row, map.name).trim()
                    val priceOrig = if (map.priceOrig >= 0) number(cell(row, map.priceOrig)) ?: 0.0 else 0.0
                    val priceSale = (if (map.priceSale >= 0) number(cell(row, map.priceSale)) else null) ?: priceOrig
                    if (barcode.isEmpty() && itemNo.isEmpty()) { res.skipped++; note(src, ri, R_NO_CODE, row); continue }
                    if (map.priceOrig >= 0 && cell(row, map.priceOrig).isNotBlank() && number(cell(row, map.priceOrig)) == null) {
                        res.badPrice++; note(src, ri, R_BAD_PRICE, row)
                    }
                    if (barcode.isNotEmpty()) {
                        val prev = barcodeItem[barcode]
                        if (prev == null) barcodeItem[barcode] = itemNo
                        else if (prev.isNotEmpty() && itemNo.isNotEmpty() && prev != itemNo) { res.dupBarcode++; note(src, ri, R_DUP_BARCODE, row) }
                    }
                    // رقم الصنف المتكرر بباركود جديد ليس خطأ (باركودات متعددة لصنف واحد)؛ نُبلّغ فقط عن التكرار الحقيقي
                    if (itemNo.isNotEmpty() && !seenItem.add(itemNo)) {
                        val known = byItemNo[itemNo]
                        val trulyDup = allB.isEmpty() || known == null ||
                            allB.all { it == known.barcode || known.altList().contains(it) }
                        if (trulyDup) { res.dupItem++; note(src, ri, R_DUP_ITEM, row) }
                    }

                    // الضم بنفس رقم الصنف (أو الباركود) يعمل في الدمج والاستبدال معاً
                    // لا دمج تلقائي للمكرر: المنتج الذي حُدِّث أو أُضيف في هذا الاستيراد لا يُضَمّ إليه صف آخر
                    // (الدمج يدوياً بزر «دمج المنتجات المكررة»)
                    val existing = ((if (itemNo.isNotEmpty()) byItemNo[itemNo] else null)
                        ?: allB.firstNotNullOfOrNull { byBarcode[it] })?.takeIf { it.id !in touched }
                    if (existing != null) {
                        // نحدّث الاسم والأسعار ونضيف الباركودات الجديدة كباركودات إضافية
                        val alts = existing.altList()
                        var main = existing.barcode
                        for (b in allB) {
                            if (b == main) continue
                            if (main.isEmpty()) main = b else if (!alts.contains(b)) alts.add(b)
                        }
                        // الأسعار: تُحدَّث من الملف إن كان عمود السعر محدداً وفيه رقم صحيح، وإلا يبقى السعر الحالي
                        val hasOrig = map.priceOrig >= 0 && number(cell(row, map.priceOrig)) != null
                        val hasSale = map.priceSale >= 0 && number(cell(row, map.priceSale)) != null
                        val p = existing.copy(
                            barcode = main, altBarcodes = alts.joinToString(","),
                            itemNo = itemNo.ifEmpty { existing.itemNo }, name = name.ifEmpty { existing.name },
                            priceOrig = if (hasOrig) priceOrig else existing.priceOrig,
                            priceSale = if (hasSale || hasOrig) priceSale else existing.priceSale
                        )
                        changed.add(p); index(p, byItemNo, byBarcode); touched.add(p.id); res.updated++
                        continue
                    }
                    val p = Product(
                        id = UUID.randomUUID().toString(), barcode = barcode, itemNo = itemNo,
                        altBarcodes = allB.drop(1).joinToString(","),
                        name = name.ifEmpty { noNameLabel }, priceOrig = priceOrig, priceSale = priceSale, sourceId = sourceId
                    )
                    changed.add(p)
                    touched.add(p.id)
                    res.added++
                }
                db.upsertProducts(changed)
                start = end
                val done = start - from
                progress(0.05f + 0.9f * (fi + done.toFloat() / maxOf(1, total)) / sources.size, "${src.name}  $done / $total")
            }
            db.addUploadedFile(src.name, "products")
        }
        progress(1f, "")
        return res
    }

    /** دمج المنتجات المكررة (نفس رقم الصنف، أو نفس الباركود عند غياب رقم الصنف). يعيد عدد المحذوف. */
    fun dedupe(): Int {
        val groups = LinkedHashMap<String, MutableList<Product>>()
        for (p in db.allProducts()) {
            val key = if (p.itemNo.isNotEmpty()) "i:${p.itemNo}" else if (p.barcode.isNotEmpty()) "b:${p.barcode}" else "x:${p.id}"
            groups.getOrPut(key) { ArrayList() }.add(p)
        }
        val toDelete = ArrayList<String>()
        val toUpsert = ArrayList<Product>()
        for (g in groups.values) {
            if (g.size < 2) continue
            val keeper = g[0]
            val codes = LinkedHashSet<String>()
            for (p in g) { if (p.barcode.isNotEmpty()) codes.add(p.barcode); codes.addAll(p.altList()) }
            val main = if (keeper.barcode.isNotEmpty()) keeper.barcode else (codes.firstOrNull() ?: "")
            codes.remove(main)
            toUpsert.add(keeper.copy(
                barcode = main, altBarcodes = codes.joinToString(","),
                name = g.map { it.name }.firstOrNull { it.isNotBlank() } ?: keeper.name,
                priceOrig = g.map { it.priceOrig }.firstOrNull { it != 0.0 } ?: 0.0,
                priceSale = g.map { it.priceSale }.firstOrNull { it != 0.0 } ?: 0.0
            ))
            g.drop(1).forEach { toDelete.add(it.id) }
        }
        db.deleteProducts(toDelete)
        db.upsertProducts(toUpsert)
        return toDelete.size
    }
}
