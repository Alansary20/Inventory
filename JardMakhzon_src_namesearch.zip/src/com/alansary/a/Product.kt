package com.alansary.a

data class Product(
    var id: String = "",
    var barcode: String = "",
    var itemNo: String = "",
    var name: String = "",
    var altBarcodes: String = "", // مفصولة بفاصلة
    var priceOrig: Double = 0.0,
    var priceSale: Double = 0.0,
    var sourceId: Long = 0L
) {
    fun altList(): MutableList<String> =
        altBarcodes.split(',').map { it.trim() }.filter { it.isNotEmpty() }.toMutableList()
}
