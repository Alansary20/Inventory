package com.alansary.a

import android.content.Context
import android.graphics.ImageFormat
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.util.Size
import android.view.SurfaceHolder
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.barcode.BarcodeScanner
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.TimeUnit

/** كاميرا Camera2 + قارئ ML Kit (النموذج مضمَّن في التطبيق، يعمل دون إنترنت). فك الباركود على خيط خلفي. */
class CameraScanner(
    private val ctx: Context,
    private val onCode: (String) -> Unit,
    private val onError: (String) -> Unit
) {
    class Cam(val id: String, val label: String, val back: Boolean)

    companion object {
        private fun mgr(ctx: Context) = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager

        fun list(ctx: Context): List<Cam> = try {
            val m = mgr(ctx)
            m.cameraIdList.mapNotNull { id ->
                val ch = m.getCameraCharacteristics(id)
                // نستبعد العدسات المساعدة التي لا تعطي صورة عادية (عمق/ToF...) ولا تدعم YUV
                val caps = ch.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: IntArray(0)
                val compat = caps.isEmpty() || caps.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_BACKWARD_COMPATIBLE)
                val hasYuv = (ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)?.getOutputSizes(ImageFormat.YUV_420_888)?.size ?: 0) > 0
                if (!compat || !hasYuv) return@mapNotNull null
                val facing = ch.get(CameraCharacteristics.LENS_FACING)
                val back = facing == CameraCharacteristics.LENS_FACING_BACK
                // البعد البؤري المكافئ (35mm) ليعرف المستخدم العدسة الرئيسية من الواسعة/المقرّبة
                var mm = ""
                try {
                    val f = ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull()
                    val sz = ch.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)
                    if (f != null && sz != null) {
                        val diag = Math.sqrt((sz.width * sz.width + sz.height * sz.height).toDouble())
                        mm = " · " + Math.round(f * 43.27 / diag) + "mm"
                    }
                } catch (_: Exception) {}
                Cam(id, "camera $id, facing " + (if (back) "back" else if (facing == CameraCharacteristics.LENS_FACING_FRONT) "front" else "external") + mm, back)
            }.sortedWith(compareBy({ !it.back }, { it.id.toIntOrNull() ?: 99 }))
        } catch (_: Exception) { emptyList() }

        /** أفضل عدسة تلقائياً للمسح: خلفية، تركيز تلقائي مستمر، فلاش، وزاوية قريبة من الرئيسية (~26mm). */
        fun bestFirst(ctx: Context, cams: List<Cam>): List<Cam> {
            fun score(c: Cam): Int = if (!c.back) -100 else try {
                val ch = mgr(ctx).getCameraCharacteristics(c.id)
                var sc = 0
                val af = ch.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES) ?: IntArray(0)
                if (af.contains(CameraCharacteristics.CONTROL_AF_MODE_CONTINUOUS_PICTURE)) sc += 4
                if (ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true) sc += 2
                val f = ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull()
                val sz = ch.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)
                if (f != null && sz != null) {
                    val eq = f * 43.27 / Math.sqrt((sz.width * sz.width + sz.height * sz.height).toDouble())
                    if (Math.abs(eq - 26.0) <= 8.0) sc += 3
                }
                sc
            } catch (_: Exception) { 0 }
            return cams.sortedByDescending { score(it) }     // الترتيب ثابت: عند التعادل تبقى الأقل رقماً أولاً
        }

        /** حجم التحليل: أكبر 4:3 حتى ~5 ميجابكسل (الباركودات الصغيرة تحتاج دقة أعلى من المعاينة). */
        fun analysisSize(ctx: Context, id: String, base: Size): Size = try {
            val map = mgr(ctx).getCameraCharacteristics(id).get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            val sizes = map?.getOutputSizes(ImageFormat.YUV_420_888)?.toList() ?: emptyList()
            sizes.filter { it.width * base.height == it.height * base.width && it.width in base.width..2600 }
                .maxByOrNull { it.width } ?: base
        } catch (_: Exception) { base }

        /** حجم المعاينة: نفضّل 4:3 بعرض قريب من 1280. */
        fun chooseSize(ctx: Context, id: String): Size? = try {
            val map = mgr(ctx).getCameraCharacteristics(id).get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            val sizes = map?.getOutputSizes(ImageFormat.YUV_420_888)?.toList() ?: emptyList()
            val ratio = sizes.filter { it.width * 3 == it.height * 4 && it.width <= 1600 }
            (ratio.maxByOrNull { it.width }
                ?: sizes.filter { it.width <= 1600 }.minByOrNull { Math.abs(it.width - 1280) + Math.abs(it.height - 720) }
                ?: sizes.minByOrNull { Math.abs(it.width - 1280) })
        } catch (_: Exception) { null }
    }

    private val AIM_PREFIX = Regex("^\\][A-Za-z][0-9A-Za-z]")
    private val main = Handler(Looper.getMainLooper())
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var reader: ImageReader? = null
    @Volatile private var closed = true
    @Volatile private var gotFrame = false
    private var gen = 0
    private var retries = 0
    private var lastId: String? = null
    private var lastHolder: SurfaceHolder? = null
    private var lastSize: Size? = null
    @Volatile private var sensorRot = 90
    private var reqBuilder: CaptureRequest.Builder? = null

    @Volatile private var mlk: BarcodeScanner? = null

    /** يعيد [نسبة العرض الظاهر، نسبة الارتفاع الظاهر]؛ لا يُقبل إلا باركود مركزه داخل المعاينة. */
    @Volatile var viewport: (() -> FloatArray)? = null

    private fun newScanner(): BarcodeScanner = BarcodeScanning.getClient(
        BarcodeScannerOptions.Builder().setBarcodeFormats(
            Barcode.FORMAT_EAN_13, Barcode.FORMAT_EAN_8, Barcode.FORMAT_UPC_A, Barcode.FORMAT_UPC_E,
            Barcode.FORMAT_CODE_128, Barcode.FORMAT_CODE_39, Barcode.FORMAT_CODE_93, Barcode.FORMAT_ITF,
            Barcode.FORMAT_CODABAR
        ).build()
    )

    fun start(id: String, holder: SurfaceHolder, size: Size, fromRetry: Boolean = false) {
        stop()
        if (!fromRetry) retries = 0
        lastId = id; lastHolder = holder; lastSize = size
        gotFrame = false
        closed = false
        mlk = newScanner()
        val t = HandlerThread("cam-scan").also { it.start() }
        thread = t
        val h = Handler(t.looper)
        handler = h
        try {
            val ch = mgr(ctx).getCameraCharacteristics(id)
            sensorRot = ch.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
            val afModes = ch.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES) ?: IntArray(0)
            // أول محاولة بدقة عالية؛ لو فشلت الجلسة تعود المحاولات التالية للحجم الآمن
            val an = if (retries == 0) analysisSize(ctx, id, size) else size
            val rd = ImageReader.newInstance(an.width, an.height, ImageFormat.YUV_420_888, 2)
            reader = rd
            var busy = false
            rd.setOnImageAvailableListener({ r ->
                val img = r.acquireLatestImage() ?: return@setOnImageAvailableListener
                gotFrame = true
                try {
                    if (closed || busy) return@setOnImageAvailableListener
                    busy = true
                    try { decode(img) } catch (_: Exception) {}
                } finally {
                    busy = false
                    img.close()
                }
            }, h)

            mgr(ctx).openCamera(id, object : CameraDevice.StateCallback() {
                override fun onOpened(cam: CameraDevice) {
                    if (closed) { cam.close(); return }
                    device = cam
                    try {
                        val surfaces = listOf(holder.surface, rd.surface)
                        cam.createCaptureSession(surfaces, object : CameraCaptureSession.StateCallback() {
                            override fun onConfigured(s: CameraCaptureSession) {
                                if (closed) { s.close(); return }
                                session = s
                                try {
                                    val req = cam.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
                                    req.addTarget(holder.surface)
                                    req.addTarget(rd.surface)
                                    if (afModes.contains(CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE))
                                        req.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
                                    reqBuilder = req
                                    s.setRepeatingRequest(req.build(), null, h)
                                    // لو لم تصل أي صورة خلال 3 ثوانٍ (شاشة سوداء) نعيد التشغيل تلقائياً
                                    val g = gen
                                    main.postDelayed({ if (!closed && gen == g && !gotFrame) retryOrFail("no frames", 0L) }, 3000L)
                                } catch (e: Exception) { fail(e.message) }
                            }
                            override fun onConfigureFailed(s: CameraCaptureSession) { retryOrFail("configure failed", 0L) }
                        }, h)
                    } catch (e: Exception) { fail(e.message) }
                }
                override fun onDisconnected(cam: CameraDevice) { cam.close(); retryOrFail("disconnected", 600L) }
                override fun onError(cam: CameraDevice, error: Int) {
                    cam.close()
                    // 1 = الكاميرا مستخدمة، 2 = تجاوز عدد الكاميرات: غالباً مؤقت بعد إغلاق سابق فنعيد المحاولة
                    if (error == 1 || error == 2) retryOrFail("error $error", 600L) else fail("error $error")
                }
            }, h)
        } catch (e: SecurityException) {
            fail("permission")
        } catch (e: CameraAccessException) {
            fail(e.message)
        } catch (e: Exception) {
            fail(e.message)
        }
    }

    private fun applyRepeating() {
        val rb = reqBuilder ?: return
        val s = session ?: return
        if (closed) return
        try { s.setRepeatingRequest(rb.build(), null, handler) } catch (_: Exception) {}
    }

    /** إعادة التركيز (عند لمس المعاينة). */
    fun refocus() {
        val rb = reqBuilder ?: return
        val s = session ?: return
        if (closed) return
        try {
            rb.set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_START)
            s.capture(rb.build(), null, handler)
            rb.set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_IDLE)
            applyRepeating()
        } catch (_: Exception) {}
    }

    /** إعادة تشغيل الكاميرا حتى 3 مرات قبل إظهار الخطأ. */
    private fun retryOrFail(msg: String, delayMs: Long) {
        if (closed) return
        val id = lastId; val h = lastHolder; val sz = lastSize
        if (retries < 3 && id != null && h != null && sz != null) {
            retries++
            val g = gen
            main.postDelayed({ if (!closed && gen == g) start(id, h, sz, true) }, delayMs)
        } else fail(msg)
    }

    private fun fail(msg: String?) {
        if (closed) return
        stop()
        main.post { onError(msg ?: "") }
    }

    fun stop() {
        closed = true
        gen++
        try { session?.close() } catch (_: Exception) {}
        try { device?.close() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        session = null; device = null; reader = null
        reqBuilder = null
        thread?.quitSafely()
        thread = null; handler = null
        try { mlk?.close() } catch (_: Exception) {}
        mlk = null
    }

    /** ML Kit يدوّر الإطار بنفسه حسب sensorRot، فلا حاجة لتدوير البايتات يدوياً. */
    private fun decode(img: android.media.Image) {
        val sc = mlk ?: return
        try {
            val input = InputImage.fromMediaImage(img, sensorRot)
            // نحن على خيط الكاميرا الخلفي، فالانتظار هنا آمن ويُبقي الصورة مفتوحة حتى انتهاء التحليل
            val list = Tasks.await(sc.process(input), 2, TimeUnit.SECONDS)
            val vp = try { viewport?.invoke() } catch (_: Exception) { null }
            val upright = sensorRot == 90 || sensorRot == 270
            val uw = (if (upright) img.height else img.width).toFloat()
            val uh = (if (upright) img.width else img.height).toFloat()
            val text = list.firstNotNullOfOrNull { b ->
                val v = b.rawValue?.takeIf { it.isNotEmpty() } ?: return@firstNotNullOfOrNull null
                val bb = b.boundingBox
                if (vp == null || bb == null) v
                else {
                    val cx = bb.exactCenterX() / uw - 0.5f
                    val cy = bb.exactCenterY() / uh - 0.5f
                    if (Math.abs(cx) <= vp[0] / 2f && Math.abs(cy) <= vp[1] / 2f) v else null
                }
            }
            if (text != null && !closed) {
                // ML Kit قد يُرجع معرّف الترميز AIM في البداية (مثل ]C1 لـ Code 128 / GS1) وفواصل FNC1؛ نحذفها
                val clean = text.replace(AIM_PREFIX, "").replace("\u001D", "").trim()
                if (clean.isNotEmpty()) main.post { if (!closed) onCode(clean) }
            }
        } catch (_: Exception) {
            // لا باركود في هذا الإطار (أو أُغلق القارئ أثناء التحليل)
        }
    }
}
