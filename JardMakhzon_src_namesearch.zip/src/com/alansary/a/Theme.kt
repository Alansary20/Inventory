package com.alansary.a

import android.content.Context

/** نفس متغيرات الألوان في النسخة الأصلية (CSS variables). */
class Theme private constructor(val dark: Boolean) {
    val bg: Int; val surface: Int; val surface2: Int; val surface3: Int; val border: Int
    val accent: Int; val accent2: Int; val danger: Int; val negative: Int; val text: Int; val muted: Int

    init {
        if (dark) {
            bg = 0xFF0F0814.toInt(); surface = 0xFF0D1520.toInt(); surface2 = 0xFF112030.toInt(); surface3 = 0xFF162A3E.toInt()
            border = 0x12FFFFFF; accent = 0xFF10B981.toInt(); accent2 = 0xFF059669.toInt(); danger = 0xFFDC2626.toInt()
            text = 0xFFE8EDF5.toInt(); muted = 0xFF6B7A9A.toInt(); negative = 0xFFFB7185.toInt()
        } else {
            bg = 0xFFFFFFFF.toInt(); surface = 0xFFFFFFFF.toInt(); surface2 = 0xFFF9F9F9.toInt(); surface3 = 0xFFF3F3F3.toInt()
            border = 0x1C000000; accent = 0xFF059669.toInt(); accent2 = 0xFF047857.toInt(); danger = 0xFFE05555.toInt()
            text = 0xFF1A1A2E.toInt(); muted = 0xFF6B7280.toInt(); negative = 0xFFDC2626.toInt()
        }
    }

    companion object {
        fun of(c: Context): Theme {
            return Theme(Settings.theme(c) == "dark")
        }

        fun alpha(color: Int, a: Float): Int = (Math.round(255 * a) shl 24) or (color and 0x00FFFFFF)
    }
}
