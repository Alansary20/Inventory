package com.alansary.a

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.util.Locale
import java.util.zip.ZipException

/** يقرأ ملف Excel (xlsx) أو CSV من Uri ويعيد الصفوف. */
object TableReader {

    fun fileName(ctx: Context, uri: Uri): String {
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0) c.getString(i)?.let { return it }
                }
            }
        } catch (_: Exception) {}
        return uri.lastPathSegment ?: "file"
    }

    /** الورقة المختارة لكل ملف (uri → رقم الورقة)، الافتراضي الأولى. */
    private val sheetChoice = HashMap<String, Int>()
    fun setSheet(uri: Uri, index: Int) { synchronized(sheetChoice) { sheetChoice[uri.toString()] = index } }
    private fun sheetOf(uri: Uri) = synchronized(sheetChoice) { sheetChoice[uri.toString()] ?: 0 }

    /** أسماء الأوراق إن كان الملف xlsx بأكثر من ورقة، وإلا قائمة فارغة. */
    fun sheetNames(ctx: Context, uri: Uri): List<String> {
        val name = fileName(ctx, uri).lowercase(Locale.ROOT)
        if (name.endsWith(".csv") || name.endsWith(".txt") || name.endsWith(".tsv")) return emptyList()
        val tmp = File.createTempFile("sheets_", ".tmp", ctx.cacheDir)
        return try {
            val input = ctx.contentResolver.openInputStream(uri) ?: return emptyList()
            input.use { i -> tmp.outputStream().use { o -> copyLimited(i, o) } }
            if (XlsReader.isXls(tmp)) XlsReader.sheetNames(tmp) else XlsxReader.sheets(tmp).map { it.name }
        } catch (_: Exception) { emptyList() } finally { tmp.delete() }
    }

    /** يفك الترميز: UTF-8 (مع/بدون BOM)، UTF-16، وإلا Windows-1256 (ملفات إكسل العربية القديمة). */
    fun decodeText(b: ByteArray): String {
        if (b.size >= 3 && b[0] == 0xEF.toByte() && b[1] == 0xBB.toByte() && b[2] == 0xBF.toByte())
            return String(b, 3, b.size - 3, Charsets.UTF_8)
        if (b.size >= 2 && b[0] == 0xFF.toByte() && b[1] == 0xFE.toByte()) return String(b, 2, b.size - 2, Charsets.UTF_16LE)
        if (b.size >= 2 && b[0] == 0xFE.toByte() && b[1] == 0xFF.toByte()) return String(b, 2, b.size - 2, Charsets.UTF_16BE)
        try {
            return Charsets.UTF_8.newDecoder()
                .onMalformedInput(java.nio.charset.CodingErrorAction.REPORT)
                .onUnmappableCharacter(java.nio.charset.CodingErrorAction.REPORT)
                .decode(java.nio.ByteBuffer.wrap(b)).toString()
        } catch (_: Exception) {}
        return try { String(b, java.nio.charset.Charset.forName("windows-1256")) } catch (_: Exception) { String(b, Charsets.ISO_8859_1) }
    }

    /** حد أقصى لحجم الملف المستورد (حماية من انهيار الذاكرة بملف ضخم أو خبيث). */
    const val MAX_FILE_BYTES = 120L * 1024 * 1024

    /** نسخ محدود الحجم: يرفض الملف بدل أن يملأ التخزين. */
    private fun copyLimited(i: java.io.InputStream, o: java.io.OutputStream) {
        val buf = ByteArray(64 * 1024); var total = 0L
        while (true) {
            val n = i.read(buf); if (n < 0) break
            total += n
            if (total > MAX_FILE_BYTES) throw IllegalArgumentException("الملف كبير جدًا (الحد 120 ميغابايت)")
            o.write(buf, 0, n)
        }
    }

    fun read(ctx: Context, uri: Uri): List<List<String>> {
        val name = fileName(ctx, uri).lowercase(Locale.ROOT)
        val tmp = File.createTempFile("import_", ".tmp", ctx.cacheDir)
        try {
            val input = ctx.contentResolver.openInputStream(uri) ?: throw IllegalArgumentException("تعذّر فتح الملف")
            input.use { i -> tmp.outputStream().use { o -> copyLimited(i, o) } }
            if (name.endsWith(".csv") || name.endsWith(".txt") || name.endsWith(".tsv")) {
                return parseCsv(decodeText(tmp.readBytes()))
            }
            if (XlsReader.isXls(tmp)) return XlsReader.read(tmp, sheetOf(uri))
            try {
                return XlsxReader.read(tmp, sheetOf(uri))
            } catch (_: ZipException) {
                throw IllegalArgumentException("صيغة الملف غير مدعومة. استخدم ملف .xls أو .xlsx أو .csv")
            }
        } finally {
            tmp.delete()
        }
    }

    fun parseCsv(textIn: String): List<List<String>> {
        val text = textIn.removePrefix("\uFEFF")
        val firstLine = text.substringBefore('\n')
        val delim = listOf(',', ';', '\t').maxByOrNull { d -> firstLine.count { it == d } } ?: ','
        val rows = ArrayList<List<String>>()
        var row = ArrayList<String>()
        val cell = StringBuilder()
        var inQuotes = false
        fun endRow() {
            row.add(cell.toString()); cell.setLength(0)
            while (row.isNotEmpty() && row.last().isBlank()) row.removeAt(row.size - 1)
            if (row.isNotEmpty()) rows.add(row)
            row = ArrayList()
        }
        var i = 0
        while (i < text.length) {
            val ch = text[i]
            if (inQuotes) {
                if (ch == '"') {
                    if (i + 1 < text.length && text[i + 1] == '"') { cell.append('"'); i++ } else inQuotes = false
                } else cell.append(ch)
            } else when (ch) {
                '"' -> inQuotes = true
                delim -> { row.add(cell.toString()); cell.setLength(0) }
                '\n' -> endRow()
                '\r' -> {}
                else -> cell.append(ch)
            }
            i++
        }
        if (cell.isNotEmpty() || row.isNotEmpty()) endRow()
        return rows
    }
}
