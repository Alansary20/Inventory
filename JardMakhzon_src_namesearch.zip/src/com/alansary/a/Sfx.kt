package com.alansary.a

import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper

/**
 * أصوات قصيرة مولّدة برمجياً (بدون ملفات صوت):
 * زيادة = نغمتان صاعدتان (رنين)، نقص = نغمتان هابطتان أخفض. تختلفان عن صفير المسح.
 */
object Sfx {
    private const val RATE = 22050
    private val handler = Handler(Looper.getMainLooper())

    private fun synth(notes: List<Pair<Double, Int>>, gain: Double = 0.55): ShortArray {
        val total = notes.sumOf { RATE * it.second / 1000 }
        val out = ShortArray(total)
        var pos = 0
        for ((f, ms) in notes) {
            val n = RATE * ms / 1000
            for (i in 0 until n) {
                val tt = i.toDouble() / RATE
                val attack = minOf(1.0, i / (RATE * 0.008))            // بداية ناعمة بلا طقطقة
                val decay = Math.exp(-3.2 * i.toDouble() / n)           // خفوت سريع كالجرس
                val wave = (Math.sin(2 * Math.PI * f * tt) + 0.25 * Math.sin(4 * Math.PI * f * tt)) / 1.25
                out[pos + i] = (wave * attack * decay * gain * Short.MAX_VALUE).toInt().toShort()
            }
            pos += n
        }
        return out
    }

    private val upData by lazy { synth(listOf(660.0 to 80, 880.0 to 150)) }
    private val downData by lazy { synth(listOf(520.0 to 80, 340.0 to 160)) }

    private fun play(data: ShortArray) {
        Thread {
            var track: AudioTrack? = null
            try {
                val tr = AudioTrack(AudioManager.STREAM_MUSIC, RATE, AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, data.size * 2, AudioTrack.MODE_STATIC)
                track = tr
                tr.write(data, 0, data.size)
                tr.play()
                handler.postDelayed({
                    try { tr.stop(); tr.release() } catch (_: Exception) {}
                }, data.size * 1000L / RATE + 200)
            } catch (_: Exception) {
                try { track?.release() } catch (_: Exception) {}   // لا نترك المسار الأصلي معلّقاً عند الفشل
            }
        }.start()
    }

    fun up() = play(upData)
    fun down() = play(downData)
}
