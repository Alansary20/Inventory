package com.alansary.a

import android.content.Context
import android.graphics.Rect
import android.view.View
import android.widget.ListView

/**
 * قائمة لا تتحرك وحدها.
 * - عند تغيّر ارتفاعها (لوحة المفاتيح) يحاول ListView اختيار أول عنصر قابل للتحديد وإظهاره،
 *   فيقفز إلى نهاية الرأس الطويل؛ لذلك لا نستدعي onSizeChanged الأصلية فيبقى موضع أول صف كما هو.
 * - يتجاهل طلبات "أظهر هذا العنصر" من حقول الكتابة.
 */
class StillListView(ctx: Context) : ListView(ctx) {
    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        // عمداً بلا super: AbsListView.onSizeChanged تُفعّل مزامنة الاختيار التي تسبب القفز.
    }

    override fun requestChildRectangleOnScreen(child: View, rect: Rect, immediate: Boolean): Boolean = false
}
