package com.alansary.a

import android.app.Activity
import android.text.InputType
import android.widget.LinearLayout
import android.widget.Toast
import java.util.UUID

/** نافذة إضافة/تعديل منتج بتصميم البطاقة، مشتركة بين تبويبي المنتجات والأسعار. */
object ProductEditor {
    /** onDone يُستدعى على الخيط الرئيسي بعد الحفظ أو الحذف. */
    fun show(act: Activity, t: Theme, db: Db, p: Product, onDone: () -> Unit) {
        val ui = android.os.Handler(android.os.Looper.getMainLooper())
        val isNew = p.id.isEmpty()
        fun s(id: Int) = act.getString(id)
        val box = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        val dec = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        val barcode = CardDialog.field(act, t, box, s(R.string.f_barcode), p.barcode, InputType.TYPE_CLASS_TEXT)
        val itemNo = CardDialog.field(act, t, box, s(R.string.f_itemno), p.itemNo, InputType.TYPE_CLASS_TEXT)
        val name = CardDialog.field(act, t, box, s(R.string.f_name), p.name, InputType.TYPE_CLASS_TEXT)
        val orig = CardDialog.field(act, t, box, s(R.string.f_price_orig), if (isNew) "" else Ui.qty(p.priceOrig), dec)
        val sale = CardDialog.field(act, t, box, s(R.string.f_price_sale), if (isNew) "" else Ui.qty(p.priceSale), dec)
        val alt = CardDialog.field(act, t, box, s(R.string.f_alt), p.altBarcodes, InputType.TYPE_CLASS_TEXT)

        val cd = CardDialog(act, t)
            .title(s(if (isNew) R.string.add_product else R.string.edit_product), R.drawable.ic_dlg_edit)
            .content(box, scroll = true)
        cd.button(s(R.string.save), CardDialog.Kind.PRIMARY, dismiss = false) {
            val bc = barcode.text.toString().trim()
            val inNo = itemNo.text.toString().trim()
            if (bc.isEmpty() && inNo.isEmpty()) {
                Toast.makeText(act, s(R.string.need_code), Toast.LENGTH_SHORT).show()
            } else {
                val po = orig.text.toString().replace(",", "").trim().toDoubleOrNull() ?: 0.0
                val ps = sale.text.toString().replace(",", "").trim().toDoubleOrNull() ?: po
                val np = p.copy(
                    id = if (isNew) UUID.randomUUID().toString() else p.id,
                    barcode = bc, itemNo = inNo, name = name.text.toString().trim(),
                    priceOrig = po, priceSale = ps,
                    altBarcodes = alt.text.toString().split(',').map { it.trim() }.filter { it.isNotEmpty() }.joinToString(",")
                )
                cd.dismiss()
                Thread {
                    try {
                        db.upsertProducts(listOf(np))
                        ui.post { Toast.makeText(act, s(R.string.saved), Toast.LENGTH_SHORT).show(); onDone() }
                    } catch (e: Exception) {
                        ui.post { Toast.makeText(act, e.message ?: "error", Toast.LENGTH_LONG).show() }
                    }
                }.start()
            }
        }
        if (!isNew) {
            cd.button(s(R.string.delete), CardDialog.Kind.DANGER) {
                Thread {
                    try {
                        db.deleteProduct(p.id)
                        ui.post { Toast.makeText(act, s(R.string.deleted), Toast.LENGTH_SHORT).show(); onDone() }
                    } catch (e: Exception) {
                        ui.post { Toast.makeText(act, e.message ?: "error", Toast.LENGTH_LONG).show() }
                    }
                }.start()
            }
        }
        cd.button(s(R.string.cancel))
        cd.show()
    }
}
