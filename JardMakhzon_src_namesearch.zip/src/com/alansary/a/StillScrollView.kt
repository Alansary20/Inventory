package com.alansary.a

import android.content.Context
import android.graphics.Rect
import android.view.View
import android.widget.ScrollView

/**
 * ScrollView لا يتحرك وحده: يعطّل كل التمرير التلقائي لإظهار حقل الكتابة أو العنصر المركَّز
 * (عند فتح لوحة المفاتيح أو تغيّر الارتفاع أو الكتابة). التمرير باللمس فقط.
 */
class StillScrollView(ctx: Context) : ScrollView(ctx) {
    override fun computeScrollDeltaToGetChildRectOnScreen(rect: Rect): Int = 0
    override fun requestChildRectangleOnScreen(child: View, rectangle: Rect, immediate: Boolean): Boolean = false
}
