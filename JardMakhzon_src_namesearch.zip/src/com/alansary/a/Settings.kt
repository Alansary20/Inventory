package com.alansary.a

import android.content.Context

/** تفضيلات المستخدم: السمة (فاتح/داكن) واللغة. الافتراضي كما في النسخة الأصلية: نهاري وعربي. */
object Settings {
    private fun p(c: Context) = c.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun theme(c: Context): String = p(c).getString("theme", "light") ?: "light"
    fun setTheme(c: Context, v: String) { p(c).edit().putString("theme", v).apply() }

    fun lang(c: Context): String = p(c).getString("lang", "ar") ?: "ar"
    fun setLang(c: Context, v: String) { p(c).edit().putString("lang", v).apply() }
}
