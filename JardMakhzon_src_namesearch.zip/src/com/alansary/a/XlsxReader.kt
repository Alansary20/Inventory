package com.alansary.a

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.io.InputStream
import java.math.BigDecimal
import java.util.zip.ZipFile

/** قارئ xlsx بدون مكتبات خارجية: يقرأ أول ورقة ويعيد الصفوف كنصوص. */
object XlsxReader {
    /** حد أقصى لحجم أي جزء بعد فك الضغط (حماية من zip bomb). */
    private const val MAX_ENTRY_BYTES = 300L * 1024 * 1024

    private class Limited(private val inner: InputStream) : InputStream() {
        private var n = 0L
        override fun read(): Int { val b = inner.read(); if (b >= 0 && ++n > MAX_ENTRY_BYTES) tooBig(); return b }
        override fun read(b: ByteArray, off: Int, len: Int): Int {
            val r = inner.read(b, off, len); if (r > 0) { n += r; if (n > MAX_ENTRY_BYTES) tooBig() }; return r
        }
        override fun close() = inner.close()
        private fun tooBig(): Nothing = throw IllegalArgumentException("محتوى الملف كبير جدًا")
    }
    private fun ZipFile.open(e: java.util.zip.ZipEntry): InputStream = Limited(getInputStream(e))

    class Sheet(val name: String, val path: String)

    /** يقرأ الورقة رقم sheetIndex (الأولى افتراضياً). */
    fun read(file: File, sheetIndex: Int = 0): List<List<String>> {
        ZipFile(file).use { zip ->
            val se = zip.getEntry("xl/sharedStrings.xml")
            val shared = if (se != null) zip.open(se).use { parseShared(it) } else emptyList()
            val sheets = sheetList(zip)
            val path = (sheets.getOrNull(sheetIndex) ?: sheets.firstOrNull())?.path ?: "xl/worksheets/sheet1.xml"
            val entry = zip.getEntry(path)
                ?: throw IllegalArgumentException("لا توجد ورقة بيانات في الملف")
            return zip.open(entry).use { parseSheet(it, shared) }
        }
    }

    fun sheets(file: File): List<Sheet> = ZipFile(file).use { sheetList(it) }

    private fun local(name: String) = name.substringAfter(':')

    private fun newParser(s: InputStream): XmlPullParser =
        Xml.newPullParser().also { it.setInput(s, null) }

    /** كل الأوراق بالترتيب (الاسم + مسار الملف داخل الـ zip). */
    private fun sheetList(zip: ZipFile): List<Sheet> {
        try {
            val wb = zip.getEntry("xl/workbook.xml")
            val rels = zip.getEntry("xl/_rels/workbook.xml.rels")
            if (wb != null && rels != null) {
                val found = ArrayList<Pair<String, String>>()   // الاسم، rId
                zip.open(wb).use { st ->
                    val p = newParser(st)
                    var ev = p.eventType
                    while (ev != XmlPullParser.END_DOCUMENT) {
                        if (ev == XmlPullParser.START_TAG && local(p.name) == "sheet") {
                            var rid: String? = null
                            for (i in 0 until p.attributeCount) {
                                val an = p.getAttributeName(i)
                                if (an == "r:id" || an == "id") { rid = p.getAttributeValue(i); break }
                            }
                            if (rid != null) found.add((p.getAttributeValue(null, "name") ?: "") to rid)
                        }
                        ev = p.next()
                    }
                }
                val targets = HashMap<String, String>()
                zip.open(rels).use { st ->
                    val p = newParser(st)
                    var ev = p.eventType
                    while (ev != XmlPullParser.END_DOCUMENT) {
                        if (ev == XmlPullParser.START_TAG && local(p.name) == "Relationship") {
                            val id = p.getAttributeValue(null, "Id"); val tg = p.getAttributeValue(null, "Target")
                            if (id != null && tg != null) targets[id] = tg
                        }
                        ev = p.next()
                    }
                }
                val out = ArrayList<Sheet>()
                for ((name, rid) in found) {
                    val t = targets[rid] ?: continue
                    val path = if (t.startsWith("/")) t.substring(1) else "xl/$t"
                    if (zip.getEntry(path) != null) out.add(Sheet(name.ifEmpty { "Sheet ${out.size + 1}" }, path))
                }
                if (out.isNotEmpty()) return out
            }
        } catch (_: Exception) { /* نرجع للبحث اليدوي */ }
        val re = Regex("xl/worksheets/sheet\\d+\\.xml")
        val paths = zip.entries().asSequence().map { it.name }.filter { re.matches(it) }.sorted().toList()
        return if (paths.isEmpty()) listOf(Sheet("Sheet 1", "xl/worksheets/sheet1.xml"))
        else paths.mapIndexed { i, pth -> Sheet("Sheet ${i + 1}", pth) }
    }

    private fun parseShared(stream: InputStream): List<String> {
        val list = ArrayList<String>()
        val p = newParser(stream)
        var sb: StringBuilder? = null
        var inT = false
        var rph = 0
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> when (local(p.name)) {
                    "si" -> sb = StringBuilder()
                    "rPh" -> rph++
                    "t" -> if (sb != null && rph == 0) inT = true
                }
                XmlPullParser.TEXT -> if (inT) sb?.append(p.text)
                XmlPullParser.END_TAG -> when (local(p.name)) {
                    "t" -> inT = false
                    "rPh" -> rph = maxOf(0, rph - 1)
                    "si" -> { list.add(sb?.toString() ?: ""); sb = null }
                }
            }
            ev = p.next()
        }
        return list
    }

    private fun colFromRef(ref: String?): Int {
        if (ref.isNullOrEmpty()) return -1
        var n = 0
        var any = false
        for (ch in ref) {
            if (ch in 'A'..'Z') { n = n * 26 + (ch - 'A' + 1); any = true }
            else if (ch in 'a'..'z') { n = n * 26 + (ch - 'a' + 1); any = true }
            else break
        }
        return if (any) n - 1 else -1
    }

    private fun normalizeNumber(v: String): String {
        val t = v.trim()
        if (t.isEmpty()) return ""
        return try { BigDecimal(t).stripTrailingZeros().toPlainString() } catch (_: Exception) { t }
    }

    private fun parseSheet(stream: InputStream, shared: List<String>): List<List<String>> {
        val rows = ArrayList<List<String>>()
        val p = newParser(stream)
        var cur: ArrayList<String>? = null
        var colIdx = 0
        var type = ""
        var inV = false
        var inT = false
        val vSb = StringBuilder()
        val tSb = StringBuilder()
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> when (local(p.name)) {
                    "row" -> cur = ArrayList()
                    "c" -> {
                        val row = cur ?: ArrayList<String>().also { cur = it }
                        val ci = colFromRef(p.getAttributeValue(null, "r"))
                        colIdx = if (ci >= 0) ci else row.size
                        type = p.getAttributeValue(null, "t") ?: ""
                        vSb.setLength(0); tSb.setLength(0)
                    }
                    "v" -> inV = true
                    "t" -> if (type == "inlineStr") inT = true
                }
                XmlPullParser.TEXT -> {
                    if (inV) vSb.append(p.text)
                    if (inT) tSb.append(p.text)
                }
                XmlPullParser.END_TAG -> when (local(p.name)) {
                    "v" -> inV = false
                    "t" -> inT = false
                    "c" -> cur?.let { row ->
                        val raw = vSb.toString()
                        val value = when (type) {
                            "s" -> shared.getOrNull(raw.trim().toIntOrNull() ?: -1) ?: ""
                            "inlineStr" -> tSb.toString()
                            "b" -> if (raw.trim() == "1") "TRUE" else "FALSE"
                            "str", "e" -> raw
                            else -> normalizeNumber(raw)
                        }
                        while (row.size < colIdx) row.add("")
                        row.add(value)
                    }
                    "row" -> {
                        cur?.let { row ->
                            while (row.isNotEmpty() && row.last().isBlank()) row.removeAt(row.size - 1)
                            if (row.isNotEmpty()) rows.add(row)
                        }
                        cur = null
                    }
                }
            }
            ev = p.next()
        }
        return rows
    }
}
